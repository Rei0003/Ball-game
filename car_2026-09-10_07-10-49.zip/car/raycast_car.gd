extends RigidBody3D
class_name RaycastCar

@export var wheels: Array[RaycastWheel]
@export var acceleration := 600.0
@export var max_speed := 20.0
@export var accel_curve: Curve
@export var tire_turn_speed := 2.0
@export var tire_max_turn_degrees := 25.0

@export var skid_marks: Array[GPUParticles3D]
@export var total_wheels := wheels.size()

var motor_input := 0
var hand_brake := false
var is_slipping := false

func _get_point_velocity(point: Vector3) -> Vector3:
	return linear_velocity + angular_velocity.cross(point - global_position)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("handbrake-player1"):
		hand_brake = true
		is_slipping = true
	elif  event.is_action_released("handbrake-player1"):
		hand_brake = false
	
	if event.is_action_pressed("accelerate-player1"):
		motor_input = 1
	elif event.is_action_released("accelerate-player1"):
		motor_input = 0
		
	if event.is_action_pressed("decelerate-player1"):
		motor_input = -1
	elif event.is_action_released("decelerate-player1"):
		motor_input = 0

func _basic_steering_rotation(wheel: RaycastWheel, delta: float) -> void:
	if not wheel.is_steer: return
	var turn_input := Input.get_axis("turn_right-player1", "turn_left-player1") * tire_turn_speed
	
	if turn_input:
		wheel.rotation.y = clampf(wheel.rotation.y + turn_input * delta,
		deg_to_rad(-tire_max_turn_degrees), deg_to_rad(tire_max_turn_degrees))
	else:
		wheel.rotation.y = move_toward(wheel.rotation.y, 0, tire_turn_speed * delta)


func _physics_process(delta: float) -> void:
	var grounded := false
	var id := 0
	for wheel in wheels:
		wheel.apply_wheel_physics(self)
		_basic_steering_rotation(wheel, delta)

		skid_marks[id].global_position = wheel.get_collision_point() + Vector3.UP * 0.01
		skid_marks[id].look_at(skid_marks[id].global_position + global_basis.z)
		
		if not hand_brake and wheel.grip_factor < 0.2:
			is_slipping = false
			skid_marks[id].emitting = false
		
		if hand_brake and not skid_marks[id].emitting:
			skid_marks[id].emitting = true
			
		if wheel.is_colliding():
			grounded = true

		id += 1
	if grounded:
		center_of_mass = Vector3.ZERO
	else:
		center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
		center_of_mass = Vector3.DOWN * 0.5
