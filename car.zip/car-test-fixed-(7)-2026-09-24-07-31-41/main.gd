extends Node

@onready var time_label1: Label = $GridContainer/SubViewportContainer/SubViewport/TimeLabel
@onready var time_label2: Label = $GridContainer/SubViewportContainer2/SubViewport/TimeLabel
@onready var timer: Timer = $GridContainer/Timer

@onready var car1: RaycastCar = $GridContainer/SubViewportContainer/SubViewport/Car
@onready var car2: RaycastCar = $GridContainer/SubViewportContainer2/SubViewport/Car2

var time_left: int = 60

var pause_menu_scene = preload("res://pause_menu.tscn")
var pause_menu: Control


func _ready() -> void:
	timer.wait_time = 1.0
	timer.timeout.connect(_on_timer_timeout)
	timer.start()

	update_labels()

	pause_menu = pause_menu_scene.instantiate()
	add_child(pause_menu)

	pause_menu.visible = false


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("Pause-Menu"):
		_toggle_pause()


func _toggle_pause() -> void:
	if get_tree().paused:
		# Resume
		pause_menu.visible = false
		get_tree().paused = false
	else:
		# Pause
		pause_menu.visible = true
		get_tree().paused = true


func _on_timer_timeout() -> void:
	time_left -= 1
	update_labels()

	if time_left <= 0:
		timer.stop()

		if car1.score > car2.score:
			GameState.winner_username = GameState.car1_username
		else:
			GameState.winner_username = GameState.car2_username

		get_tree().change_scene_to_file("res://winning-screen.tscn")


func update_labels() -> void:
	var minutes: int = time_left / 60
	var seconds: int = time_left % 60

	var time_text := "%02d:%02d" % [minutes, seconds]

	time_label1.text = time_text
	time_label2.text = time_text
