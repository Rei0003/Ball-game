extends Control


@onready var resume_button: Button = $VBoxContainer/Button
@onready var options_button: Button = $VBoxContainer/Button2
@onready var quit_button: Button = $VBoxContainer/Button3


func _ready() -> void:
	# The pause menu must continue processing while the game is paused.
	process_mode = Node.PROCESS_MODE_ALWAYS

	resume_button.pressed.connect(_on_resume_pressed)
	options_button.pressed.connect(_on_options_pressed)
	quit_button.pressed.connect(_on_quit_pressed)


func _on_resume_pressed() -> void:
	_resume_game()


func _resume_game() -> void:
	visible = false
	get_tree().paused = false


func _on_options_pressed() -> void:
	pass


func _on_quit_pressed() -> void:
	get_tree().paused = false
	get_tree().quit()
