extends Node3D
class_name TargetSpawner

## Scene to spawn for every target.
@export var target_scene: PackedScene

@export_group("Spawn Area")

## Center of the rectangular area (world X/Z) targets can spawn across.
@export var spawn_center: Vector2 = Vector2(-0.7, 0.64)

## Half-width / half-depth of the spawn area.
@export var spawn_extents: Vector2 = Vector2(2450.0, 2450.0)

## Optional - prevents targets from spawning over the sea.
@export var sea: Sea

@export_group("Ground Raycast")

@export var raycast_start_height: float = 700.0
@export var raycast_max_distance: float = 1500.0
@export var ground_collision_mask: int = 1

@export_group("Target")

## How far above the ground the target should appear.
@export var target_height: float = 8.0

## How many targets can exist at once.
@export var max_active: int = 10

## How often a new target is spawned after one is collected.
@export var spawn_interval: float = 3.0

@export var target_scale: float = 1.0


var _container: Node3D


func _ready() -> void:
	if target_scene == null:
		push_warning(
			"TargetSpawner has no target_scene assigned; no targets will spawn."
		)
		return

	_container = Node3D.new()
	_container.name = "Targets"
	add_child(_container)

	# Spawn the initial targets.
	_try_fill_targets()

	# Timer for replacing collected targets.
	var timer := Timer.new()
	timer.name = "TargetSpawnTimer"
	timer.wait_time = spawn_interval
	timer.autostart = true
	timer.one_shot = false

	add_child(timer)

	timer.timeout.connect(_on_spawn_timer_timeout)


func _on_spawn_timer_timeout() -> void:
	if _container.get_child_count() >= max_active:
		return

	_try_spawn_one()


func _try_fill_targets() -> void:
	while _container.get_child_count() < max_active:
		if not _try_spawn_one():
			break


func _try_spawn_one() -> bool:
	if _container.get_child_count() >= max_active:
		return false

	var ground_position = _find_ground_position()

	if ground_position == null:
		return false

	var target: Target = target_scene.instantiate()

	_container.add_child(target)

	# Put the target above the ground.
	target.global_position = (
		ground_position +
		Vector3.UP * target_height
	)

	target.coin_scale = target_scale

	return true


func _find_ground_position() -> Variant:
	var space_state := get_world_3d().direct_space_state

	for attempt in 30:
		var x: float = (
			spawn_center.x +
			randf_range(-spawn_extents.x, spawn_extents.x)
		)

		var z: float = (
			spawn_center.y +
			randf_range(-spawn_extents.y, spawn_extents.y)
		)

		var from := Vector3(
			x,
			raycast_start_height,
			z
		)

		var to := Vector3(
			x,
			raycast_start_height - raycast_max_distance,
			z
		)

		var query := PhysicsRayQueryParameters3D.create(
			from,
			to
		)

		query.collision_mask = ground_collision_mask

		var result := space_state.intersect_ray(query)

		if not result:
			continue

		# Don't spawn targets over the sea.
		if sea != null and not sea.is_land_y(result.position.y):
			continue

		return result.position

	return null
