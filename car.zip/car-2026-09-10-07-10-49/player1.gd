extends Node
class_name PlayerController

@export_range(1, 2, 1) var player_id: int = 1

func get_action(action: String) -> String:
	return action + "-player" + str(player_id)

func get_steering() -> float:
	return Input.get_axis(
		get_action("turn_right"),
		get_action("turn_left")
	)

func is_accelerating() -> bool:
	return Input.is_action_pressed(get_action("accelerate"))

func is_decelerating() -> bool:
	return Input.is_action_pressed(get_action("decelerate"))

func is_handbraking() -> bool:
	return Input.is_action_pressed(get_action("handbrake"))
