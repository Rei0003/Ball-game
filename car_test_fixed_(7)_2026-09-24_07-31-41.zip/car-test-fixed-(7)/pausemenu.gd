extends Control

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS


func _on_resume_pressed() -> void:
	visible = false
	get_tree().paused = false


func _on_options_pressed() -> void:
	pass


func _on_quit_pressed() -> void:
	get_tree().quit()
