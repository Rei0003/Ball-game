extends Node

@onready var time_label1 = $GridContainer/SubViewportContainer/SubViewport/TimeLabel
@onready var time_label2 = $GridContainer/SubViewportContainer2/SubViewport/TimeLabel
@onready var timer = $GridContainer/Timer

var time_left := 150 # 2 minutes 30 seconds

var pause_menu_scene = preload("res://pause_menu.tscn")
var pause_menu

func _ready():
	timer.wait_time = 1.0
	timer.timeout.connect(_on_timer_timeout)
	timer.start()
	update_labels()
	pause_menu = pause_menu_scene.instantiate()
	pause_menu.visible = false
	add_child(pause_menu)

func _input(event):
	if event.is_action_pressed("Pause-Menu"):
		pause_menu.visible = !pause_menu.visible
		get_tree().paused = pause_menu.visible

func _on_timer_timeout():
	time_left -= 1
	update_labels()

	if time_left <= 0:
		timer.stop()
		time_label1.text = "Time's up!"
		time_label2.text = "Time's up!"

func update_labels():
	var minutes = time_left / 60
	var seconds = time_left % 60
	var time_text = "%02d:%02d" % [minutes, seconds]

	time_label1.text = time_text
	time_label2.text = time_text
