extends Area3D
class_name Coin

## Emitted right before this coin frees itself, so a spawner can react
## (e.g. know a slot in its tier just opened up).
signal collected(coin: Coin)

## Points added to the driver's score when this coin is collected.
@export var score_value: int = 30

## Text shown on the driver's trick label when collected, e.g. "COMMON COIN".
@export var display_name: String = "COIN"

## Uniform size multiplier for the coin mesh and its pickup radius.
@export var coin_scale: float = 1.0:
	set(value):
		coin_scale = value
		scale = Vector3.ONE * coin_scale

## How fast the coin spins in place, purely visual.
@export var spin_speed_degrees: float = 90.0

## Coins further than this from the camera aren't drawn at all. They're
## small enough that they'd only be a few pixels at this range anyway.
@export var draw_distance: float = 350.0

## One shared material per coin colour, instead of a brand new material
## for every single coin. Identical materials let the renderer batch the
## coins together instead of treating each one as a separate draw.
static var _material_cache: Dictionary = {}

@onready var _visual: Node3D = $coin

var _mesh_instances: Array[MeshInstance3D] = []


func _ready() -> void:
	body_entered.connect(_on_body_entered)

	# Nothing ever needs to detect the coin itself - only the coin needs
	# to detect cars - so skip registering it as something detectable.
	monitorable = false

	_mesh_instances = _find_mesh_instances(self)

	for mesh_instance in _mesh_instances:
		# Small spinning coins add almost nothing visually as shadows, but
		# each one would otherwise be drawn again into the shadow map, in
		# both split-screen views.
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mesh_instance.visibility_range_end = draw_distance
		mesh_instance.visibility_range_end_margin = 20.0


func _process(delta: float) -> void:
	# Spin only the visual model, not the Area3D itself - moving the Area3D
	# would make the physics engine update the coin's collision every
	# frame, even though the round pickup shape looks the same rotated.
	_visual.rotate_y(deg_to_rad(spin_speed_degrees) * delta)


func set_coin_color(color: Color) -> void:
	var material: StandardMaterial3D = _material_cache.get(color)

	if material == null:
		material = StandardMaterial3D.new()
		material.albedo_color = color
		material.metallic = 0.85
		material.roughness = 0.25
		_material_cache[color] = material

	if _mesh_instances.is_empty():
		_mesh_instances = _find_mesh_instances(self)

	for mesh_instance in _mesh_instances:
		mesh_instance.material_override = material


func _find_mesh_instances(node: Node) -> Array[MeshInstance3D]:
	var found: Array[MeshInstance3D] = []

	for child in node.get_children():
		if child is MeshInstance3D:
			found.append(child)

		found.append_array(_find_mesh_instances(child))

	return found


func _on_body_entered(body: Node3D) -> void:
	if not (body is RaycastCar):
		return

	var car: RaycastCar = body

	car.score += score_value
	car.score_label.text = str(car.score)

	car.show_trick_message(display_name + " +" + str(score_value))

	collected.emit(self)

	queue_free()
