extends RigidBody3D
class_name RaycastCar

@export var controler: PlayerController

@export_group("Wheels")
@export var wheels: Array[RaycastWheel]
@export var total_wheels: int = 4

@export_group("Engine")
@export var acceleration: float = 750.0
@export var max_speed: float = 60.0
@export var accel_curve: Curve

@export_group("Steering")
@export var tire_turn_speed: float = 3.0
@export var tire_max_turn_degrees: float = 60.0

## Steering angle is gradually reduced between these two speeds (m/s) so
## the car stays stable at speed instead of snapping sideways, while
## keeping full, tight steering lock at parking-lot speeds.
@export var steering_speed_falloff_start: float = 10.0
@export var steering_speed_falloff_end: float = 40.0
@export var min_steering_angle_degrees: float = 18.0

@export_group("Nitro")
@export var nitro_capacity: float = 100.0
@export var nitro_drain_rate: float = 40.0
@export var nitro_regen_rate: float = 12.0
@export var nitro_drift_refill_rate: float = 15.0
@export var nitro_trick_refill: float = 20.0
@export var nitro_boost_multiplier: float = 1.6
@export var nitro_max_speed_bonus: float = 25.0

var nitro: float = 100.0
var is_boosting: bool = false

@export_group("Gearing")
## Drives RPM timing - how quickly each gear climbs to its shift point.
## Ratios should decrease from 1st gear to top gear.
@export var gear_ratios: Array[float] = [3.8, 2.5, 1.9, 1.5, 1.2, 0.85]
## Drives actual force output per gear - kept as a separate, much more
## modest spread than gear_ratios above so low gears feel punchier
## without being explosive. One entry per gear.
@export var gear_torque_multipliers: Array[float] = [
	1.5, 1.3, 1.15, 1.05, 1.0, 0.95
]
@export var reverse_gear_ratio: float = 3.2
@export var reverse_torque_multiplier: float = 1.0
@export var final_drive: float = 3.9
@export var idle_rpm: float = 1000.0
@export var redline_rpm: float = 8000.0
@export var shift_up_rpm: float = 7400.0
@export var shift_down_rpm: float = 3200.0
@export var gear_shift_cooldown_time: float = 0.3

## When true, gears only change via controller.is_upshifting() /
## is_downshifting() - set the player's upshift-playerN / downshift-playerN
## input actions for this to do anything. When false (default), gears
## shift automatically based on RPM as before.
@export var manual_transmission: bool = false

@export_group("Drift/RPM Interaction")
## How much rear grip is reduced at high RPM, representing wheelspin
## under heavy power - 0 disables this entirely. Combined with
## max_grip_force_coefficient and drift_torque_smoothing elsewhere, this
## makes revving hard more likely to break the rear loose without ever
## producing an instant, uncontrollable spin.
@export var drift_rpm_traction_loss: float = 0.35
@export var min_rpm_traction_factor: float = 0.6

var current_gear: int = 1
var is_reversing: bool = false
var is_neutral: bool = false
var engine_rpm: float = 1000.0
var rpm_ratio: float = 0.0
var _gear_shift_cooldown: float = 0.0

@export_group("Launch Control")
## Hold accelerate and decelerate together (while stopped) to rev the
## engine up to this RPM without moving - release decelerate while still
## holding accelerate to launch from that RPM instead of idle.
@export var launch_control_rpm: float = 4500.0
@export var launch_control_speed_threshold: float = 2.0
@export var launch_control_rev_rate: float = 6000.0
@export var launch_boost_duration: float = 0.4
@export var launch_boost_multiplier: float = 1.4

var is_launch_control_active: bool = false
var _launch_boost_timer: float = 0.0

@export_group("Reset")
## How long the reset key must be held before it does a full respawn back
## at the car's starting position, instead of just the normal in-place
## reset (which still happens immediately on every press either way).
@export var respawn_hold_duration: float = 0.6

var _spawn_transform: Transform3D
var _reset_hold_time: float = 0.0
var _has_triggered_hold_respawn: bool = false

@export_group("Drift initiation")
@export var drift_min_speed: float = 6.0
@export var drift_min_steering: float = 0.78
@export var drift_start_angle: float = 8.0
@export var initiation_duration: float = 0.3

@export_group("Drift control")
@export var drift_yaw_strength: float = 3.5
@export var drift_countersteer_strength: float = 1.8
@export var drift_max_angle: float = 65.0
@export var drift_recovery_angle: float = 8.0

## How quickly the drift's yaw torque ramps toward its target strength
## each second, instead of jumping straight to full strength the moment
## the handbrake or a sharp countersteer is applied. Lower = more gradual,
## less snappy; higher = more immediate response.
@export var drift_torque_smoothing: float = 6.0

var _drift_torque_current: float = 0.0

@export_group("Effects")
@export var skid_marks: Array[GPUParticles3D]

@export_group("Air Control")
@export var air_pitch_strength: float = 5.0
@export var air_yaw_strength: float = 4.0
@export var air_roll_strength: float = 4.0
@export var air_control_speed: float = 10.0



@export var controller: PlayerController
@onready var speedometer: Label = $Control/SpeedLabel
@onready var trick_label: Label = $"../CenterContainer/Label"
@onready var score_label: Label = $"../ScoreContainer/ScoreLabel"




@export_group("Speed Effect")
@export var speed_effect_start := 100.0
@export var speed_effect_full := 180.0
@export var speed_effect_smoothing := 4.0

@export var speed_effect: ColorRect

var speed_effect_strength := 0.0




var motor_input: int = 0
var hand_brake: bool = false

var is_slipping: bool = false
var is_drifting: bool = false
var is_initiating_drift: bool = false

var drift_direction: float = 0.0
var initiation_timer: float = 0.0

@export_group("Air Tricks")
@export var flip_detection_enabled: bool = true
@export var minimum_flip_angle: float = 300.0

var was_airborne: bool = false
var frontflip_rotation: float = 0.0
var backflip_rotation: float = 0.0
var trick_label_timer: float = 0.0

@export var score_per_flip: int = 75

var score: int = 0

# Caches so per-frame updates only happen when something actually changed.
var _com_grounded_state: bool = true
var _last_displayed_speed: int = -1
var _last_speed_effect_strength: float = -1.0




func _ready() -> void:
	total_wheels = maxi(total_wheels, 1)

	score = 0
	score_label.text = str(score)

	nitro = nitro_capacity

	_spawn_transform = global_transform

	var world := get_tree().current_scene

	if controler.player_id == 1:
		var username_label: Label = world.get_node(
			"GridContainer/SubViewportContainer/SubViewport/UsernameLabel"
		)
		username_label.text = GameState.car1_username

	elif controler.player_id == 2:
		var username_label: Label = world.get_node(
			"GridContainer/SubViewportContainer2/SubViewport/UsernameLabel"
		)
		username_label.text = GameState.car2_username
	

func _update_speed_effect(delta: float) -> void:
	var velocity := linear_velocity
	
	# Ignore vertical velocity from flips/jumps
	velocity.y = 0.0
	
	var speed_kmh := velocity.length() * 3.6

	var target_strength := clampf(
		inverse_lerp(
			speed_effect_start,
			speed_effect_full,
			speed_kmh
		),
		0.0,
		1.0
	)

	speed_effect_strength = lerpf(
		speed_effect_strength,
		target_strength,
		delta * speed_effect_smoothing
	)

	if absf(speed_effect_strength - _last_speed_effect_strength) < 0.002:
		return

	_last_speed_effect_strength = speed_effect_strength

	var material := speed_effect.material as ShaderMaterial

	if material:
		material.set_shader_parameter(
			"strength",
			speed_effect_strength
		)




func _reset_car() -> void:
	var current_position := global_position
	var current_yaw := global_rotation.y

	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO

	global_position = current_position
	global_rotation = Vector3(0.0, current_yaw, 0.0)


func respawn_at(new_position: Vector3) -> void:
	global_position = new_position

	_reset_car()


## Full respawn back to exactly where the car started the level, facing
## the same way it originally did.
func _respawn_at_start() -> void:
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO

	global_transform = _spawn_transform


## A tap of the reset key does the normal in-place reset, immediately,
## every time. Holding it past respawn_hold_duration additionally sends
## the car all the way back to its starting position.
func _handle_reset_input(delta: float) -> void:
	var reset_action: String = controller.get_action("reset")

	if Input.is_action_just_pressed(reset_action):
		_reset_car()
		_reset_hold_time = 0.0
		_has_triggered_hold_respawn = false

	if Input.is_action_pressed(reset_action):
		_reset_hold_time += delta

		if (
			not _has_triggered_hold_respawn
			and _reset_hold_time >= respawn_hold_duration
		):
			_has_triggered_hold_respawn = true
			_respawn_at_start()
	else:
		_reset_hold_time = 0.0
		_has_triggered_hold_respawn = false


## Simulates gears/RPM from the car's actual speed. current_gear and
## rpm_ratio are read directly by raycast_wheel.gd's engine force
## calculation, so shifting gears genuinely changes how hard the car
## accelerates - this isn't just a cosmetic number.
func _update_gearing(delta: float) -> void:
	if _gear_shift_cooldown > 0.0:
		_gear_shift_cooldown -= delta

	if _launch_boost_timer > 0.0:
		_launch_boost_timer -= delta

	var wheel_radius: float = 0.4

	if wheels.size() > 0 and wheels[0] != null:
		wheel_radius = wheels[0].wheel_radius

	var wheel_circumference: float = TAU * wheel_radius

	var holding_launch_control: bool = (
		controller.is_accelerating()
		and controller.is_decelerating()
		and linear_velocity.length() < launch_control_speed_threshold
	)

	if holding_launch_control:
		is_launch_control_active = true
		is_reversing = false
		is_neutral = false
		current_gear = 1

		engine_rpm = move_toward(
			engine_rpm,
			launch_control_rpm,
			launch_control_rev_rate * delta
		)

		rpm_ratio = inverse_lerp(idle_rpm, redline_rpm, engine_rpm)

		# Keeps the launch boost primed for the moment decelerate is
		# released - it decays on its own timer once actually launched.
		_launch_boost_timer = launch_boost_duration

		return

	if is_launch_control_active:
		# Decelerate was just released while still flooring the gas -
		# this is the launch. is_launch_control_active drops, and the
		# primed _launch_boost_timer carries the RPM's torque advantage
		# into the next few frames of real acceleration.
		is_launch_control_active = false

	var forward_speed: float = -global_basis.z.dot(linear_velocity)

	# Only actually reversing once nearly stopped (or already rolling
	# backward) while holding decelerate - otherwise that input is just
	# braking while still moving forward.
	is_reversing = motor_input < 0 and forward_speed <= 1.0

	if is_reversing:
		is_neutral = false
		current_gear = 0

		var reverse_total_ratio: float = (
			reverse_gear_ratio * final_drive
		)

		var reverse_wheel_rpm: float = (
			(absf(forward_speed) / wheel_circumference) * 60.0
		)

		engine_rpm = clampf(
			idle_rpm + reverse_wheel_rpm * reverse_total_ratio,
			idle_rpm,
			redline_rpm
		)

		rpm_ratio = inverse_lerp(idle_rpm, redline_rpm, engine_rpm)

		return

	if current_gear < 1:
		current_gear = 1

	var speed: float = linear_velocity.length()

	var wheel_rpm: float = (speed / wheel_circumference) * 60.0

	var total_ratio: float = (
		gear_ratios[current_gear - 1] *
		final_drive
	)

	engine_rpm = clampf(
		idle_rpm + wheel_rpm * total_ratio,
		idle_rpm,
		redline_rpm
	)

	rpm_ratio = inverse_lerp(idle_rpm, redline_rpm, engine_rpm)

	# The transmission reads as "neutral" whenever RPM has settled back
	# to idle - in this model that only happens when the car is stopped
	# and off the throttle, same as a real automatic left in gear at a
	# standstill would eventually show close to idle.
	is_neutral = engine_rpm <= idle_rpm + 50.0

	if _gear_shift_cooldown > 0.0:
		return

	if manual_transmission:
		if controller.is_upshifting() and current_gear < gear_ratios.size():
			current_gear += 1
			_gear_shift_cooldown = gear_shift_cooldown_time
		elif controller.is_downshifting() and current_gear > 1:
			current_gear -= 1
			_gear_shift_cooldown = gear_shift_cooldown_time

		return

	if (
		engine_rpm >= shift_up_rpm
		and current_gear < gear_ratios.size()
	):
		current_gear += 1
		_gear_shift_cooldown = gear_shift_cooldown_time
	elif (
		engine_rpm <= shift_down_rpm
		and current_gear > 1
	):
		current_gear -= 1
		_gear_shift_cooldown = gear_shift_cooldown_time


## Extra force multiplier while a primed launch is still playing out,
## giving the car the RPM's torque advantage for a brief moment right as
## it takes off from a launch-control hold, instead of starting from idle.
func get_launch_boost_multiplier() -> float:
	if _launch_boost_timer > 0.0:
		return launch_boost_multiplier

	return 1.0


## The force multiplier for whatever gear is currently engaged, used by
## raycast_wheel.gd's engine force calculation.
func get_current_gear_torque_multiplier() -> float:
	if is_reversing:
		return reverse_torque_multiplier

	return gear_torque_multipliers[current_gear - 1]


## How much rear-wheel grip should be scaled by right now, based on RPM -
## full grip near idle, reduced (down to min_rpm_traction_factor) near
## redline, representing wheelspin under heavy power.
func get_rpm_traction_factor() -> float:
	return maxf(
		min_rpm_traction_factor,
		1.0 - rpm_ratio * drift_rpm_traction_loss
	)


func _update_speedometer() -> void:
	var velocity := linear_velocity
	
	
	
	var speed_kmh := velocity.length() * 3.6

	var rounded_speed: int = roundi(speed_kmh)

	# Changing a Label's text makes it re-layout, so only do it when the
	# displayed number actually changes.
	if rounded_speed != _last_displayed_speed:
		_last_displayed_speed = rounded_speed
		speedometer.text = str(rounded_speed)




func _get_point_velocity(point: Vector3) -> Vector3:
	return (
		linear_velocity +
		angular_velocity.cross(point - global_position)
	)


func _update_inputs() -> void:
	if controller.is_accelerating():
		motor_input = 1
	elif controller.is_decelerating():
		motor_input = -1
	else:
		motor_input = 0

	hand_brake = controller.is_handbraking()


func _get_steering_input() -> float:
	return controller.get_steering()


func _basic_steering_rotation(
	wheel: RaycastWheel,
	delta: float
) -> void:

	if not wheel.is_steer:
		return

	var steering_input: float = _get_steering_input()

	var speed: float = linear_velocity.length()

	var speed_factor: float = 1.0 - clampf(
		inverse_lerp(
			steering_speed_falloff_start,
			steering_speed_falloff_end,
			speed
		),
		0.0,
		1.0
	)

	var current_max_turn_degrees: float = lerpf(
		min_steering_angle_degrees,
		tire_max_turn_degrees,
		speed_factor
	)

	var target_angle: float = (
		steering_input *
		deg_to_rad(current_max_turn_degrees)
	)

	var steering_speed: float = tire_turn_speed

	if is_drifting:
		steering_speed *= 1.35

	wheel.rotation.y = move_toward(
		wheel.rotation.y,
		target_angle,
		steering_speed * delta
	)


func _get_drift_angle() -> float:
	var velocity: Vector3 = linear_velocity

	velocity.y = 0.0

	if velocity.length_squared() < 1.0:
		return 0.0

	var forward: Vector3 = -global_basis.z

	forward.y = 0.0
	forward = forward.normalized()

	var velocity_direction: Vector3 = velocity.normalized()

	var angle: float = rad_to_deg(
		acos(
			clampf(
				forward.dot(velocity_direction),
				-1.0,
				1.0
			)
		)
	)

	var side: float = signf(
		global_basis.x.dot(velocity_direction)
	)

	return angle * side


func _begin_drift(direction: float) -> void:
	is_drifting = true
	is_initiating_drift = false
	initiation_timer = 0.0
	drift_direction = direction


func _begin_drift_initiation(direction: float) -> void:
	is_initiating_drift = true
	initiation_timer = initiation_duration
	drift_direction = direction


func _update_drift_state(delta: float) -> void:
	var speed: float = linear_velocity.length()
	var steering: float = _get_steering_input()

	if speed < drift_min_speed:
		is_drifting = false
		is_initiating_drift = false
		drift_direction = 0.0
		initiation_timer = 0.0
		return

	if not is_drifting and not is_initiating_drift:

		if hand_brake and absf(steering) > 0.2:
			_begin_drift(signf(steering))
			return

		if absf(steering) >= drift_min_steering:
			_begin_drift_initiation(signf(steering))
			return

	if is_initiating_drift:

		initiation_timer -= delta

		if absf(steering) < 0.5 and not hand_brake:
			is_initiating_drift = false
			initiation_timer = 0.0
			return

		var drift_angle: float = absf(_get_drift_angle())

		if drift_angle >= drift_start_angle:
			_begin_drift(drift_direction)
			return

		if initiation_timer <= 0.0:
			_begin_drift(drift_direction)
			return

	if is_drifting:

		var current_angle: float = absf(_get_drift_angle())

		if current_angle > drift_max_angle:
			is_drifting = false
			drift_direction = 0.0
			return

		if (
			current_angle < drift_recovery_angle
			and absf(steering) < 0.2
		):
			is_drifting = false
			drift_direction = 0.0


func _apply_drift_control(delta: float) -> void:
	if not is_drifting:
		_drift_torque_current = 0.0
		return

	var speed: float = linear_velocity.length()

	if speed < drift_min_speed:
		_drift_torque_current = 0.0
		return

	var steering: float = _get_steering_input()
	var direction: float = drift_direction

	var target_torque: float = 0.0

	if absf(steering) >= 0.05 and direction != 0.0:
		var countersteering: bool = (
			steering * direction < 0.0
		)

		if countersteering:
			target_torque = (
				steering *
				drift_countersteer_strength
			)
		else:
			target_torque = (
				steering *
				drift_yaw_strength
			)

	var actual_angle: float = _get_drift_angle()

	if absf(actual_angle) > 40.0:
		target_torque -= (
			signf(actual_angle) *
			drift_countersteer_strength *
			0.5
		)

	_drift_torque_current = move_toward(
		_drift_torque_current,
		target_torque,
		drift_torque_smoothing * delta
	)

	apply_torque(
		global_basis.y *
		_drift_torque_current
	)

func _apply_air_control(delta: float) -> void:
	var steering: float = _get_steering_input()
	var pitch_input: float = float(motor_input)
	var roll_input: float = controller.get_roll()

	var local_angular_velocity: Vector3 = (
		global_basis.inverse() * angular_velocity
	)

	var target_pitch: float = (
		-pitch_input *
		air_pitch_strength
	)

	local_angular_velocity.x = move_toward(
		local_angular_velocity.x,
		target_pitch,
		air_control_speed * delta
	)

	var target_yaw: float = (
		steering *
		air_yaw_strength
	)

	local_angular_velocity.y = move_toward(
		local_angular_velocity.y,
		target_yaw,
		air_control_speed * delta
	)



	var target_roll: float = (
		roll_input *
		air_roll_strength
	)

	local_angular_velocity.z = move_toward(
		local_angular_velocity.z,
		target_roll,
		air_control_speed * delta
	)

	angular_velocity = (
		global_basis *
		local_angular_velocity
	)

func _flips_from_rotation(rotation_amount: float) -> int:
	# A flip counts once its rotation gets within "tolerance" of the next
	# full 360, instead of requiring an exact multiple of 360. This lets
	# slightly-short flips (e.g. 340 degrees) still register, while still
	# needing at least minimum_flip_angle of rotation for the first one.
	var tolerance: float = 360.0 - minimum_flip_angle

	return int(
		(rotation_amount + tolerance) / 360.0
	)

func _update_flip_detection(grounded: bool) -> void:
	if not flip_detection_enabled:
		return

	if not grounded and not was_airborne:
		was_airborne = true
		frontflip_rotation = 0.0
		backflip_rotation = 0.0

		return

	if not grounded and was_airborne:
		var local_angular_velocity: Vector3 = (
			global_basis.inverse() *
			angular_velocity
		)

		var pitch_speed: float = local_angular_velocity.x

		var pitch_degrees_per_second: float = (
			rad_to_deg(pitch_speed)
		)

		var delta_rotation: float = (
			pitch_degrees_per_second *
			get_physics_process_delta_time()
		)

		# Frontflip and backflip rotation are tracked separately (rather
		# than summed into one signed total) so that flipping one way and
		# then the other in the same airtime doesn't cancel out and lose
		# both tricks.
		if delta_rotation < 0.0:
			frontflip_rotation += -delta_rotation
		else:
			backflip_rotation += delta_rotation

	if grounded and was_airborne:
		was_airborne = false

		var completed_frontflips: int = _flips_from_rotation(
			frontflip_rotation
		)

		var completed_backflips: int = _flips_from_rotation(
			backflip_rotation
		)

		if completed_frontflips > 0 or completed_backflips > 0:
			var trick_lines: PackedStringArray = []
			var total_earned_score: int = 0

			# ---------------------------------------------------------
			# FRONTFLIPS
			# ---------------------------------------------------------

			if completed_frontflips > 0:
				var frontflip_score: int = (
					completed_frontflips *
					score_per_flip
				)

				total_earned_score += frontflip_score

				trick_lines.append(
					"FRONTFLIP x" +
					str(completed_frontflips) +
					"  +" +
					str(frontflip_score)
				)

			# ---------------------------------------------------------
			# BACKFLIPS
			# ---------------------------------------------------------

			if completed_backflips > 0:
				var backflip_score: int = (
					completed_backflips *
					score_per_flip
				)

				total_earned_score += backflip_score

				trick_lines.append(
					"BACKFLIP x" +
					str(completed_backflips) +
					"  +" +
					str(backflip_score)
				)

			# ---------------------------------------------------------
			# SCORE
			# ---------------------------------------------------------

			score += total_earned_score

			score_label.text = str(score)

			nitro = minf(nitro_capacity, nitro + nitro_trick_refill)

			# ---------------------------------------------------------
			# TRICK LABEL
			# ---------------------------------------------------------

			show_trick_message("\n".join(trick_lines))

			print(
				trick_label.text,
				" score"
			)

		frontflip_rotation = 0.0
		backflip_rotation = 0.0

func _update_trick_label(delta: float) -> void:
	if not trick_label.visible:
		return

	trick_label_timer -= delta

	if trick_label_timer <= 0.0:
		trick_label.hide()


## Shows a short-lived message in the same on-screen spot as flip tricks
## (e.g. a coin pickup). Reuses the trick label's own show/hide timer.
func show_trick_message(text: String, duration: float = 2.0) -> void:
	trick_label.text = text
	trick_label.show()
	trick_label_timer = duration


func _update_nitro(delta: float) -> void:
	is_boosting = (
		controller.is_boosting()
		and nitro > 0.0
		and motor_input > 0
	)

	if is_boosting:
		nitro = maxf(0.0, nitro - nitro_drain_rate * delta)
		return

	var regen_rate: float = nitro_regen_rate

	if is_drifting:
		regen_rate += nitro_drift_refill_rate

	nitro = minf(nitro_capacity, nitro + regen_rate * delta)



func _physics_process(delta: float) -> void:
	_handle_reset_input(delta)

	_update_inputs()
	_update_drift_state(delta)
	_apply_drift_control(delta)
	_update_nitro(delta)
	_update_gearing(delta)
	_update_speedometer()
	_update_speed_effect(delta)
	_update_trick_label(delta)


	var grounded: bool = false

	for id in wheels.size():
		var wheel: RaycastWheel = wheels[id]

		wheel.apply_wheel_physics(self)
		_basic_steering_rotation(wheel, delta)

		if id < skid_marks.size():
			var skid: GPUParticles3D = skid_marks[id]

			if wheel.is_colliding():
				skid.global_position = (
					wheel.get_collision_point() +
					Vector3.UP * 0.01
				)

				skid.look_at(
					skid.global_position +
					global_basis.z
				)

			var should_emit: bool = (
				is_drifting
				and not wheel.is_steer
				and wheel.grip_factor > 0.15
				and wheel.is_colliding()
			)

			if skid.emitting != should_emit:
				skid.emitting = should_emit

		if wheel.is_colliding():
			grounded = true

	_update_flip_detection(grounded)

	if not grounded:
		_apply_air_control(delta)


	# Only touch the center of mass when grounded/airborne actually
	# changes. Setting it makes the physics engine recalculate the car's
	# mass properties, which was happening every single physics frame.
	if grounded != _com_grounded_state:
		_com_grounded_state = grounded

		if grounded:
			center_of_mass_mode = (
				RigidBody3D.CENTER_OF_MASS_MODE_AUTO
			)

			center_of_mass = Vector3.ZERO

		else:
			center_of_mass_mode = (
				RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
			)

			center_of_mass = Vector3.DOWN * 0.5
