extends Camera3D

@export_group("Camera Distance")
@export var min_distance: float = 4.0
@export var max_distance: float = 8.0
@export var height: float = 3.0

@export_group("Collision")
@export_flags_3d_physics var terrain_collision_mask: int = 1
@export var camera_radius: float = 0.35
@export var ground_clearance: float = 0.5

@export_group("Smoothing")
@export_range(0.01, 1.0) var position_smoothing: float = 0.15


@onready var target: Node3D = get_parent()

# Built once and reused, rather than allocating two new query objects
# every physics frame.
var _camera_query := PhysicsRayQueryParameters3D.new()
var _ground_query := PhysicsRayQueryParameters3D.new()


func _ready() -> void:
	var exclude: Array[RID] = []

	# The query's exclude list takes physics RIDs, not nodes.
	if target is CollisionObject3D:
		exclude.append((target as CollisionObject3D).get_rid())

	_camera_query.exclude = exclude
	_ground_query.exclude = exclude


func _physics_process(_delta: float) -> void:
	if not is_instance_valid(target):
		return

	var space_state: PhysicsDirectSpaceState3D = (
		get_world_3d().direct_space_state
	)



	var offset: Vector3 = (
		global_position -
		target.global_position
	)


	if offset.length_squared() < 0.01:
		offset = target.global_basis.z * max_distance


	var horizontal_offset: Vector3 = Vector3(
		offset.x,
		0.0,
		offset.z
	)

	if horizontal_offset.length_squared() < 0.01:
		horizontal_offset = (
			target.global_basis.z *
			max_distance
		)

	horizontal_offset = horizontal_offset.normalized()

	var desired_position: Vector3 = (
		target.global_position +
		horizontal_offset * max_distance +
		Vector3.UP * height
	)



	var camera_direction: Vector3 = (
		desired_position -
		target.global_position
	)

	var camera_distance: float = (
		camera_direction.length()
	)

	if camera_distance > 0.01:
		camera_direction = (
			camera_direction.normalized()
		)


		var ray_start: Vector3 = (
			target.global_position +
			Vector3.UP * 0.5
		)

		var ray_end: Vector3 = (
			ray_start +
			camera_direction * camera_distance
		)

		_camera_query.from = ray_start
		_camera_query.to = ray_end
		_camera_query.collision_mask = terrain_collision_mask

		var camera_result: Dictionary = (
			space_state.intersect_ray(_camera_query)
		)

		if not camera_result.is_empty():
			var collision_position: Vector3 = (
				camera_result["position"]
			)

			var safe_distance: float = (
				target.global_position.distance_to(
					collision_position
				) -
				camera_radius -
				ground_clearance
			)

			safe_distance = clampf(
				safe_distance,
				min_distance,
				max_distance
			)

			desired_position = (
				target.global_position +
				camera_direction * safe_distance
			)



	var ground_start: Vector3 = (
		desired_position +
		Vector3.UP * 2.0
	)

	var ground_end: Vector3 = (
		desired_position +
		Vector3.DOWN * 20.0
	)

	_ground_query.from = ground_start
	_ground_query.to = ground_end
	_ground_query.collision_mask = terrain_collision_mask

	var ground_result: Dictionary = (
		space_state.intersect_ray(_ground_query)
	)

	if not ground_result.is_empty():
		var ground_position: Vector3 = (
			ground_result["position"]
		)

		var minimum_camera_height: float = (
			ground_position.y +
			camera_radius +
			ground_clearance
		)

		if desired_position.y < minimum_camera_height:
			desired_position.y = (
				minimum_camera_height
			)

	global_position = global_position.lerp(
		desired_position,
		position_smoothing
	)

	look_at(
		target.global_position,
		Vector3.UP
	)
