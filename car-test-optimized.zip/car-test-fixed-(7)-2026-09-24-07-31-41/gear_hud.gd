extends VBoxContainer
class_name GearHud

## The car this HUD is displaying gear/RPM/nitro for.
@export var car: RaycastCar

@onready var gear_label: Label = $GearLabel
@onready var rpm_bar: ProgressBar = $RpmBar
@onready var nitro_bar: ProgressBar = $NitroBar

const NITRO_COLOR_NORMAL := Color(0.35, 0.65, 1.0)
const NITRO_COLOR_BOOSTING := Color(1.0, 0.55, 0.15)

var _nitro_fill_style: StyleBoxFlat
var _last_gear_text: String = ""
var _last_rpm: int = -1
var _last_boosting: bool = false

func _ready() -> void:
	rpm_bar.min_value = 0.0
	rpm_bar.max_value = 1.0
	rpm_bar.show_percentage = false

	nitro_bar.min_value = 0.0
	nitro_bar.show_percentage = false

	# A dedicated stylebox instance for THIS bar only, so recoloring it
	# for the boost effect can't bleed into any other progress bar that
	# happens to share the same theme resource.
	_nitro_fill_style = StyleBoxFlat.new()
	_nitro_fill_style.bg_color = NITRO_COLOR_NORMAL
	nitro_bar.add_theme_stylebox_override("fill", _nitro_fill_style)

func _process(_delta: float) -> void:
	if car == null:
		return

	var gear_text: String

	if car.is_reversing:
		gear_text = "R"
	elif car.is_neutral:
		gear_text = "N"
	else:
		gear_text = str(car.current_gear)

	# Rounded to the nearest 50 like a real rev counter, and only pushed
	# to the label when it changes - rewriting a Label every frame forces
	# it to re-layout every frame.
	var displayed_rpm: int = int(round(car.engine_rpm / 50.0)) * 50

	if gear_text != _last_gear_text or displayed_rpm != _last_rpm:
		_last_gear_text = gear_text
		_last_rpm = displayed_rpm

		gear_label.text = (
			"Gear " +
			gear_text +
			"  " +
			str(displayed_rpm) +
			" RPM"
		)

	rpm_bar.value = car.rpm_ratio

	nitro_bar.max_value = car.nitro_capacity
	nitro_bar.value = car.nitro

	if car.is_boosting != _last_boosting:
		_last_boosting = car.is_boosting

		_nitro_fill_style.bg_color = (
			NITRO_COLOR_BOOSTING if car.is_boosting
			else NITRO_COLOR_NORMAL
		)
