extends Control


@onready var resume_button: Button = $VBoxContainer/Button
@onready var options_button: Button = $VBoxContainer/Button2
@onready var quit_button: Button = $VBoxContainer/Button3
@onready var seed_label: Label = get_node_or_null("VBoxContainer/SeedLabel")
@onready var end_round_button: Button = get_node_or_null("VBoxContainer/EndRoundButton")


func _ready() -> void:
	# The pause menu must continue processing while the game is paused -
	# and this is also what lets it catch the Escape key to CLOSE the
	# menu again, since everything else stops receiving input once the
	# tree is paused.
	process_mode = Node.PROCESS_MODE_ALWAYS

	resume_button.pressed.connect(_on_resume_pressed)
	options_button.pressed.connect(_on_options_pressed)
	quit_button.pressed.connect(_on_quit_pressed)

	if end_round_button != null:
		end_round_button.pressed.connect(_on_end_round_pressed)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("Pause-Menu"):
		if get_tree().paused:
			_resume_game()
		else:
			_pause_game()


func _pause_game() -> void:
	# Shows which map this is, so a good one can be replayed by entering
	# the seed on the naming screen.
	if seed_label != null:
		seed_label.text = "Map seed: " + str(GameState.current_map_seed)

	visible = true
	get_tree().paused = true


func _on_resume_pressed() -> void:
	_resume_game()


func _resume_game() -> void:
	visible = false
	get_tree().paused = false


func _on_options_pressed() -> void:
	# Added as a child of the pause menu so it keeps running while paused,
	# and gets the Escape key before the pause menu does.
	var options: Control = preload("res://options_menu.tscn").instantiate()
	add_child(options)


func _on_quit_pressed() -> void:
	get_tree().paused = false
	# Stops sounds cleanly before closing (see GameState.quit_game).
	GameState.quit_game()


## Finishes the match early and goes to the results - the only way to end
## a round with the timer turned off.
func _on_end_round_pressed() -> void:
	visible = false
	get_tree().paused = false

	var world := get_tree().current_scene

	if world != null and world.has_method("end_round"):
		world.end_round()
