extends Camera3D

@export_group("Camera Distance")
@export var min_distance: float = 4.0
@export var max_distance: float = 8.0
@export var height: float = 3.0

@export_group("Collision")
@export_flags_3d_physics var terrain_collision_mask: int = 1
@export var camera_radius: float = 0.35
@export var ground_clearance: float = 0.5

@export_group("Smoothing")
@export_range(0.01, 1.0) var position_smoothing: float = 0.15

@export_group("Speed Feel")
## Extra field of view (degrees) at full speed, and on top of that with
## nitro. A widening view is one of the strongest cues of going fast.
@export var fov_speed_kick: float = 9.0
@export var fov_boost_kick: float = 6.0
@export var fov_smoothing: float = 5.0
## Small camera shake at high speed, stronger on nitro. Applied as a
## lens offset, so it never moves the camera itself.
@export var shake_at_speed: float = 0.025
@export var shake_on_boost: float = 0.05
@export var shake_frequency: float = 18.0

@export_group("Hood View")
## Toggled with the player's "camera" action (C for player 1, numpad + for
## player 2). Sits wherever this marker is on the car - move the marker in
## the editor to fit a new car model. Falls back to hood_offset if the car
## has no marker.
@export var hood_marker_name: String = "HoodCamera"
@export var hood_offset: Vector3 = Vector3(0.0, 0.6, -1.0)
@export var hood_pitch_degrees: float = -2.0
## Narrowest-it-can-be field of view in hood view. The tall splitscreen
## halves use a very wide view, which from the hood would be mostly hood;
## this keeps it a natural hood-cam view (singleplayer is already below it).
@export var hood_max_fov: float = 75.0

## Points on the car (in its own space) marking the front edge of the hood.
## In hood view, the speed effect leaves everything below them alone, so it
## doesn't draw over your own car. Left empty, they're worked out from the
## front-top edge of the car's "CarMesh" body.
@export var hood_mask_points: PackedVector3Array = PackedVector3Array()

var hood_view: bool = false
var _hood_marker: Node3D
var _hood_mask_local := PackedVector3Array()
var _mask_applied: bool = false

var _base_fov: float = 75.0
var _shake_time: float = 0.0


@onready var target: Node3D = get_parent()

# Built once and reused, rather than allocating two new query objects
# every physics frame.
var _camera_query := PhysicsRayQueryParameters3D.new()
var _ground_query := PhysicsRayQueryParameters3D.new()


func _ready() -> void:
	_base_fov = fov

	# The camera is top-level, so its scene transform is in world space,
	# but it was laid out relative to the car. Snap it into that spot
	# behind wherever the car actually starts (it moves every map), instead
	# of swooping across the map on the first frames.
	if is_instance_valid(target):
		global_transform = target.global_transform * transform
		_hood_marker = target.get_node_or_null(hood_marker_name) as Node3D
		_hood_mask_local = _find_hood_edge()

	var exclude: Array[RID] = []

	# The query's exclude list takes physics RIDs, not nodes.
	if target is CollisionObject3D:
		exclude.append((target as CollisionObject3D).get_rid())

	_camera_query.exclude = exclude
	_ground_query.exclude = exclude


func _process(delta: float) -> void:
	if not is_instance_valid(target):
		return

	_check_view_toggle()

	# Hood view is placed here, at render time, using where the car really
	# is this frame. Doing it in the physics step (like the chase camera)
	# would leave it a step behind the car, making the hood shudder.
	if hood_view:
		global_transform = _hood_transform()

	var strength: float = 0.0
	var boost: float = 0.0

	if target is RaycastCar:
		strength = (target as RaycastCar).speed_effect_strength
		boost = (target as RaycastCar).speed_effect_boost

	var base_fov: float = minf(_base_fov, hood_max_fov) if hood_view else _base_fov

	var target_fov: float = (
		base_fov +
		fov_speed_kick * strength +
		fov_boost_kick * boost
	)

	fov = lerpf(fov, target_fov, minf(1.0, delta * fov_smoothing))

	_update_hood_mask()

	var shake: float = shake_at_speed * strength + shake_on_boost * boost

	if shake < 0.0005:
		h_offset = 0.0
		v_offset = 0.0
		return

	_shake_time += delta * shake_frequency

	# A few out-of-step sine waves - a smooth rumble rather than jitter.
	h_offset = shake * (
		sin(_shake_time * 1.0) * 0.6 +
		sin(_shake_time * 2.3 + 1.7) * 0.4
	)

	v_offset = shake * (
		sin(_shake_time * 1.4 + 0.5) * 0.6 +
		sin(_shake_time * 2.9 + 2.2) * 0.4
	)


func _physics_process(_delta: float) -> void:
	if not is_instance_valid(target) or hood_view:
		return

	var space_state: PhysicsDirectSpaceState3D = (
		get_world_3d().direct_space_state
	)



	var offset: Vector3 = (
		global_position -
		target.global_position
	)


	if offset.length_squared() < 0.01:
		offset = target.global_basis.z * max_distance


	var horizontal_offset: Vector3 = Vector3(
		offset.x,
		0.0,
		offset.z
	)

	if horizontal_offset.length_squared() < 0.01:
		horizontal_offset = (
			target.global_basis.z *
			max_distance
		)

	horizontal_offset = horizontal_offset.normalized()

	var desired_position: Vector3 = (
		target.global_position +
		horizontal_offset * max_distance +
		Vector3.UP * height
	)



	var camera_direction: Vector3 = (
		desired_position -
		target.global_position
	)

	var camera_distance: float = (
		camera_direction.length()
	)

	if camera_distance > 0.01:
		camera_direction = (
			camera_direction.normalized()
		)


		var ray_start: Vector3 = (
			target.global_position +
			Vector3.UP * 0.5
		)

		var ray_end: Vector3 = (
			ray_start +
			camera_direction * camera_distance
		)

		_camera_query.from = ray_start
		_camera_query.to = ray_end
		_camera_query.collision_mask = terrain_collision_mask

		var camera_result: Dictionary = (
			space_state.intersect_ray(_camera_query)
		)

		if not camera_result.is_empty():
			var collision_position: Vector3 = (
				camera_result["position"]
			)

			var safe_distance: float = (
				target.global_position.distance_to(
					collision_position
				) -
				camera_radius -
				ground_clearance
			)

			safe_distance = clampf(
				safe_distance,
				min_distance,
				max_distance
			)

			desired_position = (
				target.global_position +
				camera_direction * safe_distance
			)



	desired_position = _keep_above_ground(desired_position, space_state)

	var new_position: Vector3 = global_position.lerp(
		desired_position,
		position_smoothing
	)

	# Check where the camera actually ends up, not just where it's heading:
	# gliding toward a new spot (say, after the car drops off a cliff) can
	# otherwise cut straight through the terrain on the way.
	new_position = _keep_view_clear(new_position, space_state)
	new_position = _keep_above_ground(new_position, space_state)

	global_position = new_position

	look_at(
		target.global_position,
		Vector3.UP
	)


## Height of the ground under a point, found from far above - so it always
## hits the top surface, even when the point is buried deep inside a steep
## hillside (a ray starting inside the terrain would never see it).
func _ground_height(point: Vector3, space_state: PhysicsDirectSpaceState3D) -> float:
	var top: float = maxf(point.y, target.global_position.y) + 80.0

	_ground_query.from = Vector3(point.x, top, point.z)
	_ground_query.to = Vector3(point.x, point.y - 60.0, point.z)
	_ground_query.collision_mask = terrain_collision_mask

	var hit: Dictionary = space_state.intersect_ray(_ground_query)

	if hit.is_empty():
		return -INF

	return hit["position"].y


func _keep_above_ground(point: Vector3, space_state: PhysicsDirectSpaceState3D) -> Vector3:
	var ground: float = _ground_height(point, space_state)
	var lowest: float = ground + camera_radius + ground_clearance

	if point.y < lowest:
		point.y = lowest

	return point


## If terrain sits between the car and the camera, pull the camera in to the
## near side of it, so the car stays in view and the camera stays outside.
func _keep_view_clear(point: Vector3, space_state: PhysicsDirectSpaceState3D) -> Vector3:
	var from: Vector3 = target.global_position + Vector3.UP * 0.5
	var to_camera: Vector3 = point - from
	var distance: float = to_camera.length()

	if distance < 0.01:
		return point

	_camera_query.from = from
	_camera_query.to = point + to_camera / distance * camera_radius
	_camera_query.collision_mask = terrain_collision_mask

	var hit: Dictionary = space_state.intersect_ray(_camera_query)

	if hit.is_empty():
		return point

	var safe: float = maxf(from.distance_to(hit["position"]) - camera_radius - 0.1, 0.5)

	return from + to_camera / distance * safe


func _check_view_toggle() -> void:
	if not (target is RaycastCar):
		return

	var car := target as RaycastCar

	if car.controller == null:
		return

	var action: String = car.controller.get_action("camera")

	if InputMap.has_action(action) and Input.is_action_just_pressed(action):
		set_hood_view(not hood_view)


func set_hood_view(enabled: bool) -> void:
	hood_view = enabled

	if hood_view:
		global_transform = _hood_transform()
	else:
		# Start the chase camera straight behind the car. Its logic keeps
		# whatever direction it's already in, which coming out of hood view
		# would otherwise be in FRONT of the car.
		global_position = (
			target.global_position +
			target.global_basis.z * max_distance +
			Vector3.UP * height
		)
		look_at(target.global_position, Vector3.UP)


func _hood_transform() -> Transform3D:
	if is_instance_valid(_hood_marker):
		return _hood_marker.global_transform

	var local := Transform3D(
		Basis(Vector3.RIGHT, deg_to_rad(hood_pitch_degrees)),
		hood_offset
	)

	return target.global_transform * local


## The hood's front edge, in the car's own space.
func _find_hood_edge() -> PackedVector3Array:
	if not hood_mask_points.is_empty():
		return hood_mask_points

	var body := target.get_node_or_null("CarMesh") as MeshInstance3D

	if body == null or body.mesh == null:
		return PackedVector3Array()

	# Front-top edge of the body (the car's front is -Z).
	var box: AABB = body.mesh.get_aabb()
	var edge := PackedVector3Array()

	for x in [box.position.x, box.position.x + box.size.x * 0.5, box.end.x]:
		edge.append(body.transform * Vector3(x, box.end.y, box.position.z))

	return edge


## In hood view, tells the speed effect where the hood is on screen - its
## front edge plus its two sides running back toward the camera - so it
## leaves the hood alone. Off in chase view.
func _update_hood_mask() -> void:
	if not (target is RaycastCar):
		return

	var effect: Control = (target as RaycastCar).speed_effect

	if effect == null or not (effect.material is ShaderMaterial):
		return

	var material := effect.material as ShaderMaterial

	if not hood_view or _hood_mask_local.size() < 2:
		if _mask_applied:
			material.set_shader_parameter("hood_mask_on", false)
			_mask_applied = false

		return

	# Front corners: leftmost and rightmost edge points. Near corners: the
	# same sides, carried back to just in front of the camera.
	var front_left: Vector3 = _hood_mask_local[0]
	var front_right: Vector3 = _hood_mask_local[0]

	for point in _hood_mask_local:
		if point.x < front_left.x:
			front_left = point
		if point.x > front_right.x:
			front_right = point

	var camera_local: Vector3 = target.to_local(global_position)
	var near_z: float = camera_local.z - 0.25

	var corners: Array[Vector3] = [
		front_left,
		front_right,
		Vector3(front_right.x, front_right.y, near_z),
		Vector3(front_left.x, front_left.y, near_z),
	]

	var size: Vector2 = get_viewport().get_visible_rect().size
	var names: Array[String] = ["hood_fl", "hood_fr", "hood_nr", "hood_nl"]

	for i in corners.size():
		var world: Vector3 = target.global_transform * corners[i]

		if is_position_behind(world):
			material.set_shader_parameter("hood_mask_on", false)
			_mask_applied = false
			return

		material.set_shader_parameter(names[i], unproject_position(world) / size)

	material.set_shader_parameter("hood_mask_on", true)
	_mask_applied = true
