extends Node
class_name DayNightCycle

## Day/night cycle: moves the sun (and the moon at night) across the sky,
## changes the light and sky colours through day, golden hour, dusk and
## night, brings out stars at night, and tells the cars how dark it is so
## they can switch their headlights on.
##
## Follows Options > Time of day: the full cycle, always day, or always
## night.

## 0 = full daylight, 1 = full night. Read by the cars for their lights.
static var darkness: float = 0.0

@export var sun: DirectionalLight3D
@export var world_environment: WorldEnvironment

## Length of one full day (and night), in minutes.
@export var cycle_minutes: float = 6.0
## Share of each cycle the sun is up. Days are longer than nights.
@export_range(0.3, 0.9) var day_fraction: float = 0.65
## Start each match at a random time of day, so short rounds see variety.
@export var random_start: bool = true
## Where in the cycle to start when random_start is off (0 = sunrise).
@export_range(0.0, 1.0) var start_time: float = 0.2
## Compass direction the sun rises from, in degrees.
@export var sun_path_yaw: float = 30.0
## How high the sun gets at noon, in degrees above the horizon.
@export var sun_max_elevation: float = 65.0
## Slows the sun down near the horizon (and speeds it up around noon and
## midnight), so sunrise, sunset and the golden light around them last much
## longer. 0 = constant speed; up to about 0.8. The day stays the same length.
@export_range(0.0, 0.85) var golden_hour_stretch: float = 0.65
## Sun elevation (0-1) where the golden colours have fully given way to
## plain daylight. Higher = the warm light reaches further into the day.
@export var golden_top_elevation: float = 0.45

@export_group("Light")
@export var sun_energy: float = 1.0
@export var moon_energy: float = 0.28
@export var moon_color: Color = Color(0.55, 0.65, 0.95)
## Extra ambient light at night, so the ground stays readable by moonlight.
@export var night_ambient_boost: float = 2.5

@export_group("Fog")
## Light distance haze in the colour of the horizon, so the far side of the
## big map fades out softly instead of ending at a hard line.
@export var fog_enabled: bool = true
@export var fog_density: float = 0.00022

## Position in the cycle: 0 = sunrise, day_fraction = sunset, 1 = next
## sunrise.
var time_of_day: float = 0.0

var _sky_material: ShaderMaterial
var _sky_timer: float = 0.0

const DAY_TOP := Color(0.24, 0.45, 0.85)
const DAY_HORIZON := Color(0.66, 0.76, 0.88)
const GOLDEN_TOP := Color(0.32, 0.42, 0.72)
const GOLDEN_HORIZON := Color(0.98, 0.6, 0.35)
const DUSK_TOP := Color(0.1, 0.12, 0.3)
const DUSK_HORIZON := Color(0.6, 0.32, 0.38)
const NIGHT_TOP := Color(0.012, 0.018, 0.05)
const NIGHT_HORIZON := Color(0.05, 0.07, 0.13)


func _ready() -> void:
	if world_environment != null and world_environment.environment != null:
		var sky := world_environment.environment.sky

		if sky != null:
			_sky_material = sky.sky_material as ShaderMaterial
			# Re-light the scene from the sky gradually as it changes,
			# rather than all at once every update.
			sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL

	if random_start:
		var rng := RandomNumberGenerator.new()
		rng.randomize()
		time_of_day = rng.randf()
	else:
		time_of_day = start_time

	GameState.settings_changed.connect(_apply_mode)
	_apply_mode()
	_update(0.0, true)


func _apply_mode() -> void:
	match GameState.time_of_day_mode:
		GameState.TimeOfDay.ALWAYS_DAY:
			time_of_day = day_fraction * 0.38
		GameState.TimeOfDay.ALWAYS_NIGHT:
			time_of_day = day_fraction + (1.0 - day_fraction) * 0.5

	_update(0.0, true)


func _process(delta: float) -> void:
	_update(delta, false)


func _update(delta: float, force_sky: bool) -> void:
	if GameState.time_of_day_mode == GameState.TimeOfDay.CYCLE and cycle_minutes > 0.0:
		time_of_day = fposmod(time_of_day + delta / (cycle_minutes * 60.0), 1.0)

	var sun_dir: Vector3 = _sun_direction(time_of_day)
	var moon_dir: Vector3 = -sun_dir
	var elevation: float = sun_dir.y

	darkness = 1.0 - smoothstep(-0.1, 0.15, elevation)

	_update_light(sun_dir, moon_dir, elevation)

	_sky_timer -= delta

	if force_sky or _sky_timer <= 0.0:
		_sky_timer = 0.1
		_update_sky(sun_dir, moon_dir, elevation)


## Direction toward the sun. It rises, arcs up to sun_max_elevation at
## noon, sets, then carries on round below the horizon through the night.
func _sun_direction(t: float) -> Vector3:
	var angle: float

	if t < day_fraction:
		angle = _slow_near_horizon(t / day_fraction) * PI
	else:
		angle = PI + _slow_near_horizon((t - day_fraction) / (1.0 - day_fraction)) * PI

	var yaw: float = deg_to_rad(sun_path_yaw)
	var across := Vector3(cos(yaw), 0.0, sin(yaw))
	var tilt: float = deg_to_rad(90.0 - sun_max_elevation)
	var overhead := Vector3.UP.rotated(across.cross(Vector3.UP).normalized(), tilt)

	return (across * cos(angle) + overhead * sin(angle)).normalized()


## Remaps progress through the day (or night) so the sun moves slowly at
## either end - near the horizon - and quickly in the middle.
func _slow_near_horizon(progress: float) -> float:
	return progress - golden_hour_stretch * sin(TAU * progress) / TAU


func _update_light(sun_dir: Vector3, moon_dir: Vector3, elevation: float) -> void:
	if sun == null:
		return

	# One light: the sun by day, the moon by night, fading through the
	# horizon in between.
	var sun_up: bool = elevation >= 0.0
	var toward: Vector3 = sun_dir if sun_up else moon_dir
	var up_hint: Vector3 = Vector3.FORWARD if absf(toward.y) > 0.98 else Vector3.UP

	sun.global_transform.basis = Basis.looking_at(-toward, up_hint)

	var sun_amount: float = smoothstep(-0.02, 0.12, elevation)
	var moon_amount: float = smoothstep(-0.02, 0.12, -elevation)

	var day_color: Color = Color(1.0, 0.62, 0.38).lerp(
		Color(1.0, 0.97, 0.92),
		smoothstep(0.05, golden_top_elevation, elevation)
	)

	if sun_up:
		sun.light_color = day_color
		sun.light_energy = sun_energy * sun_amount
	else:
		sun.light_color = moon_color
		sun.light_energy = moon_energy * moon_amount

	if world_environment != null and world_environment.environment != null:
		world_environment.environment.ambient_light_energy = lerpf(1.0, night_ambient_boost, darkness)


func _update_sky(sun_dir: Vector3, moon_dir: Vector3, elevation: float) -> void:
	if _sky_material == null:
		return

	var top: Color
	var horizon: Color

	if elevation >= golden_top_elevation:
		top = DAY_TOP
		horizon = DAY_HORIZON
	elif elevation >= 0.08:
		var k: float = inverse_lerp(0.08, golden_top_elevation, elevation)
		top = GOLDEN_TOP.lerp(DAY_TOP, k)
		horizon = GOLDEN_HORIZON.lerp(DAY_HORIZON, k)
	elif elevation >= -0.06:
		var k: float = inverse_lerp(-0.06, 0.08, elevation)
		top = DUSK_TOP.lerp(GOLDEN_TOP, k)
		horizon = DUSK_HORIZON.lerp(GOLDEN_HORIZON, k)
	elif elevation >= -0.25:
		var k: float = inverse_lerp(-0.25, -0.06, elevation)
		top = NIGHT_TOP.lerp(DUSK_TOP, k)
		horizon = NIGHT_HORIZON.lerp(DUSK_HORIZON, k)
	else:
		top = NIGHT_TOP
		horizon = NIGHT_HORIZON

	var sun_color: Color = Color(1.0, 0.55, 0.3).lerp(
		Color(1.0, 0.95, 0.85),
		smoothstep(0.05, 0.4, elevation)
	)

	if world_environment != null and world_environment.environment != null:
		var env := world_environment.environment
		env.fog_enabled = fog_enabled
		env.fog_density = fog_density
		env.fog_light_color = horizon
		env.fog_sky_affect = 0.0

	_sky_material.set_shader_parameter("top_color", top)
	_sky_material.set_shader_parameter("horizon_color", horizon)
	_sky_material.set_shader_parameter("ground_color", horizon * 0.45)
	_sky_material.set_shader_parameter("sun_direction", sun_dir)
	_sky_material.set_shader_parameter("sun_color", sun_color)
	_sky_material.set_shader_parameter("sun_visibility", smoothstep(-0.05, 0.02, elevation))
	_sky_material.set_shader_parameter("moon_direction", moon_dir)
	_sky_material.set_shader_parameter("moon_visibility", 1.0 - smoothstep(-0.12, 0.05, elevation))
	_sky_material.set_shader_parameter("star_visibility", 1.0 - smoothstep(-0.25, -0.02, elevation))
