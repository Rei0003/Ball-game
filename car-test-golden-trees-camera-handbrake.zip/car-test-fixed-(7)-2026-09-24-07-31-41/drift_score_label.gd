extends Label
class_name DriftScoreLabel

## Live drift combo display. The number counts up smoothly with a little
## pop and a tick sound as it climbs (pitch rising with the combo), flashes
## and pops bigger when the multiplier goes up, bursts outward with a chime
## when the combo is banked, and shakes red when it's lost.

@export var car: RaycastCar

## How quickly the shown number catches up with the real one.
@export var count_speed: float = 10.0
## Points between tick sounds.
@export var tick_every: int = 5

@export_group("Sound")
@export var sounds_enabled: bool = true
@export var volume_db: float = -10.0
@export var tick_sound: AudioStream = preload("res://sounds/drift_tick.wav")
@export var multiplier_sound: AudioStream = preload("res://sounds/drift_multiplier.wav")
@export var bank_sound: AudioStream = preload("res://sounds/drift_bank.wav")
@export var fail_sound: AudioStream = preload("res://sounds/drift_fail.wav")

const COLOR_START := Color(1.0, 0.62, 0.15)
const COLOR_HOT := Color(1.0, 0.28, 0.1)
const COLOR_FLASH := Color(1.0, 1.0, 0.85)
const COLOR_BANK := Color(0.45, 1.0, 0.5)
const COLOR_FAIL := Color(1.0, 0.25, 0.22)

enum State { IDLE, ACTIVE, BANKED, FAILED }

var _state: State = State.IDLE
var _shown: float = 0.0
var _last_tick: int = 0
var _tick_cooldown: float = 0.0
var _pop: float = 0.0
var _flash: float = 0.0
var _outro: float = 0.0
var _base_position := Vector2.ZERO

var _tick_player: AudioStreamPlayer
var _event_player: AudioStreamPlayer


func _ready() -> void:
	visible = false
	resized.connect(_update_pivot)
	_update_pivot()

	_tick_player = _make_player("DriftTick")
	_tick_player.max_polyphony = 4
	_event_player = _make_player("DriftEvent")

	if car != null:
		car.drift_multiplier_increased.connect(_on_multiplier_increased)
		car.drift_banked.connect(_on_banked)
		car.drift_failed.connect(_on_failed)


func _make_player(label: String) -> AudioStreamPlayer:
	var player := AudioStreamPlayer.new()
	player.name = label
	player.volume_db = volume_db
	add_child(player)
	return player


## Scale from the middle, so pops grow outward evenly.
func _update_pivot() -> void:
	pivot_offset = size * 0.5


func _process(delta: float) -> void:
	if car == null:
		return

	_tick_cooldown -= delta
	_pop = move_toward(_pop, 0.0, delta * 2.5)
	_flash = move_toward(_flash, 0.0, delta * 3.0)

	match _state:
		State.IDLE, State.ACTIVE:
			_update_combo(delta)
		State.BANKED:
			_update_bank_outro(delta)
		State.FAILED:
			_update_fail_outro(delta)


func _update_combo(delta: float) -> void:
	if not car.is_drift_combo_active():
		if _state == State.ACTIVE:
			# Ended too small to bank - just fade away.
			modulate.a = move_toward(modulate.a, 0.0, delta * 5.0)

			if modulate.a <= 0.0:
				_state = State.IDLE
				visible = false

		return

	if _state != State.ACTIVE:
		_state = State.ACTIVE
		_shown = 0.0
		_last_tick = 0
		modulate.a = 1.0
		position = _base_position if _base_position != Vector2.ZERO else position
		_base_position = position
		visible = true

	var target: float = car.get_drift_combo_value()

	# Count up smoothly: quick to catch up when far behind, never stalling.
	_shown = move_toward(_shown, target, maxf(25.0 * delta, (target - _shown) * count_speed * delta))

	var value: int = int(_shown)

	if value >= _last_tick + tick_every:
		_last_tick = value - value % tick_every
		_pop = maxf(_pop, 0.1)
		_play_tick(value)

	text = "DRIFT  +%d  x%d" % [value, car.get_drift_multiplier()]

	# Warmer the bigger the combo, with a bright flash on multiplier up.
	var heat: float = clampf(_shown / 400.0, 0.0, 1.0)
	add_theme_color_override("font_color", COLOR_START.lerp(COLOR_HOT, heat).lerp(COLOR_FLASH, _flash))

	scale = Vector2.ONE * (1.0 + _pop)


func _update_bank_outro(delta: float) -> void:
	_outro += delta

	var t: float = clampf(_outro / 0.8, 0.0, 1.0)

	# Burst outward and fade.
	scale = Vector2.ONE * (1.15 + 0.6 * ease(t, 0.4))
	modulate.a = 1.0 - smoothstep(0.35, 1.0, t)

	if t >= 1.0:
		_finish_outro()


func _update_fail_outro(delta: float) -> void:
	_outro += delta

	var t: float = clampf(_outro / 0.7, 0.0, 1.0)

	# Shake side to side, settling, then fade.
	position.x = _base_position.x + sin(_outro * 55.0) * 14.0 * (1.0 - t)
	scale = Vector2.ONE * (1.0 - 0.1 * t)
	modulate.a = 1.0 - smoothstep(0.4, 1.0, t)

	if t >= 1.0:
		_finish_outro()


func _finish_outro() -> void:
	_state = State.IDLE
	visible = false
	scale = Vector2.ONE
	position = _base_position
	modulate.a = 1.0


func _on_multiplier_increased(multiplier: int) -> void:
	_pop = 0.35
	_flash = 1.0
	_play_event(multiplier_sound, 1.0 + (multiplier - 2) * 0.12)


func _on_banked(points: int, multiplier: int) -> void:
	_state = State.BANKED
	_outro = 0.0
	visible = true
	modulate.a = 1.0
	text = "+%d" % points
	add_theme_color_override("font_color", COLOR_BANK)
	_play_event(bank_sound, 1.0)


func _on_failed(_reason: String) -> void:
	_state = State.FAILED
	_outro = 0.0
	visible = true
	modulate.a = 1.0
	text = "DRIFT LOST"
	add_theme_color_override("font_color", COLOR_FAIL)
	_play_event(fail_sound, 1.0)


func _play_tick(value: int) -> void:
	if not sounds_enabled or tick_sound == null or _tick_cooldown > 0.0:
		return

	# Limit how fast ticks can fire, so a fast count-up stays a crisp
	# rattle instead of a buzz.
	_tick_cooldown = 0.055
	_tick_player.stream = tick_sound
	_tick_player.pitch_scale = (
		1.0
		+ clampf(value / 500.0, 0.0, 1.0) * 0.8
		+ (car.get_drift_multiplier() - 1) * 0.1
	)
	_tick_player.play()


func _play_event(stream: AudioStream, pitch: float) -> void:
	if not sounds_enabled or stream == null:
		return

	_event_player.stream = stream
	_event_player.pitch_scale = pitch
	_event_player.play()
