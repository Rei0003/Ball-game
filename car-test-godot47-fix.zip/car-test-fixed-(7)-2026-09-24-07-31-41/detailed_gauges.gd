extends Control
class_name DetailedGauges

## Single round gauge in the style of Forza Horizon / NFS Payback, kept
## minimal: no background or outlines, just a segmented RPM ring (red
## redline, flashes at the shift point), the speed as big digits in the
## middle, the gear above it, and nitro as an arc in the gap at the bottom.
## Drawn entirely in code, so it stays sharp at any size.
##
## Shown instead of the simple HUD when GameState.use_detailed_hud() says so
## (by default in singleplayer) - switchable from the Options menu.

@export var car: RaycastCar

## How quickly the RPM ring and speed follow the real values.
@export var smoothing: float = 14.0

const GAUGE_SIZE := Vector2(230.0, 230.0)
const CENTRE := Vector2(115.0, 115.0)
const RADIUS := 100.0

## The RPM ring sweeps 270 degrees, leaving a gap at the bottom for nitro.
const RPM_START := 135.0
const RPM_SWEEP := 270.0
const RPM_SEGMENTS := 44
const RING_WIDTH := 11.0

## Nitro arc fills the bottom gap, left to right.
const NITRO_START := 128.0
const NITRO_END := 52.0

# Unlit segments are faint dark shapes - with no background behind the
# gauge, faint white ones would vanish against bright ground.
const COLOR_SEGMENT_OFF := Color(0, 0, 0, 0.28)
const COLOR_SEGMENT_ON := Color(1, 1, 1, 0.95)
const COLOR_RED_OFF := Color(0.55, 0.08, 0.06, 0.45)
const COLOR_SHADOW := Color(0, 0, 0, 0.45)
const COLOR_RED_ON := Color(1.0, 0.25, 0.22, 1.0)
const COLOR_TEXT := Color(1, 1, 1, 0.97)
const COLOR_DIM_TEXT := Color(1, 1, 1, 0.55)
const COLOR_NITRO := Color(0.35, 0.65, 1.0)
const COLOR_BOOST := Color(1.0, 0.55, 0.15)

var _font: Font
var _rpm_shown: float = 0.0
var _speed_shown: float = 0.0
var _nitro_shown: float = 1.0
var _flash_time: float = 0.0
var _last_drawn: Array = []


func _ready() -> void:
	custom_minimum_size = GAUGE_SIZE
	_font = get_theme_font("font", "Label")

	GameState.settings_changed.connect(_apply_style)
	get_viewport().size_changed.connect(_fit_to_view)

	_apply_style()
	_fit_to_view()


func _apply_style() -> void:
	visible = GameState.use_detailed_hud()


## Full size on a full-width view; shrinks on narrow splitscreen halves,
## keeping the bottom-right corner in place.
func _fit_to_view() -> void:
	var view_width: float = get_viewport_rect().size.x
	var fit: float = clampf(view_width / 900.0, 0.65, 1.0)

	pivot_offset = GAUGE_SIZE
	scale = Vector2(fit, fit)


func _process(delta: float) -> void:
	if car == null or not visible:
		return

	var blend: float = minf(1.0, delta * smoothing)

	# Shown revs include the nitro over-rev (past the redline = ring full).
	_rpm_shown = lerpf(_rpm_shown, car.display_rpm, blend)
	_speed_shown = lerpf(_speed_shown, car.linear_velocity.length() * 3.6, blend)
	_nitro_shown = lerpf(_nitro_shown, car.nitro / maxf(car.nitro_capacity, 1.0), blend)

	var shifting: bool = _at_shift_point()

	if shifting:
		_flash_time += delta
	else:
		_flash_time = 0.0

	# Only redraw when something visible has actually changed.
	var state: Array = [
		roundi(_rpm_shown / 20.0),
		roundi(_speed_shown),
		roundi(_nitro_shown * 100.0),
		_gear_text(),
		car.is_boosting,
		_flash_on(),
	]

	if state != _last_drawn:
		_last_drawn = state
		queue_redraw()


func _gear_text() -> String:
	if car.is_reversing:
		return "R"

	if car.is_neutral:
		return "N"

	return str(car.current_gear)


## Follows the real revs, so nitro over-revving doesn't set off the shift
## light when no shift is actually due.
func _at_shift_point() -> bool:
	return car.engine_rpm >= car.shift_up_rpm * 0.97 and not car.is_reversing


## The shift light blinks rather than just staying red, so it catches the
## eye in the corner of the screen.
func _flash_on() -> bool:
	return _at_shift_point() and fmod(_flash_time, 0.16) < 0.09


func _rpm_angle(t: float) -> float:
	return deg_to_rad(RPM_START + RPM_SWEEP * clampf(t, 0.0, 1.0))


func _draw() -> void:
	if car == null:
		return

	var redline: float = maxf(car.redline_rpm, 1000.0)
	var rpm_t: float = clampf(_rpm_shown / redline, 0.0, 1.0)
	var red_from: float = car.shift_up_rpm * 0.95 / redline
	var flash: bool = _flash_on()

	# --- Segmented RPM ring ----------------------------------------------
	var seg_sweep: float = RPM_SWEEP / RPM_SEGMENTS

	for i in RPM_SEGMENTS:
		var t0: float = float(i) / RPM_SEGMENTS
		var lit: bool = t0 < rpm_t
		var red: bool = t0 >= red_from

		var color: Color

		if flash:
			color = COLOR_RED_ON
		elif red:
			color = COLOR_RED_ON if lit else COLOR_RED_OFF
		else:
			color = COLOR_SEGMENT_ON if lit else COLOR_SEGMENT_OFF

		var a0: float = deg_to_rad(RPM_START + seg_sweep * i + seg_sweep * 0.12)
		var a1: float = deg_to_rad(RPM_START + seg_sweep * (i + 1) - seg_sweep * 0.12)

		draw_arc(CENTRE, RADIUS - RING_WIDTH * 0.5, a0, a1, 4, color, RING_WIDTH, true)

	# RPM numbers (x1000) just inside the ring.
	var thousands: int = int(redline / 1000.0)

	for k in thousands + 1:
		var t: float = (k * 1000.0) / redline
		var a: float = _rpm_angle(t)
		var pos: Vector2 = CENTRE + Vector2(cos(a), sin(a)) * (RADIUS - 26.0)
		var color: Color = COLOR_RED_ON if t >= red_from else COLOR_DIM_TEXT

		_draw_centered(str(k), pos, 13, color)

	# --- Nitro arc in the bottom gap -------------------------------------
	var nitro_color: Color = COLOR_BOOST if car.is_boosting else COLOR_NITRO
	var nitro_r: float = RADIUS - RING_WIDTH * 0.5

	draw_arc(CENTRE, nitro_r, deg_to_rad(NITRO_START), deg_to_rad(NITRO_END), 16, COLOR_SEGMENT_OFF, RING_WIDTH * 0.55, true)

	if _nitro_shown > 0.01:
		var fill_end: float = lerpf(NITRO_START, NITRO_END, _nitro_shown)

		if car.is_boosting:
			draw_arc(CENTRE, nitro_r, deg_to_rad(NITRO_START), deg_to_rad(fill_end), 16, Color(nitro_color, 0.3), RING_WIDTH * 1.3, true)

		draw_arc(CENTRE, nitro_r, deg_to_rad(NITRO_START), deg_to_rad(fill_end), 16, nitro_color, RING_WIDTH * 0.55, true)

	_draw_centered("NOS", CENTRE + Vector2(0.0, RADIUS - 24.0), 10, nitro_color)

	# --- Gear -------------------------------------------------------------
	var gear_color: Color = COLOR_RED_ON if flash else COLOR_TEXT

	_draw_centered(_gear_text(), CENTRE + Vector2(0.0, -40.0), 26, gear_color)

	# --- Speed ------------------------------------------------------------
	_draw_centered(str(roundi(_speed_shown)), CENTRE + Vector2(0.0, 6.0), 52, COLOR_TEXT)
	_draw_centered("KM/H", CENTRE + Vector2(0.0, 40.0), 12, COLOR_DIM_TEXT)


func _draw_centered(text: String, centre: Vector2, size: int, color: Color) -> void:
	if _font == null:
		return

	var width: float = _font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	var baseline := Vector2(centre.x - width * 0.5, centre.y + size * 0.35)

	# A soft drop shadow instead of an outline - keeps text readable over
	# bright ground without the heavy outlined look.
	var offset: float = maxf(1.0, size * 0.04)
	draw_string(_font, baseline + Vector2(offset, offset), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(COLOR_SHADOW, COLOR_SHADOW.a * color.a))
	draw_string(_font, baseline, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
