extends Node

var car1_username: String = ""
var car2_username: String = ""
var winner_username: String = ""

## Seed for the procedurally generated map. 0 = pick a random one each
## match. Set from the naming screen to replay a particular map.
var map_seed: int = 0

## The seed the current map was actually built from (shown in the pause
## menu, so a good map can be noted down and replayed).
var current_map_seed: int = 0

enum GameMode { SPLITSCREEN, SINGLEPLAYER }

## Chosen on the naming screen; kept between matches until changed.
var game_mode: GameMode = GameMode.SPLITSCREEN
var timer_enabled: bool = true
## Round length in seconds, when the timer is on.
var round_length_seconds: int = 60

## Results of the last round, for the results screen.
var car1_score: int = 0
var car2_score: int = 0
var is_draw: bool = false


func is_singleplayer() -> bool:
	return game_mode == GameMode.SINGLEPLAYER


## A username, or a sensible default if the player left it blank.
func display_name(player: int) -> String:
	var name: String = car1_username if player == 1 else car2_username
	name = name.strip_edges()

	if name.is_empty():
		return "Player " + str(player)

	return name


# --- Settings (saved between launches) -------------------------------------

## Emitted whenever a setting changes, so open screens can update live
## (e.g. switching gauge style from the pause menu).
signal settings_changed

## AUTO = detailed gauges in singleplayer, simple ones in splitscreen.
enum HudStyle { AUTO, SIMPLE, DETAILED }

const SETTINGS_PATH := "user://settings.cfg"

var hud_style: HudStyle = HudStyle.AUTO

enum TimeOfDay { CYCLE, ALWAYS_DAY, ALWAYS_NIGHT }

var time_of_day_mode: TimeOfDay = TimeOfDay.CYCLE


func _ready() -> void:
	load_settings()


## Whether the detailed gauges should be showing right now.
func use_detailed_hud() -> bool:
	match hud_style:
		HudStyle.SIMPLE:
			return false
		HudStyle.DETAILED:
			return true

	return is_singleplayer()


func set_hud_style(style: HudStyle) -> void:
	if style == hud_style:
		return

	hud_style = style
	save_settings()
	settings_changed.emit()


func set_time_of_day_mode(mode: TimeOfDay) -> void:
	if mode == time_of_day_mode:
		return

	time_of_day_mode = mode
	save_settings()
	settings_changed.emit()


func load_settings() -> void:
	var config := ConfigFile.new()

	if config.load(SETTINGS_PATH) != OK:
		return

	hud_style = clampi(
		config.get_value("display", "hud_style", HudStyle.AUTO),
		HudStyle.AUTO,
		HudStyle.DETAILED
	) as HudStyle

	time_of_day_mode = clampi(
		config.get_value("display", "time_of_day", TimeOfDay.CYCLE),
		TimeOfDay.CYCLE,
		TimeOfDay.ALWAYS_NIGHT
	) as TimeOfDay


func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("display", "hud_style", hud_style)
	config.set_value("display", "time_of_day", time_of_day_mode)
	config.save(SETTINGS_PATH)


# --- Starting a match --------------------------------------------------------

var _loading_layer: CanvasLayer


## Starts a match. Building the map takes a few seconds, during which the
## screen can't redraw - so a "Generating map..." message is drawn first,
## and stays on screen until the world has finished loading.
func start_match() -> void:
	_show_loading("Generating map...")

	# Two frames so the message is actually drawn before the long load.
	await get_tree().process_frame
	await get_tree().process_frame

	get_tree().change_scene_to_file("res://world.tscn")


## Called by the world once the map is built.
func hide_loading() -> void:
	if _loading_layer != null:
		_loading_layer.queue_free()
		_loading_layer = null


func _show_loading(text: String) -> void:
	hide_loading()

	_loading_layer = CanvasLayer.new()
	_loading_layer.layer = 100
	add_child(_loading_layer)

	var backdrop := ColorRect.new()
	backdrop.color = Color(0.0, 0.0, 0.0, 0.65)
	backdrop.set_anchors_preset(Control.PRESET_FULL_RECT)
	_loading_layer.add_child(backdrop)

	var label := Label.new()
	label.text = text
	label.set_anchors_preset(Control.PRESET_FULL_RECT)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 36)
	_loading_layer.add_child(label)
