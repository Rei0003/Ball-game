extends RigidBody3D
class_name RaycastCar

@export var controler: PlayerController

@export_group("Wheels")
@export var wheels: Array[RaycastWheel]
@export var total_wheels: int = 4

@export_group("Engine")
@export var acceleration: float = 750.0
@export var max_speed: float = 60.0
@export var accel_curve: Curve

@export_group("Tire Smoke")
@export var tire_smoke_enabled: bool = true
@export var tire_smoke_color: Color = Color(0.92, 0.92, 0.92)
## Most puffs alive per rear wheel at once - this is the cap at full
## intensity; light slides use only a fraction of it.
@export var tire_smoke_amount: int = 48
## How long each puff lingers (seconds) before fully fading out.
@export var tire_smoke_lifetime: float = 2.2
## Overall size multiplier for the smoke puffs.
@export var tire_smoke_size: float = 1.0
## Smoke also bursts from the rear tires for this long after a
## launch-control start.
@export var tire_smoke_on_launch: bool = true

var _tire_smoke: Dictionary = {}

@export_group("Tire Marks")
@export var tire_marks_enabled: bool = true
## Seconds marks stay on the ground before fading away.
@export var tire_mark_lifetime: float = 20.0
@export var tire_mark_color: Color = Color(0.035, 0.032, 0.03)
@export var tire_mark_opacity: float = 0.9

var _tire_marks: Dictionary = {}

@export_group("Drift Scoring")
@export var drift_score_enabled: bool = true
## Base points per second of drifting, before angle, speed and the
## combo multiplier are applied.
@export var drift_points_per_second: float = 3.5
## Below this real slide angle (degrees) a drift earns nothing - stops
## points being farmed by just holding the drift state with no slide.
@export var drift_score_min_angle: float = 10.0
## Angle (degrees) that earns the full 1x angle rate. Bigger angles earn
## more, up to 1.5x.
@export var drift_score_full_angle: float = 40.0
## Speed (km/h) that earns the full 1x speed rate. Scales from 0.3x when
## slow up to 2x when fast.
@export var drift_score_reference_speed: float = 60.0
## Seconds of continuous scoring drift needed for each +1 multiplier.
@export var drift_multiplier_interval: float = 5.0
@export var drift_max_multiplier: int = 2
## After a drift ends, this long (seconds, on the ground) to start the
## next one and keep the combo alive before it gets banked.
@export var drift_chain_window: float = 1.2
## Combos worth less than this aren't banked (stops tiny wiggles spamming
## the trick label).
@export var drift_min_bank_points: int = 25
## Sliding further sideways than this (degrees) counts as a spin-out and
## loses the combo. Past 90° the car is going sideways-backwards - a
## properly countersteered drift stays well under this.
@export var drift_spin_out_angle: float = 95.0
## Losing speed faster than this (m/s per second) counts as a crash and
## loses the combo. Measured: normal drifting peaks around 5, a spin's
## tire scrub around 40, a wall hit at speed in the hundreds.
@export var drift_crash_deceleration: float = 80.0
## Diminishing returns on a single combo, so one endless drift can't
## out-earn everything else in the game. A combo can approach this many
## points but never pass it: short combos are barely affected (100 raw
## banks ~92), long ones level off (raw 300 ~236, raw 800 ~440).
@export var drift_combo_soft_cap: float = 600.0

@onready var drift_label: Label = get_node_or_null("../DriftLabel")

var _drift_combo_active: bool = false
var _drift_points: float = 0.0
var _drift_multiplier: int = 1
var _drift_multiplier_timer: float = 0.0
var _drift_chain_timer: float = 0.0
var _drift_prev_speed: float = 0.0
var _last_drift_label_text: String = ""
# Set when a combo is lost, so the same out-of-control slide can't
# immediately start a fresh combo - cleared once that slide ends.
var _drift_fail_lockout: bool = false

@export_group("Anti-Roll Bars")
## Resists body lean in corners by linking each axle's left and right
## wheels. Stiffer front than rear keeps the car stable and predictable
## (it'll push wide slightly before it ever swaps ends). Raise the rear
## value for a more tail-happy car, set either to 0 to disable that bar.
@export var front_anti_roll: float = 2500.0
@export var rear_anti_roll: float = 1500.0

var _front_axle: Array[RaycastWheel] = []
var _rear_axle: Array[RaycastWheel] = []

@export_group("Steering")
@export var tire_turn_speed: float = 3.0
@export var tire_max_turn_degrees: float = 60.0

## Steering angle is gradually reduced between these two speeds (m/s) so
## the car stays stable at speed instead of snapping sideways, while
## keeping full, tight steering lock at parking-lot speeds.
@export var steering_speed_falloff_start: float = 10.0
@export var steering_speed_falloff_end: float = 40.0
@export var min_steering_angle_degrees: float = 18.0

@export_group("Nitro")
@export var nitro_capacity: float = 100.0
@export var nitro_drain_rate: float = 40.0
@export var nitro_regen_rate: float = 12.0
@export var nitro_drift_refill_rate: float = 15.0
@export var nitro_trick_refill: float = 20.0
@export var nitro_boost_multiplier: float = 1.6
@export var nitro_max_speed_bonus: float = 25.0

var nitro: float = 100.0
var is_boosting: bool = false

## NFS-style: while boosting, the revs shown on the gauges (and heard, once
## there's engine sound) jump up toward - and past - the redline. This is
## display only: the real engine_rpm still drives acceleration and gear
## changes, because the acceleration curve cuts power at the top of the
## rev range and pushing the real RPM there would kill the boost.
## How far the shown revs push toward the over-rev limit (0-1).
@export var nitro_rev_push: float = 0.65
## How far past the redline the shown revs can go on nitro.
@export var nitro_overrev_rpm: float = 900.0
## How fast the shown revs rise and fall (RPM per second).
@export var display_rpm_rise_rate: float = 9000.0
@export var display_rpm_fall_rate: float = 7000.0

@export_group("Lights")
## Headlights and taillights come on as it gets dark (see DayNightCycle).
@export var car_lights_enabled: bool = true
@export var headlight_energy: float = 6.0
@export var headlight_range: float = 75.0
@export var headlight_angle: float = 32.0
@export var headlight_color: Color = Color(1.0, 0.95, 0.85)
## Where the lights sit on the body (the car's front is -Z).
@export var headlight_offset: Vector3 = Vector3(0.68, 0.05, -2.02)
@export var taillight_offset: Vector3 = Vector3(0.7, 0.05, 2.02)

## In singleplayer the player switches the headlights on and off with this
## input action (L by default). In splitscreen they stay automatic.
@export var headlight_toggle_action: String = "toggle-headlights"

var _headlights: Array[SpotLight3D] = []
var _headlights_switched_on: bool = false
var _manual_lights_level: float = 0.0
var _headlight_hint_shown: bool = false
var _headlight_lens: StandardMaterial3D
var _taillight_lens: StandardMaterial3D
var _lights_level: float = -1.0
var _brake_level: float = -1.0

@export_group("Nitro Sound")
@export var nitro_sounds_enabled: bool = true
@export var nitro_sound_volume_db: float = -6.0
## Burst when nitro kicks in, and the hiss that loops while boosting.
## Swap these for your own recordings any time.
@export var nitro_start_sound: AudioStream = preload("res://sounds/nitro_start.wav")
@export var nitro_loop_sound: AudioStream = preload("res://sounds/nitro_loop.wav")

var _nitro_start_player: AudioStreamPlayer
var _nitro_loop_player: AudioStreamPlayer
var _nitro_loop_level: float = 0.0
var _was_boosting_for_sound: bool = false
var _nitro_start_cooldown: float = 0.0

## Revs for the gauges and sound - engine_rpm plus the nitro over-rev,
## smoothed. display_rpm_ratio can go above 1.0 when over-revving.
var display_rpm: float = 1000.0
var display_rpm_ratio: float = 0.0

@export_group("Gearing")
## Drives RPM timing - how quickly each gear climbs to its shift point.
## Ratios should decrease from 1st gear to top gear.
@export var gear_ratios: Array[float] = [3.8, 2.5, 1.9, 1.5, 1.2, 0.85]
## Drives actual force output per gear - kept as a separate, much more
## modest spread than gear_ratios above so low gears feel punchier
## without being explosive. One entry per gear.
@export var gear_torque_multipliers: Array[float] = [
	1.5, 1.3, 1.15, 1.05, 1.0, 0.95
]
@export var reverse_gear_ratio: float = 3.2
@export var reverse_torque_multiplier: float = 1.0
@export var final_drive: float = 3.9
@export var idle_rpm: float = 1000.0
@export var redline_rpm: float = 8000.0
@export var shift_up_rpm: float = 7400.0
@export var shift_down_rpm: float = 3200.0
@export var gear_shift_cooldown_time: float = 0.3

## When true, gears only change via controller.is_upshifting() /
## is_downshifting() - set the player's upshift-playerN / downshift-playerN
## input actions for this to do anything. When false (default), gears
## shift automatically based on RPM as before.
@export var manual_transmission: bool = false

@export_group("Drift/RPM Interaction")
## How much rear grip is reduced at high RPM, representing wheelspin
## under heavy power - 0 disables this entirely. Combined with
## max_grip_force_coefficient and drift_torque_smoothing elsewhere, this
## makes revving hard more likely to break the rear loose without ever
## producing an instant, uncontrollable spin.
@export var drift_rpm_traction_loss: float = 0.35
@export var min_rpm_traction_factor: float = 0.6

var current_gear: int = 1
var is_reversing: bool = false
var is_neutral: bool = false
var engine_rpm: float = 1000.0
var rpm_ratio: float = 0.0
var _gear_shift_cooldown: float = 0.0

@export_group("Launch Control")
## Hold accelerate and decelerate together (while stopped) to rev the
## engine up to this RPM without moving - release decelerate while still
## holding accelerate to launch from that RPM instead of idle.
@export var launch_control_rpm: float = 4500.0
@export var launch_control_speed_threshold: float = 2.0
@export var launch_control_rev_rate: float = 6000.0
@export var launch_boost_duration: float = 0.4
@export var launch_boost_multiplier: float = 1.4

var is_launch_control_active: bool = false
var _launch_boost_timer: float = 0.0

@export_group("Reset")
## How long the reset key must be held before it does a full respawn back
## at the car's starting position, instead of just the normal in-place
## reset (which still happens immediately on every press either way).
@export var respawn_hold_duration: float = 0.6

var _spawn_transform: Transform3D
var _reset_hold_time: float = 0.0
var _has_triggered_hold_respawn: bool = false

@export_group("Drift initiation")
@export var drift_min_speed: float = 6.0
@export var drift_min_steering: float = 0.78
@export var drift_start_angle: float = 8.0
@export var initiation_duration: float = 0.3

@export_group("Drift control")
@export var drift_yaw_strength: float = 3.5
@export var drift_countersteer_strength: float = 1.8
@export var drift_max_angle: float = 65.0
@export var drift_recovery_angle: float = 8.0

## How quickly the drift's yaw torque ramps toward its target strength
## each second, instead of jumping straight to full strength the moment
## the handbrake or a sharp countersteer is applied. Lower = more gradual,
## less snappy; higher = more immediate response.
@export var drift_torque_smoothing: float = 6.0

@export_group("Drift Handling")
## How strongly the car is helped to hold the drift angle your steering
## asks for. 0 = no help (pure tire physics), 1 = full help. This is what
## makes the same steering input give the same angle every time.
@export_range(0.0, 1.0) var drift_assist: float = 1.0
## Drifting needs countersteer (front wheels turned away from the
## corner, toward the slide). These set where the car settles depending
## on how far the front wheels are countersteered:
## - none (wheels straight): the tail keeps coming round toward this
##   angle - far enough to spin out if you don't catch it,
## - full countersteer: settles at this angle, i.e. straightens out.
## In between holds a drift - around 60% countersteer holds ~45°.
@export var drift_no_countersteer_angle: float = 120.0
@export var drift_full_countersteer_angle: float = 0.0
## Steering INTO the corner mid-drift whips the tail round toward this.
@export var drift_steer_into_angle: float = 150.0
## For this long after a drift starts (seconds), the angle is limited to
## drift_entry_max_angle, giving time to get the countersteer in.
@export var drift_entry_grace: float = 0.6
@export var drift_entry_max_angle: float = 45.0
## Off the throttle, the target angle shrinks to this fraction - so
## lifting straightens the car out, and throttle swings the tail out.
@export var drift_off_throttle_angle_scale: float = 0.45
## How hard the assist pulls the angle toward the target (N·m per degree)
## and how much it resists the angle changing too fast (N·m per °/s).
@export var drift_assist_strength: float = 14.0
@export var drift_assist_damping: float = 14.0
@export var drift_assist_max_torque: float = 1000.0
## Builds up extra push the longer the angle stays off target, so the
## car actually reaches the angle you're asking for instead of settling
## short of it where the tires push back.
@export var drift_assist_integral: float = 8.0
@export var drift_assist_max_integral_torque: float = 400.0
## How much sideways force the rear tires can make once they're sliding,
## as a multiple of the weight on them (a friction coefficient). On the
## throttle it drops from low RPM to redline, so revs still break the
## tail loose more easily.
@export var drift_rear_grip_low_rpm: float = 1.2
@export var drift_rear_grip_high_rpm: float = 1.0
## The same off the throttle - grip comes back, so lifting lets the car
## recover instead of carrying on sliding.
@export var drift_rear_grip_off_throttle: float = 1.6
## The front tires' friction limit while drifting. A bit above the rear
## so the front keeps steering authority, but limited so it can't drag
## the nose round faster than the rear can follow.
@export var drift_front_friction: float = 1.3
## How fast rear grip blends between the two (per second), so tapping the
## throttle on a keyboard doesn't make the grip jump around.
@export var drift_grip_blend_speed: float = 2.5
## Starting a drift without the handbrake ("power over") needs near full
## lock, throttle, this much speed (m/s) and this fraction of the rev range.
@export var power_over_min_steering: float = 0.95
@export var power_over_min_speed: float = 12.0
@export var power_over_min_rpm: float = 0.5
## A drift lasts at least this long before it can end on its own.
@export var drift_min_duration: float = 0.5
## Speed lost while drifting, in m/s per second at a fully sideways
## slide (it scales with the angle). Sliding sideways has to cost some
## speed, otherwise the car just keeps accelerating through a drift.
@export var drift_speed_scrub: float = 9.0

var _drift_rear_grip_current: float = 0.5
var _drift_angle_sign: float = 0.0
var _drift_prev_angle: float = 0.0
var _drift_time: float = 0.0
var _drift_integral: float = 0.0
# Steering lock available at the current speed, kept so the drift can
# read how far the front wheels are actually turned as a 0-1 amount.
var _current_max_steer_degrees: float = 60.0

var _drift_torque_current: float = 0.0

@export_group("Effects")

@export_group("Air Nitro")
## Nitro also works in the air, rocket-car style: a strong push the way the
## car is facing (so yawing or pitching then boosting sends you that way),
## plus lift, so you can glide, climb, or fly across gaps.
@export var air_nitro_enabled: bool = true
## Push along the car's facing while boosting in the air (m/s per second).
@export var air_boost_thrust: float = 30.0
## Constant lift while boosting, as a fraction of gravity.
@export var air_boost_lift: float = 0.45
## While boosting, falling is slowed to at most this speed (m/s) - the
## glide.
@export var air_boost_max_fall_speed: float = 4.0
## Most upward push thrust plus lift can give, as a fraction of gravity.
## Above 1.0 means pointing the nose up and boosting climbs. How far is
## limited by the nitro tank, since it doesn't refill in the air. Set it
## below 1.0 if you only want air nitro to glide, never climb.
@export var air_boost_max_lift: float = 2.4
## Air boost stops adding speed past this (km/h).
@export var air_boost_max_speed: float = 380.0
## Nitro used per second while boosting in the air.
@export var air_boost_drain_rate: float = 40.0
## Must be airborne this long (seconds) before air nitro kicks in, so
## cresting a bump while boosting on the ground doesn't trigger it.
@export var air_boost_delay: float = 0.12

var _airborne_time: float = 0.0
var is_air_boosting: bool = false
# Set when the tank runs dry while boost is held - the key has to be let go
# and pressed again, otherwise the slow refill keeps re-triggering tiny
# stuttering boosts (and the nitro sound) while the key is still held.
var _nitro_needs_release: bool = false

@export_group("Air Control")
@export var air_pitch_strength: float = 5.0
@export var air_yaw_strength: float = 4.0
@export var air_roll_strength: float = 4.0
@export var air_control_speed: float = 10.0



@export var controller: PlayerController
## Old standalone speed label. The dashboard (GearHud) shows speed now;
## this is only used if a scene still has the old label.
@onready var speedometer: Label = get_node_or_null("Control/SpeedLabel")
@onready var trick_label: Label = $"../CenterContainer/Label"
@onready var score_label: Label = $"../ScoreContainer/ScoreLabel"




@export_group("Speed Effect")
## Speed (km/h) where the speed effect starts, and where it's at full
## strength. Nitro pushes it further on top of this.
@export var speed_effect_start := 60.0
@export var speed_effect_full := 200.0
@export var speed_effect_smoothing := 4.0
## How quickly the nitro part of the effect kicks in and fades out.
@export var speed_effect_boost_smoothing := 6.0

@export var speed_effect: ColorRect

var speed_effect_strength := 0.0
## 0-1, how much of the nitro version of the effect is showing. Read by
## the camera for its FOV kick and shake too.
var speed_effect_boost := 0.0




var motor_input: int = 0
var hand_brake: bool = false

var is_slipping: bool = false
var is_drifting: bool = false
var is_initiating_drift: bool = false

var drift_direction: float = 0.0
var initiation_timer: float = 0.0

@export_group("Air Tricks")
@export var flip_detection_enabled: bool = true
@export var minimum_flip_angle: float = 300.0

var was_airborne: bool = false
var frontflip_rotation: float = 0.0
var backflip_rotation: float = 0.0
var trick_label_timer: float = 0.0

@export var score_per_flip: int = 100

var score: int = 0

# Caches so per-frame updates only happen when something actually changed.
var _com_grounded_state: bool = true
var _last_displayed_speed: int = -1
var _last_speed_effect_strength: float = -1.0
var _last_speed_effect_boost: float = -1.0




func _ready() -> void:
	total_wheels = maxi(total_wheels, 1)

	score = 0
	score_label.text = str(score)

	nitro = nitro_capacity

	_spawn_transform = global_transform

	_setup_anti_roll_axles()
	_setup_tire_smoke()
	_setup_tire_marks()
	_setup_nitro_sound()
	_setup_car_lights()

	var world := get_tree().current_scene

	if controler.player_id == 1:
		var username_label: Label = world.get_node(
			"GridContainer/SubViewportContainer/SubViewport/UsernameLabel"
		)
		username_label.text = GameState.car1_username

	elif controler.player_id == 2:
		var username_label: Label = world.get_node(
			"GridContainer/SubViewportContainer2/SubViewport/UsernameLabel"
		)
		username_label.text = GameState.car2_username
	

func _update_speed_effect(delta: float) -> void:
	var velocity := linear_velocity

	# Ignore vertical velocity from flips/jumps
	velocity.y = 0.0

	var speed_kmh := velocity.length() * 3.6

	var target_strength := clampf(
		inverse_lerp(
			speed_effect_start,
			speed_effect_full,
			speed_kmh
		),
		0.0,
		1.0
	)

	# Ease in, so it builds gently at first and ramps up hard near the top.
	target_strength = target_strength * target_strength * (3.0 - 2.0 * target_strength)

	speed_effect_strength = lerpf(
		speed_effect_strength,
		target_strength,
		minf(1.0, delta * speed_effect_smoothing)
	)

	var target_boost: float = 1.0 if is_boosting else 0.0

	speed_effect_boost = lerpf(
		speed_effect_boost,
		target_boost,
		minf(1.0, delta * speed_effect_boost_smoothing)
	)

	if speed_effect == null:
		return

	# Fully hidden when slow, so it costs nothing at all.
	var active: bool = (
		speed_effect_strength > 0.005
		or speed_effect_boost > 0.005
	)

	if speed_effect.visible != active:
		speed_effect.visible = active

	if not active:
		return

	if (
		absf(speed_effect_strength - _last_speed_effect_strength) < 0.002
		and absf(speed_effect_boost - _last_speed_effect_boost) < 0.002
	):
		return

	_last_speed_effect_strength = speed_effect_strength
	_last_speed_effect_boost = speed_effect_boost

	var material := speed_effect.material as ShaderMaterial

	if material:
		material.set_shader_parameter("strength", speed_effect_strength)
		material.set_shader_parameter("boost", speed_effect_boost)


## Builds one smoke emitter per driven (rear) wheel. Made in code from
## the "Tire Smoke" settings rather than placed in the scene, so tuning
## the look happens in one place for all wheels.
func _setup_tire_smoke() -> void:
	if not tire_smoke_enabled:
		return

	var process_material := _build_smoke_process_material()
	var draw_mesh := _build_smoke_mesh()

	for wheel in wheels:
		if wheel == null or wheel.is_steer:
			continue

		var smoke := GPUParticles3D.new()
		smoke.name = "TireSmoke_" + wheel.name

		smoke.amount = tire_smoke_amount
		smoke.lifetime = tire_smoke_lifetime
		smoke.emitting = false
		smoke.process_material = process_material
		smoke.draw_pass_1 = draw_mesh

		# Particles live in the world, so smoke stays behind as a trail
		# instead of following the car around.
		smoke.local_coords = false
		smoke.draw_order = GPUParticles3D.DRAW_ORDER_VIEW_DEPTH
		smoke.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

		# Big enough to cover a trail drifting away from the emitter, so
		# the smoke isn't culled while it's still visible.
		smoke.visibility_aabb = AABB(
			Vector3(-20.0, -6.0, -20.0),
			Vector3(40.0, 26.0, 40.0)
		)

		# Positioned directly in world space every frame.
		smoke.top_level = true

		add_child(smoke)

		_tire_smoke[wheel] = smoke


func _setup_tire_marks() -> void:
	if not tire_marks_enabled:
		return

	for wheel in wheels:
		if wheel == null or wheel.is_steer:
			continue

		var trail := SkidTrail.new()
		trail.name = "TireMarks_" + wheel.name
		trail.lifetime = tire_mark_lifetime
		trail.fade_time = minf(5.0, tire_mark_lifetime * 0.5)
		trail.mark_color = tire_mark_color
		trail.max_opacity = tire_mark_opacity

		add_child(trail)

		_tire_marks[wheel] = trail


func _update_tire_marks(wheel: RaycastWheel) -> void:
	var trail: SkidTrail = _tire_marks.get(wheel)

	if trail == null:
		return

	var intensity: float = _get_rear_slip_intensity(wheel)

	if intensity < 0.05:
		trail.end_strip()
		return

	var normal: Vector3 = wheel.get_collision_normal()

	# Marks run the way the tire is actually travelling, which in a
	# drift is the car's direction of travel, not the way it's facing.
	var direction: Vector3 = linear_velocity

	if direction.length_squared() < 1.0:
		direction = -global_basis.z

	var sideways: float = clampf(absf(_get_drift_angle()) / 60.0, 0.0, 1.0)

	trail.add_point(
		wheel.get_collision_point() + normal * 0.02,
		normal,
		direction,
		intensity,
		sideways
	)


func _build_smoke_process_material() -> ParticleProcessMaterial:
	var material := ParticleProcessMaterial.new()

	material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	material.emission_sphere_radius = 0.25

	material.direction = Vector3(0.0, 1.0, 0.0)
	material.spread = 55.0
	material.initial_velocity_min = 0.8
	material.initial_velocity_max = 2.2

	# Light, slow-rising smoke that quickly loses its initial push.
	material.gravity = Vector3(0.0, 0.7, 0.0)
	material.damping_min = 1.5
	material.damping_max = 2.5

	material.angle_min = 0.0
	material.angle_max = 360.0
	material.angular_velocity_min = -35.0
	material.angular_velocity_max = 35.0

	material.scale_min = 0.8 * tire_smoke_size
	material.scale_max = 1.4 * tire_smoke_size

	# Puffs start small at the tire and billow out as they age.
	var scale_curve := Curve.new()
	scale_curve.max_value = 3.0
	scale_curve.add_point(Vector2(0.0, 0.5))
	scale_curve.add_point(Vector2(0.35, 1.8))
	scale_curve.add_point(Vector2(1.0, 3.0))

	var scale_texture := CurveTexture.new()
	scale_texture.curve = scale_curve
	material.scale_curve = scale_texture

	# Quick fade in, long soft fade out.
	var gradient := Gradient.new()
	var base := tire_smoke_color

	gradient.offsets = PackedFloat32Array([0.0, 0.08, 0.45, 1.0])
	gradient.colors = PackedColorArray([
		Color(base.r, base.g, base.b, 0.0),
		Color(base.r, base.g, base.b, 0.55),
		Color(base.r * 0.92, base.g * 0.92, base.b * 0.92, 0.32),
		Color(base.r * 0.85, base.g * 0.85, base.b * 0.85, 0.0),
	])

	var color_texture := GradientTexture1D.new()
	color_texture.gradient = gradient
	material.color_ramp = color_texture

	# Gentle swirling so the trail looks like smoke, not a row of discs.
	material.turbulence_enabled = true
	material.turbulence_noise_strength = 0.6
	material.turbulence_noise_scale = 2.5
	material.turbulence_influence_min = 0.05
	material.turbulence_influence_max = 0.15

	return material


func _build_smoke_mesh() -> QuadMesh:
	# Soft round puff generated in code - no image file needed.
	var puff_gradient := Gradient.new()
	puff_gradient.offsets = PackedFloat32Array([0.0, 0.45, 1.0])
	puff_gradient.colors = PackedColorArray([
		Color(1, 1, 1, 1.0),
		Color(1, 1, 1, 0.55),
		Color(1, 1, 1, 0.0),
	])

	var puff_texture := GradientTexture2D.new()
	puff_texture.gradient = puff_gradient
	puff_texture.fill = GradientTexture2D.FILL_RADIAL
	puff_texture.fill_from = Vector2(0.5, 0.5)
	puff_texture.fill_to = Vector2(1.0, 0.5)
	puff_texture.width = 64
	puff_texture.height = 64

	var draw_material := StandardMaterial3D.new()
	draw_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	draw_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	draw_material.vertex_color_use_as_albedo = true
	draw_material.albedo_texture = puff_texture
	draw_material.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	draw_material.billboard_keep_scale = true

	# Soft particles: puffs fade out where they meet the ground instead
	# of showing a hard straight edge.
	draw_material.proximity_fade_enabled = true
	draw_material.proximity_fade_distance = 0.6

	var mesh := QuadMesh.new()
	mesh.size = Vector2(1.0, 1.0)
	mesh.material = draw_material

	return mesh


## How hard a rear tire is sliding right now, 0-1. Shared by the tire
## smoke and tire marks so they always agree with each other.
func _get_rear_slip_intensity(wheel: RaycastWheel) -> float:
	if not wheel.is_colliding():
		return 0.0

	var speed_kmh: float = linear_velocity.length() * 3.6

	var intensity: float = 0.0

	if is_drifting and wheel.grip_factor > 0.12:
		# Harder slides and higher speeds mean a harder-working tire.
		var slide: float = clampf(
			inverse_lerp(0.12, 0.55, wheel.grip_factor),
			0.25,
			1.0
		)

		var pace: float = clampf(speed_kmh / 40.0, 0.4, 1.0)

		intensity = slide * pace

	# Any other big slide too - a spin, or a locked handbrake.
	elif wheel.grip_factor > 0.3 and speed_kmh > 15.0:
		intensity = clampf(inverse_lerp(0.3, 0.8, wheel.grip_factor), 0.3, 1.0)

	# Only once actually launching - while launch control is still
	# being held, the rear wheels are held too and don't slip.
	if (
		tire_smoke_on_launch
		and not is_launch_control_active
		and _launch_boost_timer > 0.0
		and motor_input > 0
	):
		intensity = maxf(intensity, 0.8)

	return intensity


func _update_tire_smoke(wheel: RaycastWheel) -> void:
	var smoke: GPUParticles3D = _tire_smoke.get(wheel)

	if smoke == null:
		return

	var intensity: float = _get_rear_slip_intensity(wheel)

	if wheel.is_colliding():
		smoke.global_position = (
			wheel.get_collision_point() +
			Vector3.UP * 0.25
		)

	if intensity > 0.01:
		# amount_ratio scales how many puffs are emitted without
		# restarting the effect - only pushed when it really changes.
		if absf(smoke.amount_ratio - intensity) > 0.05:
			smoke.amount_ratio = intensity

		if not smoke.emitting:
			smoke.emitting = true

	elif smoke.emitting:
		smoke.emitting = false


## Builds up a drift combo while the car is genuinely sliding, banks it
## into the score once the combo ends cleanly, or throws it away if the
## driver spins out, crashes, resets or lands in the sea.
func _update_drift_score(delta: float, grounded: bool) -> void:
	var horizontal_velocity: Vector3 = linear_velocity
	horizontal_velocity.y = 0.0

	var speed: float = horizontal_velocity.length()

	var deceleration: float = 0.0

	if delta > 0.0:
		deceleration = (_drift_prev_speed - speed) / delta

	_drift_prev_speed = speed

	if not drift_score_enabled:
		return

	var angle: float = absf(_get_drift_angle())

	if _drift_fail_lockout:
		if not is_drifting:
			_drift_fail_lockout = false

		return

	if _drift_combo_active:
		if angle > drift_spin_out_angle and speed > 3.0:
			_fail_drift_combo("SPUN OUT")
			return

		if deceleration > drift_crash_deceleration:
			_fail_drift_combo("CRASHED")
			return

	var scoring: bool = (
		is_drifting
		and grounded
		and angle >= drift_score_min_angle
		and speed >= drift_min_speed
	)

	if scoring:
		if not _drift_combo_active:
			_drift_combo_active = true
			_drift_points = 0.0
			_drift_multiplier = 1
			_drift_multiplier_timer = 0.0

		_drift_chain_timer = drift_chain_window

		var angle_factor: float = clampf(
			angle / drift_score_full_angle,
			0.0,
			1.5
		)

		var speed_factor: float = clampf(
			(speed * 3.6) / drift_score_reference_speed,
			0.3,
			2.0
		)

		_drift_points += (
			drift_points_per_second *
			angle_factor *
			speed_factor *
			delta
		)

		_drift_multiplier_timer += delta

		if (
			_drift_multiplier_timer >= drift_multiplier_interval
			and _drift_multiplier < drift_max_multiplier
		):
			_drift_multiplier += 1
			_drift_multiplier_timer -= drift_multiplier_interval

	elif _drift_combo_active and grounded:
		# The chain window only counts down on the ground, so a drift into
		# a jump and straight back into a drift on landing keeps the combo.
		_drift_chain_timer -= delta

		if _drift_chain_timer <= 0.0:
			_bank_drift_combo()
			return

	_update_drift_label()


## What the current combo would add to the score if banked now, with the
## soft cap applied.
func _get_drift_combo_value() -> int:
	var raw: float = _drift_points * _drift_multiplier

	if drift_combo_soft_cap <= 0.0:
		return roundi(raw)

	return roundi(
		drift_combo_soft_cap * (1.0 - exp(-raw / drift_combo_soft_cap))
	)


func _bank_drift_combo() -> void:
	if not _drift_combo_active:
		return

	var total: int = _get_drift_combo_value()

	if total >= drift_min_bank_points:
		score += total
		score_label.text = str(score)

		show_trick_message(
			"DRIFT x" + str(_drift_multiplier) +
			"  +" + str(total)
		)

	_clear_drift_combo()


func _fail_drift_combo(reason: String) -> void:
	if not _drift_combo_active:
		return

	if _get_drift_combo_value() >= drift_min_bank_points:
		show_trick_message("DRIFT LOST - " + reason)

	_drift_fail_lockout = is_drifting

	_clear_drift_combo()


func _clear_drift_combo() -> void:
	_drift_combo_active = false
	_drift_points = 0.0
	_drift_multiplier = 1
	_drift_multiplier_timer = 0.0
	_drift_chain_timer = 0.0

	_update_drift_label()


func _update_drift_label() -> void:
	if drift_label == null:
		return

	var text: String = ""

	if _drift_combo_active:
		# Shows what the combo is worth if banked right now.
		text = (
			"DRIFT  +" + str(_get_drift_combo_value()) +
			"  x" + str(_drift_multiplier)
		)

	if text == _last_drift_label_text:
		return

	_last_drift_label_text = text
	drift_label.text = text
	drift_label.visible = text != ""


## Sorts the wheels into a front and rear axle, each as [left, right],
## based on which wheels steer and where they sit on the car.
func _setup_anti_roll_axles() -> void:
	var front: Array[RaycastWheel] = []
	var rear: Array[RaycastWheel] = []

	for wheel in wheels:
		if wheel == null:
			continue

		if wheel.is_steer:
			front.append(wheel)
		else:
			rear.append(wheel)

	var by_side := func(a: RaycastWheel, b: RaycastWheel) -> bool:
		return a.position.x < b.position.x

	front.sort_custom(by_side)
	rear.sort_custom(by_side)

	if front.size() == 2:
		_front_axle = front

	if rear.size() == 2:
		_rear_axle = rear


func _apply_anti_roll() -> void:
	_apply_axle_anti_roll(_front_axle, front_anti_roll)
	_apply_axle_anti_roll(_rear_axle, rear_anti_roll)


func _apply_axle_anti_roll(
	axle: Array[RaycastWheel],
	stiffness: float
) -> void:
	if axle.size() != 2 or stiffness <= 0.0:
		return

	var left: RaycastWheel = axle[0]
	var right: RaycastWheel = axle[1]

	# The bar only does anything while both wheels are on the ground to
	# push against - with one wheel in the air there's nothing to twist.
	if not left.is_grounded or not right.is_grounded:
		return

	var bar_force: float = (
		(left.compression - right.compression) *
		stiffness
	)

	var up: Vector3 = global_basis.y

	# The more-compressed side gets pushed up, the less-compressed side
	# gets pulled down, which flattens out the body roll.
	apply_force(
		up * bar_force,
		left.hub_position - global_position
	)

	apply_force(
		-up * bar_force,
		right.hub_position - global_position
	)


func _reset_car() -> void:
	_fail_drift_combo("RESET")

	var current_position := global_position
	var current_yaw := global_rotation.y

	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO

	global_position = current_position
	global_rotation = Vector3(0.0, current_yaw, 0.0)


func respawn_at(new_position: Vector3, face_direction: Vector3 = Vector3.ZERO) -> void:
	_fail_drift_combo("IN THE SEA")

	global_position = new_position

	if face_direction.length_squared() > 0.01:
		# Car forward is -Z, so face_direction maps to this yaw.
		global_rotation = Vector3(0.0, atan2(-face_direction.x, -face_direction.z), 0.0)

	_reset_car()


## Full respawn back to exactly where the car started the level, facing
## the same way it originally did.
func _respawn_at_start() -> void:
	_fail_drift_combo("RESET")

	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO

	global_transform = _spawn_transform


## A tap of the reset key does the normal in-place reset, immediately,
## every time. Holding it past respawn_hold_duration additionally sends
## the car all the way back to its starting position.
func _handle_reset_input(delta: float) -> void:
	var reset_action: String = controller.get_action("reset")

	if Input.is_action_just_pressed(reset_action):
		_reset_car()
		_reset_hold_time = 0.0
		_has_triggered_hold_respawn = false

	if Input.is_action_pressed(reset_action):
		_reset_hold_time += delta

		if (
			not _has_triggered_hold_respawn
			and _reset_hold_time >= respawn_hold_duration
		):
			_has_triggered_hold_respawn = true
			_respawn_at_start()
	else:
		_reset_hold_time = 0.0
		_has_triggered_hold_respawn = false


## Simulates gears/RPM from the car's actual speed. current_gear and
## rpm_ratio are read directly by raycast_wheel.gd's engine force
## calculation, so shifting gears genuinely changes how hard the car
## accelerates - this isn't just a cosmetic number.
func _update_gearing(delta: float) -> void:
	if _gear_shift_cooldown > 0.0:
		_gear_shift_cooldown -= delta

	if _launch_boost_timer > 0.0:
		_launch_boost_timer -= delta

	var wheel_radius: float = 0.4

	if wheels.size() > 0 and wheels[0] != null:
		wheel_radius = wheels[0].wheel_radius

	var wheel_circumference: float = TAU * wheel_radius

	var holding_launch_control: bool = (
		controller.is_accelerating()
		and controller.is_decelerating()
		and linear_velocity.length() < launch_control_speed_threshold
	)

	if holding_launch_control:
		is_launch_control_active = true
		is_reversing = false
		is_neutral = false
		current_gear = 1

		engine_rpm = move_toward(
			engine_rpm,
			launch_control_rpm,
			launch_control_rev_rate * delta
		)

		rpm_ratio = inverse_lerp(idle_rpm, redline_rpm, engine_rpm)

		# Keeps the launch boost primed for the moment decelerate is
		# released - it decays on its own timer once actually launched.
		_launch_boost_timer = launch_boost_duration

		return

	if is_launch_control_active:
		# Decelerate was just released while still flooring the gas -
		# this is the launch. is_launch_control_active drops, and the
		# primed _launch_boost_timer carries the RPM's torque advantage
		# into the next few frames of real acceleration.
		is_launch_control_active = false

	var forward_speed: float = -global_basis.z.dot(linear_velocity)

	# Only actually reversing once nearly stopped (or already rolling
	# backward) while holding decelerate - otherwise that input is just
	# braking while still moving forward.
	is_reversing = motor_input < 0 and forward_speed <= 1.0

	if is_reversing:
		is_neutral = false
		current_gear = 0

		var reverse_total_ratio: float = (
			reverse_gear_ratio * final_drive
		)

		var reverse_wheel_rpm: float = (
			(absf(forward_speed) / wheel_circumference) * 60.0
		)

		engine_rpm = clampf(
			idle_rpm + reverse_wheel_rpm * reverse_total_ratio,
			idle_rpm,
			redline_rpm
		)

		rpm_ratio = inverse_lerp(idle_rpm, redline_rpm, engine_rpm)

		return

	if current_gear < 1:
		current_gear = 1

	var speed: float = linear_velocity.length()

	var wheel_rpm: float = (speed / wheel_circumference) * 60.0

	var total_ratio: float = (
		gear_ratios[current_gear - 1] *
		final_drive
	)

	engine_rpm = clampf(
		idle_rpm + wheel_rpm * total_ratio,
		idle_rpm,
		redline_rpm
	)

	rpm_ratio = inverse_lerp(idle_rpm, redline_rpm, engine_rpm)

	# The transmission reads as "neutral" whenever RPM has settled back
	# to idle - in this model that only happens when the car is stopped
	# and off the throttle, same as a real automatic left in gear at a
	# standstill would eventually show close to idle.
	is_neutral = engine_rpm <= idle_rpm + 50.0

	if _gear_shift_cooldown > 0.0:
		return

	if manual_transmission:
		if controller.is_upshifting() and current_gear < gear_ratios.size():
			current_gear += 1
			_gear_shift_cooldown = gear_shift_cooldown_time
		elif controller.is_downshifting() and current_gear > 1:
			current_gear -= 1
			_gear_shift_cooldown = gear_shift_cooldown_time

		return

	if (
		engine_rpm >= shift_up_rpm
		and current_gear < gear_ratios.size()
	):
		current_gear += 1
		_gear_shift_cooldown = gear_shift_cooldown_time
	elif (
		engine_rpm <= shift_down_rpm
		and current_gear > 1
	):
		current_gear -= 1
		_gear_shift_cooldown = gear_shift_cooldown_time


func _setup_car_lights() -> void:
	if not car_lights_enabled:
		return

	_headlight_lens = StandardMaterial3D.new()
	_headlight_lens.albedo_color = Color(0.85, 0.85, 0.8)
	_headlight_lens.emission_enabled = true
	_headlight_lens.emission = headlight_color

	_taillight_lens = StandardMaterial3D.new()
	_taillight_lens.albedo_color = Color(0.45, 0.05, 0.05)
	_taillight_lens.emission_enabled = true
	_taillight_lens.emission = Color(1.0, 0.08, 0.05)

	var lens_mesh := BoxMesh.new()
	lens_mesh.size = Vector3(0.42, 0.16, 0.04)

	for side in [-1.0, 1.0]:
		var head_pos := Vector3(headlight_offset.x * side, headlight_offset.y, headlight_offset.z)

		var spot := SpotLight3D.new()
		spot.name = "Headlight"
		spot.position = head_pos
		# Aimed slightly down at the road ahead.
		spot.rotation_degrees = Vector3(-6.0, 0.0, 0.0)
		spot.spot_range = headlight_range
		spot.spot_angle = headlight_angle
		spot.spot_attenuation = 0.6
		spot.light_color = headlight_color
		spot.light_energy = 0.0
		spot.shadow_enabled = false
		add_child(spot)
		_headlights.append(spot)

		var head_lens := MeshInstance3D.new()
		head_lens.mesh = lens_mesh
		head_lens.material_override = _headlight_lens
		head_lens.position = head_pos
		head_lens.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(head_lens)

		var tail_lens := MeshInstance3D.new()
		tail_lens.mesh = lens_mesh
		tail_lens.material_override = _taillight_lens
		tail_lens.position = Vector3(taillight_offset.x * side, taillight_offset.y, taillight_offset.z)
		tail_lens.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(tail_lens)


## Splitscreen: lights fade in on their own as it gets dark.
## Singleplayer: the player toggles them (L), and they fade on/off quickly.
## Taillights follow the headlights and glow brighter while braking.
func _update_car_lights(delta: float) -> void:
	if _headlights.is_empty():
		return

	var level: float

	if GameState.is_singleplayer():
		if InputMap.has_action(headlight_toggle_action) and Input.is_action_just_pressed(headlight_toggle_action):
			_headlights_switched_on = not _headlights_switched_on

		# A one-off reminder the first time it gets dark with the lights off.
		if not _headlight_hint_shown and DayNightCycle.darkness > 0.5 and not _headlights_switched_on:
			_headlight_hint_shown = true
			show_trick_message("PRESS L FOR HEADLIGHTS", 3.0)

		var target: float = 1.0 if _headlights_switched_on else 0.0
		_manual_lights_level = move_toward(_manual_lights_level, target, delta * 8.0)
		level = _manual_lights_level
	else:
		level = smoothstep(0.25, 0.65, DayNightCycle.darkness)
	var braking: float = 1.0 if motor_input < 0 and not is_reversing else 0.0

	var lights_changed: bool = absf(level - _lights_level) > 0.01

	if lights_changed:
		_lights_level = level

		for spot in _headlights:
			spot.light_energy = headlight_energy * level
			spot.visible = level > 0.01

		_headlight_lens.emission_energy_multiplier = 3.0 * level

	if lights_changed or braking != _brake_level:
		_brake_level = braking
		# Off by day unless braking; dim by night, bright when braking.
		_taillight_lens.emission_energy_multiplier = (
			maxf(level * 1.5, braking * 4.0) if level > 0.01
			else braking * 1.5
		)


func _setup_nitro_sound() -> void:
	if not nitro_sounds_enabled:
		return

	_nitro_start_player = AudioStreamPlayer.new()
	_nitro_start_player.name = "NitroStartSound"
	_nitro_start_player.stream = nitro_start_sound
	_nitro_start_player.volume_db = nitro_sound_volume_db
	add_child(_nitro_start_player)

	# Make the hiss loop seamlessly (the file is built to join up exactly).
	var loop_stream := nitro_loop_sound
	var wav := loop_stream as AudioStreamWAV

	if wav != null:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = int(wav.get_length() * wav.mix_rate)

	_nitro_loop_player = AudioStreamPlayer.new()
	_nitro_loop_player.name = "NitroLoopSound"
	_nitro_loop_player.stream = loop_stream
	_nitro_loop_player.volume_db = -80.0
	add_child(_nitro_loop_player)


func _update_nitro_sound(delta: float) -> void:
	if _nitro_loop_player == null:
		return

	_nitro_start_cooldown = maxf(0.0, _nitro_start_cooldown - delta)

	# Burst on the moment nitro kicks in (not re-fired on rapid taps).
	if is_boosting and not _was_boosting_for_sound and _nitro_start_cooldown <= 0.0:
		_nitro_start_player.play()
		_nitro_start_cooldown = 0.25

	_was_boosting_for_sound = is_boosting

	# Hiss fades in fast and out a little slower.
	var target: float = 1.0 if is_boosting else 0.0
	var fade_speed: float = 8.0 if is_boosting else 3.0

	_nitro_loop_level = move_toward(_nitro_loop_level, target, fade_speed * delta)

	if _nitro_loop_level > 0.0:
		if not _nitro_loop_player.playing:
			_nitro_loop_player.play()

		_nitro_loop_player.volume_db = (
			nitro_sound_volume_db + linear_to_db(_nitro_loop_level)
		)

		# Pitch rises a little with speed, and a touch more in the air.
		var speed_factor: float = clampf(linear_velocity.length() * 3.6 / 300.0, 0.0, 1.0)
		_nitro_loop_player.pitch_scale = (
			1.0 + speed_factor * 0.15 + (0.08 if is_air_boosting else 0.0)
		)

	elif _nitro_loop_player.playing:
		_nitro_loop_player.stop()


func _update_display_rpm(delta: float) -> void:
	var target: float = engine_rpm

	if is_boosting:
		var overrev_limit: float = redline_rpm + nitro_overrev_rpm
		target = lerpf(engine_rpm, overrev_limit, nitro_rev_push)

	var rate: float = (
		display_rpm_rise_rate if target > display_rpm
		else display_rpm_fall_rate
	)

	display_rpm = move_toward(display_rpm, target, rate * delta)
	display_rpm_ratio = inverse_lerp(idle_rpm, redline_rpm, display_rpm)


## Extra force multiplier while a primed launch is still playing out,
## giving the car the RPM's torque advantage for a brief moment right as
## it takes off from a launch-control hold, instead of starting from idle.
func get_launch_boost_multiplier() -> float:
	if _launch_boost_timer > 0.0:
		return launch_boost_multiplier

	return 1.0


## The force multiplier for whatever gear is currently engaged, used by
## raycast_wheel.gd's engine force calculation.
func get_current_gear_torque_multiplier() -> float:
	if is_reversing:
		return reverse_torque_multiplier

	return gear_torque_multipliers[current_gear - 1]


## How much rear-wheel grip should be scaled by right now, based on RPM -
## full grip near idle, reduced (down to min_rpm_traction_factor) near
## redline, representing wheelspin under heavy power.
func get_rpm_traction_factor() -> float:
	return maxf(
		min_rpm_traction_factor,
		1.0 - rpm_ratio * drift_rpm_traction_loss
	)


func _update_speedometer() -> void:
	if speedometer == null:
		return

	var velocity := linear_velocity
	
	
	
	var speed_kmh := velocity.length() * 3.6

	var rounded_speed: int = roundi(speed_kmh)

	# Changing a Label's text makes it re-layout, so only do it when the
	# displayed number actually changes.
	if rounded_speed != _last_displayed_speed:
		_last_displayed_speed = rounded_speed
		speedometer.text = str(rounded_speed)




func _get_point_velocity(point: Vector3) -> Vector3:
	return (
		linear_velocity +
		angular_velocity.cross(point - global_position)
	)


func _update_inputs() -> void:
	if controller.is_accelerating():
		motor_input = 1
	elif controller.is_decelerating():
		motor_input = -1
	else:
		motor_input = 0

	hand_brake = controller.is_handbraking()


func _get_steering_input() -> float:
	return controller.get_steering()


func _basic_steering_rotation(
	wheel: RaycastWheel,
	delta: float
) -> void:

	if not wheel.is_steer:
		return

	var steering_input: float = _get_steering_input()

	var speed: float = linear_velocity.length()

	var speed_factor: float = 1.0 - clampf(
		inverse_lerp(
			steering_speed_falloff_start,
			steering_speed_falloff_end,
			speed
		),
		0.0,
		1.0
	)

	var current_max_turn_degrees: float = lerpf(
		min_steering_angle_degrees,
		tire_max_turn_degrees,
		speed_factor
	)

	_current_max_steer_degrees = current_max_turn_degrees

	var target_angle: float = (
		steering_input *
		deg_to_rad(current_max_turn_degrees)
	)

	var steering_speed: float = tire_turn_speed

	if is_drifting:
		steering_speed *= 1.35

	wheel.rotation.y = move_toward(
		wheel.rotation.y,
		target_angle,
		steering_speed * delta
	)


func _get_drift_angle() -> float:
	var velocity: Vector3 = linear_velocity

	velocity.y = 0.0

	if velocity.length_squared() < 1.0:
		return 0.0

	var forward: Vector3 = -global_basis.z

	forward.y = 0.0
	forward = forward.normalized()

	var velocity_direction: Vector3 = velocity.normalized()

	var angle: float = rad_to_deg(
		acos(
			clampf(
				forward.dot(velocity_direction),
				-1.0,
				1.0
			)
		)
	)

	var side: float = signf(
		global_basis.x.dot(velocity_direction)
	)

	return angle * side


func _begin_drift(direction: float) -> void:
	is_drifting = true
	is_initiating_drift = false
	initiation_timer = 0.0
	drift_direction = direction
	_drift_time = 0.0
	# A drift entered steering one way has a drift angle of the same sign
	# (steering right = -1, nose right of travel = negative angle), so the
	# assist knows which way to swing the car from the first frame.
	_drift_angle_sign = direction
	_drift_prev_angle = _get_drift_angle()
	_drift_rear_grip_current = drift_rear_grip_low_rpm
	_drift_integral = 0.0


func _begin_drift_initiation(direction: float) -> void:
	is_initiating_drift = true
	initiation_timer = initiation_duration
	drift_direction = direction


func _update_drift_state(delta: float) -> void:
	var speed: float = linear_velocity.length()
	var steering: float = _get_steering_input()

	if speed < drift_min_speed:
		is_drifting = false
		is_initiating_drift = false
		drift_direction = 0.0
		initiation_timer = 0.0
		return

	if not is_drifting and not is_initiating_drift:

		if hand_brake and absf(steering) > 0.2:
			_begin_drift(signf(steering))
			return

		# Power over: only with near full lock, on the throttle, at
		# speed and with revs up - an ordinary hard turn stays gripped.
		if (
			absf(steering) >= power_over_min_steering
			and motor_input > 0
			and speed >= power_over_min_speed
			and rpm_ratio >= power_over_min_rpm
		):
			_begin_drift_initiation(signf(steering))
			return

	if is_initiating_drift:

		initiation_timer -= delta

		if absf(steering) < 0.5 and not hand_brake:
			is_initiating_drift = false
			initiation_timer = 0.0
			return

		var drift_angle: float = absf(_get_drift_angle())

		if drift_angle >= drift_start_angle:
			_begin_drift(drift_direction)
			return

		if initiation_timer <= 0.0:
			_begin_drift(drift_direction)
			return

	if is_drifting:

		_drift_time += delta

		var current_angle: float = absf(_get_drift_angle())

		# No more cutting the drift at a maximum angle - grip snapping
		# straight back to full mid-slide is what used to whip the car
		# around. The drift assist keeps the angle in check instead.

		var steering_into: float = steering * drift_direction

		if (
			_drift_time >= drift_min_duration
			and current_angle < drift_recovery_angle
			and steering_into < 0.3
		):
			is_drifting = false
			drift_direction = 0.0


func _apply_drift_control(delta: float) -> void:
	if not is_drifting:
		_drift_torque_current = 0.0
		_drift_integral = 0.0
		return

	var angle: float = _get_drift_angle()

	var angle_rate: float = 0.0

	if delta > 0.0:
		angle_rate = (angle - _drift_prev_angle) / delta

	_drift_prev_angle = angle

	var throttle: float = 1.0 if motor_input > 0 else 0.0

	_update_drift_rear_grip(throttle, delta)

	if drift_assist <= 0.0 or linear_velocity.length() < drift_min_speed:
		_drift_torque_current = 0.0
		return

	# How far the front wheels are actually countersteered (0-1), read
	# from the wheels themselves rather than the raw input - wheels swing
	# over gradually, so tapping a key gives part countersteer too.
	var countersteer: float = -_get_front_steer_fraction() * drift_direction

	var target_angle: float

	if countersteer >= 0.0:
		target_angle = lerpf(
			drift_no_countersteer_angle,
			drift_full_countersteer_angle,
			clampf(countersteer, 0.0, 1.0)
		)
	else:
		target_angle = lerpf(
			drift_no_countersteer_angle,
			drift_steer_into_angle,
			clampf(-countersteer, 0.0, 1.0)
		)

	target_angle *= lerpf(drift_off_throttle_angle_scale, 1.0, throttle)

	if _drift_time < drift_entry_grace:
		target_angle = minf(target_angle, drift_entry_max_angle)

	var error: float = _drift_angle_sign * target_angle - angle

	if drift_assist_integral > 0.0:
		var integral_limit: float = (
			drift_assist_max_integral_torque / drift_assist_integral
		)

		_drift_integral = clampf(
			_drift_integral + error * delta,
			-integral_limit,
			integral_limit
		)

	var target_torque: float = clampf(
		error * drift_assist_strength +
		_drift_integral * drift_assist_integral -
		angle_rate * drift_assist_damping,
		-drift_assist_max_torque,
		drift_assist_max_torque
	) * drift_assist

	_drift_torque_current = move_toward(
		_drift_torque_current,
		target_torque,
		drift_assist_max_torque * 40.0 * delta
	)

	# Positive yaw torque increases the signed drift angle.
	apply_torque(global_basis.y * _drift_torque_current)

	# Scrub off speed in proportion to how sideways the car is.
	if drift_speed_scrub > 0.0:
		var horizontal_velocity: Vector3 = linear_velocity
		horizontal_velocity.y = 0.0

		if horizontal_velocity.length_squared() > 1.0:
			var scrub: float = (
				drift_speed_scrub *
				sin(deg_to_rad(minf(absf(angle), 90.0)))
			)

			apply_central_force(
				-horizontal_velocity.normalized() * scrub * mass
			)


## How far the front wheels are turned right now, -1 to 1 (same sign as
## the steering input), relative to the lock available at this speed.
func _get_front_steer_fraction() -> float:
	var total: float = 0.0
	var count: int = 0

	for wheel in wheels:
		if wheel != null and wheel.is_steer:
			total += rad_to_deg(wheel.rotation.y)
			count += 1

	if count == 0 or _current_max_steer_degrees <= 0.0:
		return 0.0

	return clampf(
		(total / count) / _current_max_steer_degrees,
		-1.0,
		1.0
	)


func _update_drift_rear_grip(throttle: float, delta: float) -> void:
	var on_throttle_grip: float = lerpf(
		drift_rear_grip_low_rpm,
		drift_rear_grip_high_rpm,
		rpm_ratio
	)

	var target_grip: float = lerpf(
		drift_rear_grip_off_throttle,
		on_throttle_grip,
		throttle
	)

	_drift_rear_grip_current = move_toward(
		_drift_rear_grip_current,
		target_grip,
		drift_grip_blend_speed * delta
	)


## Rear tire friction limit while drifting - set by throttle and revs.
func get_drift_rear_grip() -> float:
	return _drift_rear_grip_current

func _apply_air_control(delta: float) -> void:
	var steering: float = _get_steering_input()
	var pitch_input: float = float(motor_input)
	var roll_input: float = controller.get_roll()

	var local_angular_velocity: Vector3 = (
		global_basis.inverse() * angular_velocity
	)

	var target_pitch: float = (
		-pitch_input *
		air_pitch_strength
	)

	local_angular_velocity.x = move_toward(
		local_angular_velocity.x,
		target_pitch,
		air_control_speed * delta
	)

	var target_yaw: float = (
		steering *
		air_yaw_strength
	)

	local_angular_velocity.y = move_toward(
		local_angular_velocity.y,
		target_yaw,
		air_control_speed * delta
	)



	var target_roll: float = (
		roll_input *
		air_roll_strength
	)

	local_angular_velocity.z = move_toward(
		local_angular_velocity.z,
		target_roll,
		air_control_speed * delta
	)

	angular_velocity = (
		global_basis *
		local_angular_velocity
	)

## Nitro in the air: thrust along the car's facing, plus lift and a capped
## fall speed so the car glides. Pointing the nose up climbs.
func _apply_air_boost() -> void:
	var gravity: float = absf(get_gravity().y)

	var thrust: Vector3 = -global_basis.z * air_boost_thrust

	# Stop adding speed once fast enough.
	var speed_kmh: float = linear_velocity.length() * 3.6
	thrust *= 1.0 - smoothstep(air_boost_max_speed * 0.9, air_boost_max_speed, speed_kmh)

	var lift: float = gravity * air_boost_lift

	# Cap the upward push from thrust and lift together (see
	# air_boost_max_lift).
	var max_up: float = gravity * air_boost_max_lift
	var upward: float = thrust.y + lift

	if upward > max_up:
		thrust.y -= upward - max_up

	var accel: Vector3 = thrust + Vector3.UP * lift

	# Glide: soften a fast fall down toward air_boost_max_fall_speed. Only
	# ever slows falling - it can't make the car rise.
	var falling: float = -linear_velocity.y

	if falling > air_boost_max_fall_speed:
		accel.y += minf((falling - air_boost_max_fall_speed) * 4.0, gravity * 1.5)

	apply_central_force(accel * mass)


func _flips_from_rotation(rotation_amount: float) -> int:
	# A flip counts once its rotation gets within "tolerance" of the next
	# full 360, instead of requiring an exact multiple of 360. This lets
	# slightly-short flips (e.g. 340 degrees) still register, while still
	# needing at least minimum_flip_angle of rotation for the first one.
	var tolerance: float = 360.0 - minimum_flip_angle

	return int(
		(rotation_amount + tolerance) / 360.0
	)

func _update_flip_detection(grounded: bool) -> void:
	if not flip_detection_enabled:
		return

	if not grounded and not was_airborne:
		was_airborne = true
		frontflip_rotation = 0.0
		backflip_rotation = 0.0

		return

	if not grounded and was_airborne:
		var local_angular_velocity: Vector3 = (
			global_basis.inverse() *
			angular_velocity
		)

		var pitch_speed: float = local_angular_velocity.x

		var pitch_degrees_per_second: float = (
			rad_to_deg(pitch_speed)
		)

		var delta_rotation: float = (
			pitch_degrees_per_second *
			get_physics_process_delta_time()
		)

		# Frontflip and backflip rotation are tracked separately (rather
		# than summed into one signed total) so that flipping one way and
		# then the other in the same airtime doesn't cancel out and lose
		# both tricks.
		if delta_rotation < 0.0:
			frontflip_rotation += -delta_rotation
		else:
			backflip_rotation += delta_rotation

	if grounded and was_airborne:
		was_airborne = false

		var completed_frontflips: int = _flips_from_rotation(
			frontflip_rotation
		)

		var completed_backflips: int = _flips_from_rotation(
			backflip_rotation
		)

		if completed_frontflips > 0 or completed_backflips > 0:
			var trick_lines: PackedStringArray = []
			var total_earned_score: int = 0

			# ---------------------------------------------------------
			# FRONTFLIPS
			# ---------------------------------------------------------

			if completed_frontflips > 0:
				var frontflip_score: int = (
					completed_frontflips *
					score_per_flip
				)

				total_earned_score += frontflip_score

				trick_lines.append(
					"FRONTFLIP x" +
					str(completed_frontflips) +
					"  +" +
					str(frontflip_score)
				)

			# ---------------------------------------------------------
			# BACKFLIPS
			# ---------------------------------------------------------

			if completed_backflips > 0:
				var backflip_score: int = (
					completed_backflips *
					score_per_flip
				)

				total_earned_score += backflip_score

				trick_lines.append(
					"BACKFLIP x" +
					str(completed_backflips) +
					"  +" +
					str(backflip_score)
				)

			# ---------------------------------------------------------
			# SCORE
			# ---------------------------------------------------------

			score += total_earned_score

			score_label.text = str(score)

			nitro = minf(nitro_capacity, nitro + nitro_trick_refill)

			# ---------------------------------------------------------
			# TRICK LABEL
			# ---------------------------------------------------------

			show_trick_message("\n".join(trick_lines))

			print(
				trick_label.text,
				" score"
			)

		frontflip_rotation = 0.0
		backflip_rotation = 0.0

func _update_trick_label(delta: float) -> void:
	if not trick_label.visible:
		return

	trick_label_timer -= delta

	if trick_label_timer <= 0.0:
		trick_label.hide()


## Shows a short-lived message in the same on-screen spot as flip tricks
## (e.g. a coin pickup). Reuses the trick label's own show/hide timer.
func show_trick_message(text: String, duration: float = 2.0) -> void:
	trick_label.text = text
	trick_label.show()
	trick_label_timer = duration


func _update_nitro(delta: float) -> void:
	var boost_held: bool = controller.is_boosting()

	if not boost_held:
		_nitro_needs_release = false

	var wants_boost: bool = boost_held and nitro > 0.0 and not _nitro_needs_release

	is_air_boosting = (
		air_nitro_enabled
		and wants_boost
		and not _com_grounded_state
		and _airborne_time >= air_boost_delay
	)

	# On the ground the throttle has to be held too. In the air it
	# doesn't, because throttle pitches the car there.
	is_boosting = is_air_boosting or (wants_boost and motor_input > 0 and _com_grounded_state)

	if is_boosting:
		var drain: float = air_boost_drain_rate if is_air_boosting else nitro_drain_rate
		nitro = maxf(0.0, nitro - drain * delta)

		if nitro <= 0.0:
			_nitro_needs_release = true

		return

	# No passive refill in the air - otherwise holding boost mid-air lets
	# the trickle keep re-triggering it, floating almost forever.
	if not _com_grounded_state:
		return

	var regen_rate: float = nitro_regen_rate

	if is_drifting:
		regen_rate += nitro_drift_refill_rate

	nitro = minf(nitro_capacity, nitro + regen_rate * delta)



func _physics_process(delta: float) -> void:
	_handle_reset_input(delta)

	_update_inputs()
	_update_drift_state(delta)
	_apply_drift_control(delta)
	_update_nitro(delta)
	_update_gearing(delta)
	_update_display_rpm(delta)
	_update_nitro_sound(delta)
	_update_car_lights(delta)
	_update_speedometer()
	_update_speed_effect(delta)
	_update_trick_label(delta)


	var grounded: bool = false

	for id in wheels.size():
		var wheel: RaycastWheel = wheels[id]

		wheel.apply_wheel_physics(self)
		_basic_steering_rotation(wheel, delta)

		_update_tire_smoke(wheel)
		_update_tire_marks(wheel)

		if wheel.is_colliding():
			grounded = true

	_apply_anti_roll()

	_update_flip_detection(grounded)

	_update_drift_score(delta, grounded)

	if grounded:
		_airborne_time = 0.0
	else:
		_airborne_time += delta
		_apply_air_control(delta)

		if is_air_boosting:
			_apply_air_boost()


	# Only touch the center of mass when grounded/airborne actually
	# changes. Setting it makes the physics engine recalculate the car's
	# mass properties, which was happening every single physics frame.
	if grounded != _com_grounded_state:
		_com_grounded_state = grounded

		if grounded:
			center_of_mass_mode = (
				RigidBody3D.CENTER_OF_MASS_MODE_AUTO
			)

			center_of_mass = Vector3.ZERO

		else:
			center_of_mass_mode = (
				RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
			)

			center_of_mass = Vector3.DOWN * 0.5
