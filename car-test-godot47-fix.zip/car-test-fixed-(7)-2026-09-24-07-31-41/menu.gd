extends VBoxContainer


func _ready() -> void:
	print("Menu loaded")


func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://naming.tscn")




func _on_options_pressed() -> void:
	var options: Control = preload("res://options_menu.tscn").instantiate()
	get_tree().current_scene.add_child(options)


func _on_quit_pressed() -> void:
	get_tree().quit()
