extends VBoxContainer
class_name GearHud

## Compact dashboard per player: speed and gear on one line, with thin RPM
## and nitro bars underneath. No background panel - the text is outlined
## so it reads on any terrain while taking up as little screen as possible.

## The car this dashboard shows.
@export var car: RaycastCar

const RPM_COLOR_LOW := Color(0.35, 0.85, 0.45)
const RPM_COLOR_MID := Color(1.0, 0.82, 0.25)
const RPM_COLOR_HIGH := Color(1.0, 0.3, 0.25)
const NITRO_COLOR_NORMAL := Color(0.35, 0.65, 1.0)
const NITRO_COLOR_BOOSTING := Color(1.0, 0.55, 0.15)
const GEAR_BORDER_NORMAL := Color(1.0, 1.0, 1.0, 0.85)

@onready var gear_label: Label = $TopRow/GearBox/GearLabel
@onready var gear_box: PanelContainer = $TopRow/GearBox
@onready var speed_label: Label = $TopRow/SpeedLabel
@onready var rpm_bar: ProgressBar = $RpmBar
@onready var nitro_bar: ProgressBar = $NitroBar
## Optional - the compact layout leaves the RPM number out (the bar's
## colour shows it), but it's shown if a Label is added at this path.
@onready var rpm_label: Label = get_node_or_null("RpmLabel")

# Own copies of the bar fills and the gear box style, so recolouring them
# never touches anything shared with the other player's dashboard.
var _rpm_fill := StyleBoxFlat.new()
var _nitro_fill := StyleBoxFlat.new()
var _gear_style: StyleBoxFlat

var _last_gear_text: String = ""
var _last_speed: int = -1
var _last_rpm: int = -1
var _last_rpm_color := Color.BLACK
var _last_boosting: bool = false
var _last_shift_light: bool = false


func _ready() -> void:
	# Hidden while the detailed gauges are in use (Options > Gauge style).
	GameState.settings_changed.connect(_apply_style)
	_apply_style()

	for fill in [_rpm_fill, _nitro_fill]:
		var f: StyleBoxFlat = fill
		f.corner_radius_top_left = 2
		f.corner_radius_top_right = 2
		f.corner_radius_bottom_right = 2
		f.corner_radius_bottom_left = 2

	_rpm_fill.bg_color = RPM_COLOR_LOW
	_nitro_fill.bg_color = NITRO_COLOR_NORMAL

	rpm_bar.add_theme_stylebox_override("fill", _rpm_fill)
	nitro_bar.add_theme_stylebox_override("fill", _nitro_fill)

	rpm_bar.min_value = 0.0
	rpm_bar.max_value = 1.0
	nitro_bar.min_value = 0.0

	var base_style := gear_box.get_theme_stylebox("panel") as StyleBoxFlat

	if base_style != null:
		_gear_style = base_style.duplicate()
		gear_box.add_theme_stylebox_override("panel", _gear_style)


func _apply_style() -> void:
	visible = not GameState.use_detailed_hud()


func _process(_delta: float) -> void:
	if car == null or not visible:
		return

	# --- Gear ------------------------------------------------------------
	var gear_text: String

	if car.is_reversing:
		gear_text = "R"
	elif car.is_neutral:
		gear_text = "N"
	else:
		gear_text = str(car.current_gear)

	if gear_text != _last_gear_text:
		_last_gear_text = gear_text
		gear_label.text = gear_text

	# --- Speed -----------------------------------------------------------
	var speed: int = roundi(car.linear_velocity.length() * 3.6)

	if speed != _last_speed:
		_last_speed = speed
		speed_label.text = str(speed)

	# --- RPM -------------------------------------------------------------
	# Shown revs include the nitro over-rev.
	rpm_bar.value = car.display_rpm_ratio

	# Rounded to the nearest 50 like a real rev counter.
	var rpm: int = int(round(car.display_rpm / 50.0)) * 50

	if rpm != _last_rpm and rpm_label != null:
		_last_rpm = rpm
		rpm_label.text = str(rpm) + " RPM"

	# Green through the rev range, yellow approaching the shift point,
	# red at it.
	var shift_ratio: float = inverse_lerp(
		car.idle_rpm,
		car.shift_up_rpm,
		car.display_rpm
	)

	# The shift light only follows the real revs, so nitro over-revving
	# doesn't make it flash when no shift is actually due.
	var real_shift_ratio: float = inverse_lerp(
		car.idle_rpm,
		car.shift_up_rpm,
		car.engine_rpm
	)

	var rpm_color: Color

	if shift_ratio < 0.7:
		rpm_color = RPM_COLOR_LOW
	elif shift_ratio < 0.95:
		rpm_color = RPM_COLOR_LOW.lerp(RPM_COLOR_MID, inverse_lerp(0.7, 0.95, shift_ratio))
	else:
		rpm_color = RPM_COLOR_HIGH

	if not rpm_color.is_equal_approx(_last_rpm_color):
		_last_rpm_color = rpm_color
		_rpm_fill.bg_color = rpm_color

	# Gear box outline lights up red as a shift light - mostly useful with
	# the manual gearbox.
	var shift_light: bool = real_shift_ratio >= 0.95 and not car.is_reversing

	if shift_light != _last_shift_light and _gear_style != null:
		_last_shift_light = shift_light
		_gear_style.border_color = RPM_COLOR_HIGH if shift_light else GEAR_BORDER_NORMAL

	# --- Nitro -----------------------------------------------------------
	nitro_bar.max_value = car.nitro_capacity
	nitro_bar.value = car.nitro

	if car.is_boosting != _last_boosting:
		_last_boosting = car.is_boosting
		_nitro_fill.bg_color = (
			NITRO_COLOR_BOOSTING if car.is_boosting
			else NITRO_COLOR_NORMAL
		)
