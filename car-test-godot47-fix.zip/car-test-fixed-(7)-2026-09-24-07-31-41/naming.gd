extends Control


@onready var line_edit_1: LineEdit = $HBoxContainer/LineEdit
@onready var line_edit_2: LineEdit = $HBoxContainer/LineEdit2
@onready var seed_edit: LineEdit = get_node_or_null("VBoxContainer/SeedEdit")
@onready var mode_button: OptionButton = get_node_or_null("Settings/ModeButton")
@onready var timer_toggle: CheckButton = get_node_or_null("Settings/TimerToggle")
@onready var length_label: Label = get_node_or_null("Settings/LengthLabel")
@onready var length_button: OptionButton = get_node_or_null("Settings/LengthButton")

## Round lengths offered, in seconds.
const ROUND_LENGTHS: Array[int] = [30, 60, 120, 180, 300, 600]


func _ready() -> void:
	# Start from whatever was picked last time.
	line_edit_1.text = GameState.car1_username
	line_edit_2.text = GameState.car2_username

	if mode_button != null:
		mode_button.clear()
		mode_button.add_item("Splitscreen", GameState.GameMode.SPLITSCREEN)
		mode_button.add_item("Singleplayer", GameState.GameMode.SINGLEPLAYER)
		mode_button.select(mode_button.get_item_index(GameState.game_mode))
		mode_button.item_selected.connect(_on_settings_changed)

	if timer_toggle != null:
		timer_toggle.button_pressed = GameState.timer_enabled
		timer_toggle.toggled.connect(_on_settings_changed)

	if length_button != null:
		length_button.clear()

		var closest: int = 0

		for i in ROUND_LENGTHS.size():
			length_button.add_item(_length_text(ROUND_LENGTHS[i]), ROUND_LENGTHS[i])

			if absi(ROUND_LENGTHS[i] - GameState.round_length_seconds) < absi(ROUND_LENGTHS[closest] - GameState.round_length_seconds):
				closest = i

		length_button.select(closest)

	_on_settings_changed()


func _length_text(seconds: int) -> String:
	if seconds < 60:
		return str(seconds) + " sec"

	return str(seconds / 60) + " min"


func _is_singleplayer_selected() -> bool:
	return (
		mode_button != null
		and mode_button.get_selected_id() == GameState.GameMode.SINGLEPLAYER
	)


## Hides player 2's name in singleplayer, and greys out the round length
## when the timer is off.
func _on_settings_changed(_value = null) -> void:
	line_edit_2.visible = not _is_singleplayer_selected()

	var timer_on: bool = timer_toggle == null or timer_toggle.button_pressed

	if length_button != null:
		length_button.disabled = not timer_on

	if length_label != null:
		length_label.modulate.a = 1.0 if timer_on else 0.4




func _on_button_pressed() -> void:
	GameState.car1_username = line_edit_1.text
	GameState.car2_username = line_edit_2.text
	GameState.map_seed = _parse_seed()

	if mode_button != null:
		GameState.game_mode = mode_button.get_selected_id() as GameState.GameMode

	if timer_toggle != null:
		GameState.timer_enabled = timer_toggle.button_pressed

	if length_button != null:
		GameState.round_length_seconds = length_button.get_selected_id()
	
	GameState.start_match()


## Blank = random map (0). A number = that exact map. Any other text works
## too (e.g. "rei") - it's turned into a number, so the same word always
## gives the same map.
func _parse_seed() -> int:
	if seed_edit == null:
		return 0

	var text: String = seed_edit.text.strip_edges()

	if text.is_empty():
		return 0

	if text.is_valid_int():
		return maxi(1, absi(text.to_int()) % 1000000)

	return maxi(1, absi(text.hash()) % 1000000)
