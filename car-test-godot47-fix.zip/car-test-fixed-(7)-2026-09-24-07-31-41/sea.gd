extends MeshInstance3D
class_name Sea


@export var land_margin: float = 2.0
@export var sea_penalty: int = 50

@export_group("Respawn Trigger")

## Where the respawn zone starts, relative to the water's surface. Negative
## = below it, so a car has to actually be in the water (not just near
## it) - shallow water at the shoreline can be driven through.
@export var trigger_height_above_sea: float = -0.5
## How long a car must stay in the water before it's respawned, giving a
## chance to drive back out of a splash at the shoreline.
@export var respawn_delay: float = 0.5

@export var trigger_depth_below_sea: float = 2000.0

@export var respawn_cooldown: float = 1.0

@export_group("Car Respawn")

@export var respawn_height_offset: float = 1.5
@export var respawn_search_radius_step: float = 25.0
@export var respawn_search_max_radius: float = 3000.0
@export var respawn_search_angle_steps: int = 16
## A respawn spot must be at least this high above the water (so the car
## isn't put on a wet beach) ...
@export var respawn_min_height_above_sea: float = 6.0
## ... and fairly flat: the ground within a few meters can't drop more than
## this, otherwise the car just rolls straight back into the sea.
@export var respawn_max_height_change: float = 0.5

@export_group("Ground Raycast")
@export var raycast_start_height: float = 700.0
@export var raycast_max_distance: float = 1500.0
@export var ground_collision_mask: int = 1

var _sea_level_y: float = 0.0
var _sea_level_cached: bool = false
var _ground_query := PhysicsRayQueryParameters3D.new()

var _trigger: Area3D
var _cars_on_cooldown: Dictionary = {}
var _cars_in_water: Dictionary = {}

func _ready() -> void:
	_setup_trigger()

func _setup_trigger() -> void:
	var horizontal_size := _get_world_horizontal_size()
	var sea_y := get_sea_level_y()

	var shape := BoxShape3D.new()
	shape.size = Vector3(
		horizontal_size.x,
		trigger_height_above_sea + trigger_depth_below_sea,
		horizontal_size.y
	)

	var collision_shape := CollisionShape3D.new()
	collision_shape.shape = shape

	_trigger = Area3D.new()
	_trigger.name = "RespawnTrigger"
	_trigger.collision_layer = 0
	_trigger.collision_mask = ground_collision_mask
	_trigger.monitorable = false


	_trigger.top_level = true

	add_child(_trigger)
	_trigger.add_child(collision_shape)

	_trigger.global_position = Vector3(
		global_transform.origin.x,
		sea_y + (trigger_height_above_sea - trigger_depth_below_sea) / 2.0,
		global_transform.origin.z
	)

	_trigger.body_entered.connect(_on_body_entered)
	_trigger.body_exited.connect(_on_body_exited)

func _get_world_horizontal_size() -> Vector2:
	if mesh == null:
		return Vector2(5000.0, 5000.0)

	var aabb := mesh.get_aabb()
	var corner_a: Vector3 = global_transform * aabb.position
	var corner_b: Vector3 = global_transform * (aabb.position + aabb.size)

	return Vector2(
		absf(corner_b.x - corner_a.x),
		absf(corner_b.z - corner_a.z)
	)


func get_sea_level_y() -> float:
	# The sea never moves, so work this out once and reuse it - the coin
	# and target spawners ask for it on every placement attempt.
	if _sea_level_cached:
		return _sea_level_y

	if mesh == null:
		_sea_level_y = global_transform.origin.y
	else:
		var local_y: float = mesh.get_aabb().get_center().y
		_sea_level_y = (global_transform * Vector3(0.0, local_y, 0.0)).y

	_sea_level_cached = true

	return _sea_level_y


func is_land_y(y: float) -> bool:
	return y > get_sea_level_y() + land_margin


func find_nearest_land_position(from_position: Vector3) -> Variant:
	var space_state := get_world_3d().direct_space_state


	var direct = _raycast_ground(from_position.x, from_position.z, space_state)

	if direct != null and _is_good_respawn(direct, space_state):
		return direct

	var radius: float = respawn_search_radius_step

	while radius <= respawn_search_max_radius:
		for step in respawn_search_angle_steps:
			var angle: float = (TAU / respawn_search_angle_steps) * step
			var x: float = from_position.x + cos(angle) * radius
			var z: float = from_position.z + sin(angle) * radius

			var hit = _raycast_ground(x, z, space_state)

			if hit != null and _is_good_respawn(hit, space_state):
				return hit

		radius += respawn_search_radius_step

	return null

func _is_good_respawn(point: Vector3, space_state: PhysicsDirectSpaceState3D) -> bool:
	if point.y < get_sea_level_y() + respawn_min_height_above_sea:
		return false

	for offset in [Vector2(5, 0), Vector2(-5, 0), Vector2(0, 5), Vector2(0, -5)]:
		var o: Vector2 = offset
		var around = _raycast_ground(point.x + o.x, point.z + o.y, space_state)

		if around == null or absf(around.y - point.y) > respawn_max_height_change:
			return false

	return true


func _raycast_ground(
	x: float,
	z: float,
	space_state: PhysicsDirectSpaceState3D
) -> Variant:
	var from := Vector3(x, raycast_start_height, z)
	var to := Vector3(x, raycast_start_height - raycast_max_distance, z)

	_ground_query.from = from
	_ground_query.to = to
	_ground_query.collision_mask = ground_collision_mask

	var result := space_state.intersect_ray(_ground_query)

	if result:
		return result.position

	return null

func _on_body_entered(body: Node3D) -> void:
	if body is RaycastCar:
		_cars_in_water[body] = 0.0


func _on_body_exited(body: Node3D) -> void:
	_cars_in_water.erase(body)


func _physics_process(delta: float) -> void:
	for car in _cars_in_water.keys():
		if not is_instance_valid(car):
			_cars_in_water.erase(car)
			continue

		_cars_in_water[car] += delta

		if _cars_in_water[car] >= respawn_delay:
			_cars_in_water.erase(car)
			_respawn_car(car)


func _respawn_car(car: RaycastCar) -> void:
	if _cars_on_cooldown.get(car, false):
		return

	# Remove points for falling into the sea
	car.score -= sea_penalty
	car.score = max(car.score, 0)
	car.score_label.text = str(car.score)

	var land_position = find_nearest_land_position(car.global_position)

	if land_position == null:
		push_warning("Sea: couldn't find any land nearby to respawn the car onto.")
		return

	_cars_on_cooldown[car] = true

	# Face inland - away from the water the car just went into.
	var inland: Vector3 = land_position - car.global_position
	inland.y = 0.0

	car.respawn_at(
		land_position + Vector3(0.0, respawn_height_offset, 0.0),
		inland
	)

	await get_tree().create_timer(respawn_cooldown).timeout

	_cars_on_cooldown[car] = false
