extends Node

## Runs a match: sets up singleplayer or splitscreen, the optional round
## timer, and ending the round (when the timer runs out, or from the pause
## menu's End Round button).

## Vertical FOV for singleplayer's full-width view. The splitscreen views
## are much narrower, so keeping their FOV here would look very fish-eyed;
## this gives about the same width of view as each splitscreen half.
@export var singleplayer_fov: float = 68.0

@onready var timer: Timer = $GridContainer/Timer

@onready var car1: RaycastCar = $GridContainer/SubViewportContainer/SubViewport/Car
@onready var car2: RaycastCar = get_node_or_null("GridContainer/SubViewportContainer2/SubViewport/Car2")

@onready var time_label1: Label = $GridContainer/SubViewportContainer/SubViewport/TimeLabel
@onready var time_label2: Label = get_node_or_null("GridContainer/SubViewportContainer2/SubViewport/TimeLabel")

var time_left: int = 60
var _round_over: bool = false

var pause_menu_scene = preload("res://pause_menu.tscn")
var pause_menu: Control


func _enter_tree() -> void:
	# Runs before any child's _ready, so player 2 can be removed entirely
	# in singleplayer - their car, camera and HUD never start up at all.
	if GameState.is_singleplayer():
		_setup_singleplayer()


func _setup_singleplayer() -> void:
	var grid: GridContainer = get_node("GridContainer")
	var second_view: Node = get_node_or_null("GridContainer/SubViewportContainer2")
	var first_car: Node = get_node("GridContainer/SubViewportContainer/SubViewport/Car")

	if second_view != null:
		grid.remove_child(second_view)
		second_view.free()

	# One view across the whole screen.
	grid.columns = 1

	# Nothing left that points at the removed car.
	var generator := get_node_or_null("MapGenerator")

	if generator != null:
		# Edited in place - the exported list is typed, so swapping in a
		# plain new array isn't allowed.
		generator.cars.clear()
		generator.cars.append(first_car)

	# Racing position means nothing with one player.
	var place_label := get_node_or_null("GridContainer/SubViewportContainer/SubViewport/PlaceLabel")

	if place_label != null:
		place_label.other_cars.clear()
		place_label.visible = false

	var camera := first_car.get_node_or_null("Camera3D") as Camera3D

	if camera != null:
		camera.fov = singleplayer_fov


func _ready() -> void:
	# Everything (map included) is built by now.
	GameState.hide_loading()

	pause_menu = pause_menu_scene.instantiate()
	add_child(pause_menu)
	pause_menu.visible = false

	if GameState.timer_enabled:
		time_left = maxi(GameState.round_length_seconds, 1)

		timer.wait_time = 1.0
		timer.timeout.connect(_on_timer_timeout)
		timer.start()

		update_labels()
	else:
		# No timer: the round runs until someone ends it from the pause menu.
		for label in [time_label1, time_label2]:
			if label != null:
				label.visible = false


func _on_timer_timeout() -> void:
	time_left -= 1
	update_labels()

	if time_left <= 0:
		end_round()


func update_labels() -> void:
	var minutes: int = time_left / 60
	var seconds: int = time_left % 60

	var time_text := "%02d:%02d" % [minutes, seconds]

	for label in [time_label1, time_label2]:
		if label != null:
			label.text = time_text


## Finishes the match and shows the results. Called when the timer runs
## out, or from the pause menu.
func end_round() -> void:
	if _round_over:
		return

	_round_over = true
	timer.stop()
	get_tree().paused = false

	GameState.car1_score = car1.score
	GameState.car2_score = car2.score if car2 != null else 0
	GameState.is_draw = false

	if GameState.is_singleplayer():
		GameState.winner_username = GameState.display_name(1)
	elif car1.score > car2.score:
		GameState.winner_username = GameState.display_name(1)
	elif car2.score > car1.score:
		GameState.winner_username = GameState.display_name(2)
	else:
		# Used to silently hand ties to player 2.
		GameState.is_draw = true
		GameState.winner_username = ""

	get_tree().change_scene_to_file("res://winning-screen.tscn")
