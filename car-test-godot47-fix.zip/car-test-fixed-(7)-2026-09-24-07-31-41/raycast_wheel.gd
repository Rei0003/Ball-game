extends RayCast3D
class_name RaycastWheel

@export_group("Wheel Properties")
@export var spring_strength: float = 5000.0
## Kept for compatibility with older scenes - bump_damping and
## rebound_damping below are what the suspension actually uses now.
@export var spring_damping: float = 120.0
@export var rest_dist: float = 0.5
@export var over_extend: float = 0.02
@export var wheel_radius: float = 0.4

@export_group("Suspension")
## Damping while the spring is being compressed (hitting a bump,
## landing, braking dive). Lower = softer, absorbs impacts better.
@export var bump_damping: float = 110.0
## Damping while the spring is extending back out. Real dampers resist
## this more than compression, which stops the car bouncing/pogoing
## after a bump or landing.
@export var rebound_damping: float = 190.0
## How much stiffer the spring gets as it compresses. 0 = linear spring.
## 1.0 = twice as stiff at full compression. Lets the car stay supple
## over small bumps but still resist heavy landings.
@export var spring_progression: float = 1.0
## Once the spring is shorter than this, a very stiff bump stop kicks in
## so hard landings don't bottom the car out into the ground.
@export var bump_stop_length: float = 0.08
@export var bump_stop_strength: float = 40000.0
## How quickly the visible wheel follows the suspension (m/s).
@export var wheel_visual_speed: float = 25.0

@export_group("Tire Load")
## How much a tire's grip follows the weight actually pressing on it.
## 0 = every tire always grips as if it carries an equal share of the
## car (the old behavior). 1 = grip fully follows weight transfer, so
## braking loads up the fronts, accelerating loads the rears, and the
## outside tires do more of the work in a corner.
@export_range(0.0, 1.0) var load_sensitivity: float = 0.5

@export_group("Grip")
@export var front_grip: float = 1.0
@export var rear_grip: float = 1.0
@export var drift_front_grip: float = 0.85
## Rear tire stiffness while drifting. How much they can actually hold
## once sliding is the car's drift friction limit (set by throttle).
@export var drift_rear_grip: float = 0.6
@export var handbrake_grip: float = 0.12
@export var initiation_rear_grip: float = 0.38

@export_group("Longitudinal Traction")
@export var z_traction: float = 0.05

## Caps how much grip force a tire can generate, as a multiple of its
## share of the car's weight. This exists purely to stop a sharp turn or
## handbrake pull at high speed from snapping the car's direction
## instantly - it should sit well above anything normal driving forces
## ever need, or the tire will fail to fully cancel out ordinary slip and
## the car will spiral out of control on its own. Only lower this if you
## still see snapping at extreme slip, and lower it gradually.
@export var max_grip_force_coefficient: float = 12.0

@export_group("Motor")
@export var is_motor: bool = false
@export var is_steer: bool = false

@onready var wheel: Node3D = get_child(0)

var engine_force: float = 0.0
var grip_factor: float = 0.0

## How far the spring is currently compressed past its fully extended
## length, in meters - read by the car's anti-roll bars.
var compression: float = 0.0
## Force (N) the suspension pushed up with this frame - i.e. how much
## weight this tire is carrying.
var tire_load: float = 0.0
## World-space wheel center this frame, where suspension forces act.
var hub_position: Vector3 = Vector3.ZERO
var is_grounded: bool = false


func _ready() -> void:
	target_position.y = -(rest_dist + wheel_radius + over_extend)


func apply_wheel_physics(car: RaycastCar) -> void:
	force_raycast_update()

	target_position.y = -(rest_dist + wheel_radius + over_extend)

	var forward_dir: Vector3 = -global_basis.z

	var wheel_velocity: float = forward_dir.dot(
		car.linear_velocity
	)

	wheel.rotate_x(
		(-wheel_velocity * get_physics_process_delta_time())
		/ wheel_radius
	)

	var delta: float = get_physics_process_delta_time()

	var max_spring_len: float = rest_dist + over_extend

	if not is_colliding():
		grip_factor = 0.0
		compression = 0.0
		tire_load = 0.0
		is_grounded = false

		# Let the wheel drop to full droop in the air instead of freezing
		# wherever it was when it left the ground.
		wheel.position.y = move_toward(
			wheel.position.y,
			-max_spring_len,
			wheel_visual_speed * delta
		)

		return

	is_grounded = true

	var contact: Vector3 = get_collision_point()

	var spring_len: float = clampf(
		global_position.distance_to(contact) - wheel_radius,
		0.0,
		max_spring_len
	)

	compression = max_spring_len - spring_len

	wheel.position.y = move_toward(
		wheel.position.y,
		-spring_len,
		wheel_visual_speed * delta
	)

	# Forces act at the true wheel hub, not wherever the visual wheel
	# happens to be mid-animation.
	hub_position = global_position - global_basis.y * spring_len

	contact = hub_position

	var force_pos: Vector3 = (
		contact -
		car.global_position
	)

	# --- Spring (progressive) -----------------------------------------
	var offset: float = rest_dist - spring_len

	var compression_ratio: float = clampf(
		compression / max_spring_len,
		0.0,
		1.0
	)

	var progressive_rate: float = spring_strength * (
		1.0 +
		spring_progression * compression_ratio * compression_ratio
	)

	var spring_force: float = progressive_rate * offset

	# --- Bump stop ------------------------------------------------------
	if spring_len < bump_stop_length:
		spring_force += (
			bump_stop_strength *
			(bump_stop_length - spring_len)
		)

	# --- Damper (separate bump / rebound) -------------------------------
	var tire_vel: Vector3 = (
		car._get_point_velocity(contact)
	)

	# Positive = body moving up away from the ground (rebound),
	# negative = body moving down into the spring (bump).
	var suspension_velocity: float = global_basis.y.dot(tire_vel)

	var damping: float = (
		rebound_damping if suspension_velocity > 0.0
		else bump_damping
	)

	var spring_damp_force: float = damping * suspension_velocity

	var total_suspension_force: float = spring_force - spring_damp_force

	# Weight transfer only counts real downward pressure on the tire.
	tire_load = maxf(0.0, total_suspension_force)

	# The force on the car itself is allowed to briefly go negative,
	# though. A real wheel's own weight keeps it pressed onto the road
	# as the body rises over a bump; these raycast wheels have no weight
	# of their own, and blocking this made the stiffer rebound damping
	# unload the tires on every bump at speed - the car went light, lost
	# grip and started rolling over.
	var suspension_force: Vector3 = (
		total_suspension_force * get_collision_normal()
	)

	if is_motor and car.motor_input != 0 and not car.is_launch_control_active:
		var effective_max_speed: float = car.max_speed
		var effective_acceleration: float = car.acceleration

		if car.is_boosting:
			effective_max_speed += car.nitro_max_speed_bonus
			effective_acceleration *= car.nitro_boost_multiplier

		var speed_ratio: float = clampf(
			absf(wheel_velocity) / effective_max_speed,
			0.0,
			1.0
		)

		# Keeps the car from exceeding its (possibly boosted) top speed,
		# independent of gearing below - gearing decides how you get
		# there, this decides how fast "there" actually is.
		var top_speed_taper: float = (
			1.0 - smoothstep(0.92, 1.0, speed_ratio)
		)

		var gear_force_multiplier: float = (
			car.get_current_gear_torque_multiplier()
		)

		var rpm_multiplier: float = (
			car.accel_curve.sample_baked(
				car.rpm_ratio
			)
		)

		var acceleration_multiplier: float = (
			rpm_multiplier *
			gear_force_multiplier *
			top_speed_taper *
			car.get_launch_boost_multiplier()
		)

		var engine_force_vector: Vector3 = (
			forward_dir *
			effective_acceleration *
			car.motor_input *
			acceleration_multiplier
		)

		car.apply_force(
			engine_force_vector,
			force_pos
		)

	var lateral_velocity: float = (
		global_basis.x.dot(tire_vel)
	)

	var longitudinal_velocity: float = (
		forward_dir.dot(tire_vel)
	)

	var tire_speed: float = tire_vel.length()

	var slip_angle: float = 0.0

	if tire_speed > 0.5:
		slip_angle = atan2(
			lateral_velocity,
			absf(longitudinal_velocity) + 0.1
		)

	var slip_degrees: float = absf(
		rad_to_deg(slip_angle)
	)

	grip_factor = clampf(
		slip_degrees / 45.0,
		0.0,
		1.0
	)

	var grip: float

	if is_steer:
		grip = front_grip
	else:
		grip = rear_grip

	if car.is_drifting:
		if is_steer:
			grip = drift_front_grip
		else:
			grip = drift_rear_grip

	elif car.is_initiating_drift and not is_steer:
		grip = initiation_rear_grip

	if car.hand_brake and not is_steer:
		grip = handbrake_grip

	# High-revs wheelspin outside a drift. Inside one, revs are already
	# part of the car's drift grip, so don't apply them twice.
	if not is_steer and not car.is_drifting:
		grip *= car.get_rpm_traction_factor()

	var steering: float = (
		car.controller.get_steering()
	)

	if car.is_drifting and is_steer:
		var countersteering: bool = (
			steering *
			car.drift_direction < 0.0
		)

		if countersteering:
			grip *= 0.9

	var slip_multiplier: float = 1.0

	if is_steer:
		slip_multiplier = clampf(
			1.0 -
			slip_degrees / 75.0,
			0.35,
			1.0
		)
	else:
		# The rear used to lose grip all the way down to 18% as the slide
		# angle grew - more angle, less grip, even more angle - a runaway
		# straight into a spin. Real tires level off instead.
		slip_multiplier = clampf(
			1.0 -
			slip_degrees / 110.0,
			0.5,
			1.0
		)

	var effective_grip: float = (
		grip *
		slip_multiplier
	)

	var gravity: float = (
		-car.get_gravity().y
	)

	# This tire's share of the car's weight if it were sitting still on
	# flat ground.
	var static_load: float = (
		car.mass *
		gravity /
		maxf(car.total_wheels, 1)
	)

	# Blend toward the weight this tire is really carrying right now.
	# Clamped so a briefly unloaded tire (cresting a bump, inside wheel
	# in a hard corner) still keeps some grip instead of dropping to
	# nothing, and a landing spike can't create absurd grip.
	var dynamic_load: float = clampf(
		tire_load,
		static_load * 0.3,
		static_load * 2.0
	)

	var normal_load: float = lerpf(
		static_load,
		dynamic_load,
		load_sensitivity
	)

	# A real tire can only generate so much grip force no matter how hard
	# it's slipping - without this cap, a sudden high-speed direction
	# mismatch (sharp turn, handbrake) produces an unbounded corrective
	# force that snaps the car's heading almost instantly instead of
	# sliding it around smoothly.
	# Deliberately based on the static load, not the dynamic one above -
	# letting this cap shrink on a lightly loaded tire is exactly what
	# caused the earlier straight-line spinning problem.
	var max_grip_force: float = (
		static_load *
		max_grip_force_coefficient
	)

	var raw_lateral_force: float = (
		lateral_velocity *
		effective_grip *
		normal_load
	)

	var lateral_limit: float = max_grip_force

	# Once the rear is sliding in a drift, its sideways force levels off
	# at a friction limit instead of growing without end as the slide
	# gets bigger. That's what makes a held drift angle stable: the tires
	# stop fighting harder the further the car slides, so throttle and
	# steering (through the car's drift assist) decide the angle.
	if car.is_drifting:
		var friction: float = (
			car.drift_front_friction if is_steer
			else car.get_drift_rear_grip()
		)

		lateral_limit = minf(lateral_limit, friction * normal_load)

	var lateral_force: Vector3 = (
		-global_basis.x *
		clampf(
			raw_lateral_force,
			-lateral_limit,
			lateral_limit
		)
	)

	var longitudinal_grip: float = z_traction

	if not is_steer and car.is_drifting:
		longitudinal_grip *= 0.65

	var raw_longitudinal_force: float = (
		longitudinal_velocity *
		longitudinal_grip *
		normal_load
	)

	var longitudinal_force: Vector3 = (
		global_basis.z *
		clampf(
			raw_longitudinal_force,
			-max_grip_force,
			max_grip_force
		)
	)

	car.apply_force(
		suspension_force,
		force_pos
	)

	car.apply_force(
		lateral_force,
		force_pos
	)

	car.apply_force(
		longitudinal_force,
		force_pos
	)
