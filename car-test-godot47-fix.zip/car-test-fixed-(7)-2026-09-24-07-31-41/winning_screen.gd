extends Control

@onready var title_label: Label = get_node_or_null("Label")
@onready var winner_label: Label = $HBoxContainer2/WinnerNameLabel


func _ready() -> void:
	if GameState.is_singleplayer():
		_set_title("Results")
		winner_label.text = "%s  -  %d points" % [
			GameState.display_name(1),
			GameState.car1_score,
		]
		return

	var scores: String = "%s  %d  -  %d  %s" % [
		GameState.display_name(1),
		GameState.car1_score,
		GameState.car2_score,
		GameState.display_name(2),
	]

	if GameState.is_draw:
		_set_title("Draw")
		winner_label.text = scores
	else:
		_set_title("Winner")

		var winner_is_1: bool = GameState.car1_score > GameState.car2_score
		var high: int = maxi(GameState.car1_score, GameState.car2_score)
		var low: int = mini(GameState.car1_score, GameState.car2_score)
		var loser: String = GameState.display_name(2 if winner_is_1 else 1)

		winner_label.text = "%s wins  %d  -  %d  vs %s" % [
			GameState.winner_username, high, low, loser,
		]


func _set_title(text: String) -> void:
	if title_label != null:
		title_label.text = text
