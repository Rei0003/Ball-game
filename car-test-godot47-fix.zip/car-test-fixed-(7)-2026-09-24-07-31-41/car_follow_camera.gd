extends Camera3D

@export_group("Camera Distance")
@export var min_distance: float = 4.0
@export var max_distance: float = 8.0
@export var height: float = 3.0

@export_group("Collision")
@export_flags_3d_physics var terrain_collision_mask: int = 1
@export var camera_radius: float = 0.35
@export var ground_clearance: float = 0.5

@export_group("Smoothing")
@export_range(0.01, 1.0) var position_smoothing: float = 0.15

@export_group("Speed Feel")
## Extra field of view (degrees) at full speed, and on top of that with
## nitro. A widening view is one of the strongest cues of going fast.
@export var fov_speed_kick: float = 9.0
@export var fov_boost_kick: float = 6.0
@export var fov_smoothing: float = 5.0
## Small camera shake at high speed, stronger on nitro. Applied as a
## lens offset, so it never moves the camera itself.
@export var shake_at_speed: float = 0.025
@export var shake_on_boost: float = 0.05
@export var shake_frequency: float = 18.0

var _base_fov: float = 75.0
var _shake_time: float = 0.0


@onready var target: Node3D = get_parent()

# Built once and reused, rather than allocating two new query objects
# every physics frame.
var _camera_query := PhysicsRayQueryParameters3D.new()
var _ground_query := PhysicsRayQueryParameters3D.new()


func _ready() -> void:
	_base_fov = fov

	# The camera is top-level, so its scene transform is in world space,
	# but it was laid out relative to the car. Snap it into that spot
	# behind wherever the car actually starts (it moves every map), instead
	# of swooping across the map on the first frames.
	if is_instance_valid(target):
		global_transform = target.global_transform * transform

	var exclude: Array[RID] = []

	# The query's exclude list takes physics RIDs, not nodes.
	if target is CollisionObject3D:
		exclude.append((target as CollisionObject3D).get_rid())

	_camera_query.exclude = exclude
	_ground_query.exclude = exclude


func _process(delta: float) -> void:
	if not is_instance_valid(target):
		return

	var strength: float = 0.0
	var boost: float = 0.0

	if target is RaycastCar:
		strength = (target as RaycastCar).speed_effect_strength
		boost = (target as RaycastCar).speed_effect_boost

	var target_fov: float = (
		_base_fov +
		fov_speed_kick * strength +
		fov_boost_kick * boost
	)

	fov = lerpf(fov, target_fov, minf(1.0, delta * fov_smoothing))

	var shake: float = shake_at_speed * strength + shake_on_boost * boost

	if shake < 0.0005:
		h_offset = 0.0
		v_offset = 0.0
		return

	_shake_time += delta * shake_frequency

	# A few out-of-step sine waves - a smooth rumble rather than jitter.
	h_offset = shake * (
		sin(_shake_time * 1.0) * 0.6 +
		sin(_shake_time * 2.3 + 1.7) * 0.4
	)

	v_offset = shake * (
		sin(_shake_time * 1.4 + 0.5) * 0.6 +
		sin(_shake_time * 2.9 + 2.2) * 0.4
	)


func _physics_process(_delta: float) -> void:
	if not is_instance_valid(target):
		return

	var space_state: PhysicsDirectSpaceState3D = (
		get_world_3d().direct_space_state
	)



	var offset: Vector3 = (
		global_position -
		target.global_position
	)


	if offset.length_squared() < 0.01:
		offset = target.global_basis.z * max_distance


	var horizontal_offset: Vector3 = Vector3(
		offset.x,
		0.0,
		offset.z
	)

	if horizontal_offset.length_squared() < 0.01:
		horizontal_offset = (
			target.global_basis.z *
			max_distance
		)

	horizontal_offset = horizontal_offset.normalized()

	var desired_position: Vector3 = (
		target.global_position +
		horizontal_offset * max_distance +
		Vector3.UP * height
	)



	var camera_direction: Vector3 = (
		desired_position -
		target.global_position
	)

	var camera_distance: float = (
		camera_direction.length()
	)

	if camera_distance > 0.01:
		camera_direction = (
			camera_direction.normalized()
		)


		var ray_start: Vector3 = (
			target.global_position +
			Vector3.UP * 0.5
		)

		var ray_end: Vector3 = (
			ray_start +
			camera_direction * camera_distance
		)

		_camera_query.from = ray_start
		_camera_query.to = ray_end
		_camera_query.collision_mask = terrain_collision_mask

		var camera_result: Dictionary = (
			space_state.intersect_ray(_camera_query)
		)

		if not camera_result.is_empty():
			var collision_position: Vector3 = (
				camera_result["position"]
			)

			var safe_distance: float = (
				target.global_position.distance_to(
					collision_position
				) -
				camera_radius -
				ground_clearance
			)

			safe_distance = clampf(
				safe_distance,
				min_distance,
				max_distance
			)

			desired_position = (
				target.global_position +
				camera_direction * safe_distance
			)



	var ground_start: Vector3 = (
		desired_position +
		Vector3.UP * 2.0
	)

	var ground_end: Vector3 = (
		desired_position +
		Vector3.DOWN * 20.0
	)

	_ground_query.from = ground_start
	_ground_query.to = ground_end
	_ground_query.collision_mask = terrain_collision_mask

	var ground_result: Dictionary = (
		space_state.intersect_ray(_ground_query)
	)

	if not ground_result.is_empty():
		var ground_position: Vector3 = (
			ground_result["position"]
		)

		var minimum_camera_height: float = (
			ground_position.y +
			camera_radius +
			ground_clearance
		)

		if desired_position.y < minimum_camera_height:
			desired_position.y = (
				minimum_camera_height
			)

	global_position = global_position.lerp(
		desired_position,
		position_smoothing
	)

	look_at(
		target.global_position,
		Vector3.UP
	)
