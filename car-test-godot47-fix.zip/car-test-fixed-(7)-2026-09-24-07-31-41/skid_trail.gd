extends Node3D
class_name SkidTrail

## Continuous tire marks laid on the ground as a ribbon mesh, replacing
## the old particle marks (which vanished after 1.5s and looked dotted at
## speed). The ribbon is split into chunks: only the newest chunk is
## rebuilt as the car moves, and whole old chunks are freed once they've
## faded out, so long trails stay cheap.

## Width of the mark from a tire rolling straight. Sideways slides leave
## much wider marks (the whole tire dragging across the ground), up to
## sideways_width_scale times this.
@export var width: float = 0.3
@export var sideways_width_scale: float = 2.4
## Seconds a mark stays visible, and how much of that is the fade-out.
@export var lifetime: float = 20.0
@export var fade_time: float = 5.0
@export var mark_color: Color = Color(0.035, 0.032, 0.03)
@export var max_opacity: float = 0.9
## New mark points are only added this far apart (meters).
@export var min_segment_length: float = 0.25
## A jump bigger than this between points (a reset, a respawn) starts a
## fresh mark instead of stretching one across the map.
@export var max_gap: float = 3.0
@export var segments_per_chunk: int = 48
@export var max_chunks: int = 12

const SHADER_CODE := """
shader_type spatial;
// Lit (not unshaded), so marks pick up the scene's light and shadows and
// sit IN the ground rather than looking pasted on top of it.
render_mode blend_mix, depth_draw_never, cull_disabled;

uniform vec4 mark_color : source_color = vec4(0.035, 0.032, 0.03, 1.0);
uniform float now = 0.0;
uniform float lifetime = 20.0;
uniform float fade_time = 5.0;

float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(
		mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
		mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
		u.y
	);
}

void fragment() {
	float age = now - UV2.x;
	float life_fade = 1.0 - smoothstep(lifetime - fade_time, lifetime, age);

	// UV.x runs across the mark (0-1), UV.y along it in meters, so the
	// patterns below keep the same size no matter how long the mark is.
	float along = UV.y;
	float across = UV.x * 2.0 - 1.0;

	// Ragged, uneven edges instead of a ruler-straight border.
	float wobble = (vnoise(vec2(along * 2.5, 3.7)) - 0.5) * 0.35;
	float edge = 1.0 - smoothstep(0.55, 1.0, abs(across) + wobble);

	// Darker core where the tire pressed hardest.
	float core = mix(0.75, 1.0, 1.0 - across * across);

	// Big blotches: rubber goes down unevenly as grip comes and goes.
	float blotch = mix(0.6, 1.0, vnoise(vec2(along * 0.6, across * 1.2)));

	// Fine grain, and faint striations running along the slide direction
	// (left by the tread as it drags across the ground).
	float grain = mix(0.8, 1.0, vnoise(vec2(along * 9.0, across * 13.0)));
	float streaks = mix(0.8, 1.0, vnoise(vec2(across * 22.0, along * 0.25)));

	// Each mark builds in over its first stretch rather than starting
	// with a hard square end.
	float start = smoothstep(0.0, 0.7, along);

	ALBEDO = mark_color.rgb;
	// Fresh rubber is a little smoother than the ground - it catches
	// light at low angles.
	ROUGHNESS = 0.55;
	SPECULAR = 0.35;
	ALPHA = clamp(
		COLOR.a * life_fade * edge * core * blotch * grain * streaks * start
			* 1.3,
		0.0,
		1.0
	);
}
"""

var _material: ShaderMaterial
var _clock: float = 0.0
var _chunks: Array[Dictionary] = []
var _strip_open: bool = false
var _last_position: Vector3 = Vector3.ZERO
var _distance_along: float = 0.0


func _ready() -> void:
	# Marks live in world space - they don't move with the car.
	top_level = true
	global_transform = Transform3D.IDENTITY

	var shader := Shader.new()
	shader.code = SHADER_CODE

	_material = ShaderMaterial.new()
	_material.shader = shader
	_material.set_shader_parameter("mark_color", mark_color)
	_material.set_shader_parameter("lifetime", lifetime)
	_material.set_shader_parameter("fade_time", fade_time)


func _process(delta: float) -> void:
	# Own clock, so marks pause with the game instead of fading away
	# behind the pause menu.
	_clock += delta
	_material.set_shader_parameter("now", _clock)

	# Free whole chunks once everything in them has faded out.
	while not _chunks.is_empty() and _clock - _chunks[0].newest > lifetime:
		_free_chunk(0)


## Adds a point to the mark. `intensity` (0-1) sets how dark this stretch
## is, `sideways` (0-1) how sideways the tire is sliding (wider mark).
func add_point(
	position: Vector3,
	normal: Vector3,
	direction: Vector3,
	intensity: float,
	sideways: float
) -> void:
	if _strip_open:
		var gap: float = position.distance_to(_last_position)

		if gap > max_gap:
			end_strip()
		elif gap < min_segment_length:
			return

	var travel: Vector3 = direction - normal * direction.dot(normal)

	if travel.length_squared() < 0.0001:
		return

	var side: Vector3 = normal.cross(travel.normalized()).normalized()

	var half_width: float = (
		width * lerpf(1.0, sideways_width_scale, clampf(sideways, 0.0, 1.0))
	) * 0.5

	if _strip_open:
		_distance_along += position.distance_to(_last_position)

	var point := {
		"normal": normal,
		"left": position - side * half_width,
		"right": position + side * half_width,
		"alpha": clampf(intensity, 0.0, 1.0) * max_opacity,
		"time": _clock,
		"along": _distance_along,
		"connected": _strip_open,
	}

	var chunk: Dictionary = _current_chunk()

	# Start a new chunk once this one is full, carrying over the last
	# point so the mark stays one continuous ribbon across the seam.
	if chunk.points.size() >= segments_per_chunk + 1:
		var carry: Dictionary = chunk.points[-1].duplicate()
		carry.connected = false

		chunk = _new_chunk()
		chunk.points.append(carry)
		point.connected = true

	chunk.points.append(point)
	chunk.newest = _clock

	_rebuild_chunk(chunk)

	_strip_open = true
	_last_position = position


## Lifts the "pen" - the next point starts a separate mark.
func end_strip() -> void:
	_strip_open = false
	_distance_along = 0.0


func _current_chunk() -> Dictionary:
	if _chunks.is_empty():
		return _new_chunk()

	return _chunks[-1]


func _new_chunk() -> Dictionary:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.mesh = ArrayMesh.new()
	mesh_instance.material_override = _material
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	add_child(mesh_instance)

	var chunk := {
		"instance": mesh_instance,
		"points": [],
		"newest": _clock,
	}

	_chunks.append(chunk)

	if _chunks.size() > max_chunks:
		_free_chunk(0)

	return chunk


func _free_chunk(index: int) -> void:
	var chunk: Dictionary = _chunks[index]
	chunk.instance.queue_free()
	_chunks.remove_at(index)


func _rebuild_chunk(chunk: Dictionary) -> void:
	var points: Array = chunk.points
	var mesh: ArrayMesh = chunk.instance.mesh

	mesh.clear_surfaces()

	if points.size() < 2:
		return

	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()
	var uvs := PackedVector2Array()
	var uv2s := PackedVector2Array()
	var indices := PackedInt32Array()

	for i in points.size():
		var point: Dictionary = points[i]
		var color := Color(1.0, 1.0, 1.0, point.alpha)

		vertices.append(point.left)
		vertices.append(point.right)
		normals.append(point.normal)
		normals.append(point.normal)
		colors.append(color)
		colors.append(color)
		uvs.append(Vector2(0.0, point.along))
		uvs.append(Vector2(1.0, point.along))
		uv2s.append(Vector2(point.time, 0.0))
		uv2s.append(Vector2(point.time, 0.0))

		if i > 0 and point.connected:
			var base: int = (i - 1) * 2
			indices.append_array(PackedInt32Array([
				base, base + 2, base + 1,
				base + 1, base + 2, base + 3,
			]))

	if indices.is_empty():
		return

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_TEX_UV2] = uv2s
	arrays[Mesh.ARRAY_INDEX] = indices

	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
