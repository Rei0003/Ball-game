extends Node3D
class_name TargetSpawner

## Scene to spawn for every target.
@export var target_scene: PackedScene

@export_group("Spawn Area")

## Center of the rectangular area (world X/Z) targets can spawn across.
@export var spawn_center: Vector2 = Vector2(-0.7, 0.64)

## Half-width / half-depth of the spawn area.
@export var spawn_extents: Vector2 = Vector2(2450.0, 2450.0)

## Optional - prevents targets from spawning over the sea.
@export var sea: Sea

@export_group("Ground Raycast")

@export var raycast_start_height: float = 700.0
@export var raycast_max_distance: float = 1500.0
@export var ground_collision_mask: int = 1

@export_group("Ramp Detection")

## A candidate spot only counts as a launch ramp if its surface is tilted
## between these two angles away from flat ground. Too shallow and a car
## won't get airborne there; too steep and it's more of a wall/cliff face
## than something a car could drive up and launch off.
@export var min_ramp_angle_degrees: float = 12.0
@export var max_ramp_angle_degrees: float = 55.0

@export_group("Launch Estimate")

## Speed (m/s) assumed for a car driving up a ramp and launching off it.
## This only drives a rough estimate of where a jump off a given ramp
## would peak - it isn't simulating the player's actual approach speed.
@export var assumed_launch_speed: float = 22.0
@export var min_target_height: float = 2.0
@export var max_target_height: float = 60.0

@export_group("Target")

## How many targets can exist at once.
@export var max_active: int = 10

## How often a new target is spawned after one is collected.
@export var spawn_interval: float = 3.0

@export var target_scale: float = 1.0

## Height of the target model's centre above its origin (before scaling).
## Used to put the middle of the target - not its bottom edge - on the
## flight path.
@export var target_centre_height: float = 1.0


var _container: Node3D

## Known launch ramps (added by the map generator). Most targets are placed
## off the end of one of these, so they're guaranteed reachable.
var _jump_sites: Array[Dictionary] = []
@export_range(0.0, 1.0) var jump_site_chance: float = 0.75


func add_jump_site(launch_point: Vector3, direction: Vector3, incline_degrees: float) -> void:
	_jump_sites.append({
		"point": launch_point,
		"direction": Vector3(direction.x, 0.0, direction.z).normalized(),
		"incline": incline_degrees,
	})


func _ready() -> void:
	if target_scene == null:
		push_warning(
			"TargetSpawner has no target_scene assigned; no targets will spawn."
		)
		return

	_container = Node3D.new()
	_container.name = "Targets"
	add_child(_container)

	# Wait a physics frame so freshly generated terrain is in place before
	# raycasting against it.
	await get_tree().physics_frame

	# Spawn the initial targets.
	_try_fill_targets()

	# Timer for replacing collected targets.
	var timer := Timer.new()
	timer.name = "TargetSpawnTimer"
	timer.wait_time = spawn_interval
	timer.autostart = true
	timer.one_shot = false

	add_child(timer)

	timer.timeout.connect(_on_spawn_timer_timeout)


func _on_spawn_timer_timeout() -> void:
	if _container.get_child_count() >= max_active:
		return

	_try_spawn_one()


func _try_fill_targets() -> void:
	while _container.get_child_count() < max_active:
		if not _try_spawn_one():
			break


func _try_spawn_one() -> bool:
	if _container.get_child_count() >= max_active:
		return false

	var placement = _find_jump_target_position()

	if placement == null:
		return false

	var target: Target = target_scene.instantiate()

	_container.add_child(target)

	var apex: Vector3 = placement.apex
	var launch: Vector3 = placement.launch

	# Face the target back toward the ramp's lip, tilted by the actual angle
	# from the lip up to the peak - so it squarely faces a car flying off
	# that ramp. (The target model's face points along its Z axis; it's
	# double-sided, so looking_at's -Z works.)
	var toward_lip: Vector3 = launch - apex

	if toward_lip.length_squared() < 0.01:
		toward_lip = Vector3.FORWARD

	var basis := Basis.looking_at(toward_lip.normalized(), Vector3.UP)

	# The model's origin is at the bottom of the disc and its centre is
	# target_centre_height up from there - so shift it down, putting the
	# middle of the target on the flight path rather than its bottom edge.
	target.global_transform = Transform3D(basis, apex - basis.y * target_centre_height * target_scale)
	target.coin_scale = target_scale

	return true


## Looks for a random ramp-like slope on the map, then uses basic
## projectile motion (assuming a car drives up it at assumed_launch_speed)
## to estimate roughly where the peak of a jump off that ramp would be.
## That's where the target gets placed, so actually reaching one means
## using a piece of the terrain to launch into the air.
func _find_jump_target_position() -> Variant:
	var space_state := get_world_3d().direct_space_state

	if not _jump_sites.is_empty() and randf() < jump_site_chance:
		for attempt in 6:
			var site: Dictionary = _jump_sites[randi() % _jump_sites.size()]
			var apex: Vector3 = _apex_from(site.point, site.direction, site.incline)

			if not _path_is_blocked(site.point, apex, space_state):
				return {"apex": apex, "launch": site.point}

	for attempt in 40:
		var x: float = (
			spawn_center.x +
			randf_range(-spawn_extents.x, spawn_extents.x)
		)

		var z: float = (
			spawn_center.y +
			randf_range(-spawn_extents.y, spawn_extents.y)
		)

		var ground = _raycast_ground(x, z, space_state)

		if ground == null:
			continue

		if sea != null and not sea.is_land_y(ground.position.y):
			continue

		var incline_degrees: float = rad_to_deg(
			acos(
				clampf(ground.normal.dot(Vector3.UP), -1.0, 1.0)
			)
		)

		if incline_degrees < min_ramp_angle_degrees:
			continue

		if incline_degrees > max_ramp_angle_degrees:
			continue

		# Horizontal direction the slope climbs towards - a car driving
		# up it and launching off the top would be heading this way.
		var uphill_dir := Vector3(
			-ground.normal.x,
			0.0,
			-ground.normal.z
		).normalized()

		if uphill_dir.length_squared() < 0.01:
			continue

		var launch_point: Vector3 = ground.position

		var apex_position: Vector3 = _apex_from(
			launch_point,
			uphill_dir,
			incline_degrees
		)

		# Make sure nothing (a wall, a hill) sits between the ramp and
		# the spot in the air the target would go - otherwise a jump off
		# this particular ramp could never actually reach it.
		if _path_is_blocked(launch_point, apex_position, space_state):
			continue

		return {"apex": apex_position, "launch": launch_point}

	return null


## Rough peak of a jump launched from `launch_point` heading `direction`
## up a slope of `incline_degrees`, at assumed_launch_speed.
func _apex_from(launch_point: Vector3, direction: Vector3, incline_degrees: float) -> Vector3:
	var incline_radians: float = deg_to_rad(incline_degrees)

	var gravity: float = absf(
		ProjectSettings.get_setting(
			"physics/3d/default_gravity",
			9.8
		)
	)

	var vertical_speed: float = assumed_launch_speed * sin(incline_radians)
	var horizontal_speed: float = assumed_launch_speed * cos(incline_radians)
	var time_to_apex: float = vertical_speed / gravity

	var apex_height: float = clampf(
		(vertical_speed * vertical_speed) / (2.0 * gravity),
		min_target_height,
		max_target_height
	)

	return (
		launch_point +
		direction * horizontal_speed * time_to_apex +
		Vector3.UP * apex_height
	)


func _path_is_blocked(
	from_pos: Vector3,
	to_pos: Vector3,
	space_state: PhysicsDirectSpaceState3D
) -> bool:
	var query := PhysicsRayQueryParameters3D.create(
		from_pos + Vector3.UP * 2.0,
		to_pos
	)

	query.collision_mask = ground_collision_mask

	var result := space_state.intersect_ray(query)

	return not result.is_empty()


func _raycast_ground(
	x: float,
	z: float,
	space_state: PhysicsDirectSpaceState3D
) -> Variant:
	var from := Vector3(x, raycast_start_height, z)
	var to := Vector3(x, raycast_start_height - raycast_max_distance, z)

	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = ground_collision_mask

	var result := space_state.intersect_ray(query)

	if result:
		return {
			"position": result.position,
			"normal": result.normal,
		}

	return null
