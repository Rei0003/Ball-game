extends Control
class_name OptionsMenu

## Options screen, shown on top of whatever opened it (the main menu or the
## pause menu). Settings apply immediately and are saved between launches.

signal closed


@onready var style_button: OptionButton = $Card/VBox/StyleRow/StyleButton
@onready var time_button: OptionButton = $Card/VBox/TimeRow/TimeButton
@onready var hint_label: Label = $Card/VBox/Hint
@onready var back_button: Button = $Card/VBox/BackButton


func _ready() -> void:
	# Keeps working while the game is paused.
	process_mode = Node.PROCESS_MODE_ALWAYS

	style_button.clear()
	style_button.add_item("Auto", GameState.HudStyle.AUTO)
	style_button.add_item("Simple", GameState.HudStyle.SIMPLE)
	style_button.add_item("Detailed", GameState.HudStyle.DETAILED)
	style_button.select(style_button.get_item_index(GameState.hud_style))
	style_button.item_selected.connect(_on_style_selected)

	time_button.clear()
	time_button.add_item("Day & night", GameState.TimeOfDay.CYCLE)
	time_button.add_item("Always day", GameState.TimeOfDay.ALWAYS_DAY)
	time_button.add_item("Always night", GameState.TimeOfDay.ALWAYS_NIGHT)
	time_button.select(time_button.get_item_index(GameState.time_of_day_mode))
	time_button.item_selected.connect(_on_time_selected)

	back_button.pressed.connect(close)

	_update_hint()


func _on_style_selected(index: int) -> void:
	GameState.set_hud_style(style_button.get_item_id(index) as GameState.HudStyle)
	_update_hint()


func _on_time_selected(index: int) -> void:
	GameState.set_time_of_day_mode(time_button.get_item_id(index) as GameState.TimeOfDay)


func _update_hint() -> void:
	hint_label.text = _style_hint(GameState.hud_style)


## A short description of each gauge style. Built at runtime rather than as
## a constant: the style values come from the GameState autoload, which
## doesn't exist yet when the script is compiled (Godot 4.5+ rejects that
## as "not a constant expression").
func _style_hint(style: int) -> String:
	if style == GameState.HudStyle.SIMPLE:
		return "Compact speed, gear and bars - takes the least space."

	if style == GameState.HudStyle.DETAILED:
		return "Single round gauge with speed and revs - best on a full screen."

	return "Detailed gauge in singleplayer, simple bars in splitscreen."


func close() -> void:
	closed.emit()
	queue_free()


func _unhandled_input(event: InputEvent) -> void:
	# Escape closes Options first, instead of also unpausing the game.
	if event.is_action_pressed("Pause-Menu") or event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		close()
