extends Node3D
class_name MapGenerator

## Builds a new map from a seed every time the level loads. The island is a
## blend of biomes - grassland, forest, desert dunes, terraced badlands and
## snowy tundra - placed by temperature and moisture maps like real climate
## zones, with mountain ranges, lakes and a coastline all the way round so
## the sea forms a natural edge. Forests get trees and the badlands get
## boulders (real obstacles). Places jump ramps and a flat start area, and
## tells the cars, sea, coin spawner and target spawner where things are.
##
## Seed: GameState.map_seed if set (non-zero), otherwise a random one.
## The seed actually used is stored in GameState.current_map_seed so it can
## be shown to the players and entered again to replay a map.

signal generated(seed: int)

enum Biome { GRASSLAND, FOREST, DESERT, BADLANDS, TUNDRA }

## Where each biome sits on the (temperature, moisture) climate map, -1..1.
const BIOME_CLIMATE := [
	Vector2(0.0, 0.0),    # grassland: mild
	Vector2(-0.05, 0.62), # forest: mild and wet
	Vector2(0.62, -0.55), # desert: hot and dry
	Vector2(0.62, 0.2),   # badlands: hot
	Vector2(-0.68, 0.0),  # tundra: cold
]

## Collision layer for trees and rocks. The car body collides with them,
## but wheels, the camera, and coin/target/respawn raycasts (layer 1)
## ignore them - so coins never land on top of a tree.
const PROP_LAYER := 2

## Shape of the ramps' kicker curve: height = t^RAMP_CURVE along its
## length. 1 = a straight slope; higher = flatter at first, steeper lip.
const RAMP_CURVE := 1.2

@export_group("Size")
## Width and depth of the whole map in meters (land plus surrounding sea).
@export var map_size: float = 7000.0
## Size of one terrain grid square. Bigger = chunkier low-poly look and
## faster generation, smaller = more detail (and slower generation).
@export var cell_size: float = 10.0
## Grid squares per chunk side. Each chunk is drawn (and culled) separately.
@export var chunk_cells: int = 48
## The climate (which biome is where) changes slowly, so it's only worked
## out every this many grid points and blended in between - a big saving
## on generation time with no visible difference.
@export var climate_step: int = 4

@export_group("Terrain Shape")
## Average land height above the sea, in meters.
@export var base_height: float = 14.0
@export var hill_height: float = 34.0
@export var mountain_height: float = 170.0
@export var dune_height: float = 16.0
## Small bumps that only show up with the finer terrain grid, so the extra
## polygons actually add detail instead of tracing the same smooth hills.
@export var micro_detail_height: float = 1.4
## Height of each step of the badlands' terraced mesas.
@export var terrace_step: float = 15.0
## Distance from the center (as a fraction of half the map size) where the
## land starts dropping toward the sea.
@export_range(0.3, 0.95) var coast_start: float = 0.72
@export var seabed_depth: float = -45.0

@export_group("Biomes")
## How soft the borders between biomes are. Higher = wider blends.
@export var biome_blend: float = 0.3
## How much of the temperature comes from a cold-to-hot gradient across the
## map (like latitude), versus random variation. Higher keeps deserts and
## snow further apart - there's always temperate land between them.
@export_range(0.0, 1.0) var climate_gradient: float = 0.8
## Trees per square kilometer of pure forest (tundra and grassland get a
## small fraction of this).
@export var forest_density: float = 700.0
## Boulders per square kilometer of pure badlands.
@export var rock_density: float = 90.0

@export_group("Tree Models")
## Your own tree models (any Mesh - .obj, or a mesh saved from a .glb).
## They're used as broadleaf trees in grassland and forest, mixed in with
## the generated pines. Add more here and they'll be picked at random.
@export var custom_tree_meshes: Array[Mesh] = [
	preload("res://models/trees/tree.obj"),
	preload("res://models/trees/tree2.obj"),
]
## Height range (meters) the custom trees are scaled to.
@export var custom_tree_min_height: float = 5.5
@export var custom_tree_max_height: float = 9.0
## Share of forest trees that use your models (the rest are pines).
## Grassland uses them for most of its trees; tundra never does.
@export_range(0.0, 1.0) var custom_tree_forest_share: float = 0.4

@export_group("Draw Distances")
## Props are grouped into map tiles of this size, so ones off-screen or far
## away aren't drawn at all.
@export var prop_tile_size: float = 400.0
## Your detailed tree models are only drawn within this distance.
@export var custom_tree_draw_distance: float = 650.0
@export var pine_draw_distance: float = 1600.0
@export var rock_draw_distance: float = 1000.0

@export_group("Ramps")
@export var ramp_count: int = 160
## Fraction of ramps that are big kickers (taller and steeper).
@export_range(0.0, 1.0) var big_ramp_fraction: float = 0.3

@export_group("Spawn")
## Radius of the flattened start area.
@export var spawn_flat_radius: float = 70.0
## Gap between the two cars at the start, side by side.
@export var spawn_car_gap: float = 7.0

@export_group("Coins")
## The coin spawner's numbers were balanced on the old map's amount of
## land. Coin counts are scaled by (this map's land / this) so coins stay
## about as easy to find on every map.
@export var reference_land_area_km2: float = 11.4

@export_group("Links")
@export var sea: Sea
@export var cars: Array[Node3D] = []
@export var coin_spawner: CoinSpawner
@export var target_spawner: TargetSpawner

var map_seed: int = 0
var land_area_km2: float = 0.0
var biome_coverage := PackedFloat32Array([0, 0, 0, 0, 0])
var tree_count: int = 0
var rock_count: int = 0

var _sea_level: float = 0.0
var _half: float = 2500.0
var _grid_n: int = 278
var _heights := PackedFloat32Array()
var _colors := PackedColorArray()
var _badlands_weight := PackedFloat32Array()
var _tundra_weight := PackedFloat32Array()
var _spawn_center := Vector2.ZERO
var _spawn_height: float = 10.0
var _spawn_yaw: float = 0.0
var _ramp_spots: Array[Vector2] = []
# Grid cells (30 m) that ramps occupy - a fast "is a ramp near here?" check.
var _ramp_cells: Dictionary = {}
var _coarse_weights: Array[PackedFloat32Array] = []
var _coarse_n: int = 0
var _coarse_step: int = 4
# Collision shapes for props, shared by size, kept alive here.
var _prop_shapes: Array[Shape3D] = []
## Direction the map gets warmer in - different for every seed.
var _warm_direction := Vector2.DOWN
var _rng := RandomNumberGenerator.new()

var _hills := FastNoiseLite.new()
var _warp := FastNoiseLite.new()
var _region := FastNoiseLite.new()
var _ridge := FastNoiseLite.new()
var _detail := FastNoiseLite.new()
var _tint := FastNoiseLite.new()
var _temperature := FastNoiseLite.new()
var _moisture := FastNoiseLite.new()
var _dunes := FastNoiseLite.new()
var _micro := FastNoiseLite.new()
var _timings: Array[String] = []

var _terrain_material: StandardMaterial3D
var _ramp_material: StandardMaterial3D
var _prop_material: StandardMaterial3D
var _trunk_material: StandardMaterial3D


func _ready() -> void:
	var started: int = Time.get_ticks_msec()

	map_seed = GameState.map_seed

	if map_seed == 0:
		var seed_rng := RandomNumberGenerator.new()
		seed_rng.randomize()
		map_seed = seed_rng.randi_range(1, 999999)

	GameState.current_map_seed = map_seed

	_rng.seed = map_seed
	_half = map_size * 0.5

	var climate_angle: float = _rng.randf() * TAU
	_warm_direction = Vector2(cos(climate_angle), sin(climate_angle))
	_grid_n = int(map_size / cell_size)

	if sea != null:
		_fit_sea()
		_sea_level = sea.get_sea_level_y()

	_setup_noise()
	_setup_materials()
	_choose_spawn()
	_time("setup")
	_build_height_grid()
	_time("heights")
	_colour_grid()
	_time("colours")
	_build_terrain_chunks()
	_time("mesh")
	_place_ramps()
	_place_props()
	_time("props")
	_place_cars()
	_configure_spawners()

	print(
		"Map generated - seed %d, %.1f km2 of land, %d trees, %d rocks, %d ms (%s)" %
		[map_seed, land_area_km2, tree_count, rock_count, Time.get_ticks_msec() - started, ", ".join(_timings)]
	)

	generated.emit(map_seed)


var _phase_started: int = 0


func _time(label: String) -> void:
	var now: int = Time.get_ticks_msec()

	if _phase_started > 0:
		_timings.append("%s %d" % [label, now - _phase_started])

	_phase_started = now


## Stretches the sea plane (sideways only, so the water level stays put)
## to surround the whole map, whatever size it is.
func _fit_sea() -> void:
	var mesh_size: float = 5.0

	if sea.mesh is PlaneMesh:
		mesh_size = (sea.mesh as PlaneMesh).size.x

	# Well past the map edge, so the end of the sea never shows on the
	# horizon (it's one flat quad, so size costs nothing).
	var width: float = map_size * 2.6 / mesh_size
	sea.scale = Vector3(width, sea.scale.y, width)


# --- Height function ------------------------------------------------------

func _setup_noise() -> void:
	var noises: Array[FastNoiseLite] = [
		_hills, _warp, _region, _ridge, _detail, _tint, _temperature, _moisture, _dunes, _micro,
	]

	for i in noises.size():
		noises[i].seed = map_seed * 7 + i * 1013
		noises[i].noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH

	_hills.frequency = 1.0 / 650.0
	_hills.fractal_type = FastNoiseLite.FRACTAL_FBM
	_hills.fractal_octaves = 4

	_warp.frequency = 1.0 / 1100.0
	_region.frequency = 1.0 / 1400.0

	_ridge.frequency = 1.0 / 520.0
	_ridge.fractal_type = FastNoiseLite.FRACTAL_RIDGED
	_ridge.fractal_octaves = 3

	_detail.frequency = 1.0 / 90.0
	_tint.frequency = 1.0 / 160.0

	# Climate maps change slowly, so biomes form big regions.
	_temperature.frequency = 1.0 / 2600.0
	_moisture.frequency = 1.0 / 1600.0

	_dunes.frequency = 1.0 / 170.0
	_micro.frequency = 1.0 / 32.0


## How much of each biome is at (x, z), adding up to 1. Blends smoothly so
## there are no hard seams between biomes.
func _biome_weights(x: float, z: float) -> PackedFloat32Array:
	# Warp the climate maps so biome borders meander naturally.
	var wx: float = x + _warp.get_noise_2d(x * 0.6, z * 0.6) * 450.0
	var wz: float = z + _warp.get_noise_2d(x * 0.6 + 913.0, z * 0.6 - 377.0) * 450.0

	# Temperature runs mostly cold-to-hot across the map like latitude, with
	# noise only wobbling the borders - so going from desert to snow always
	# passes through temperate land, instead of jumping straight across.
	var across: float = clampf(Vector2(wx, wz).dot(_warm_direction) / (_half * 0.75), -1.0, 1.0)
	var variation: float = _temperature.get_noise_2d(wx, wz) * 1.4

	var climate := Vector2(
		clampf(lerpf(variation, across, climate_gradient), -1.0, 1.0),
		clampf(_moisture.get_noise_2d(wx, wz) * 1.9, -1.0, 1.0)
	)

	var weights := PackedFloat32Array()
	weights.resize(BIOME_CLIMATE.size())

	var total: float = 0.0
	var spread: float = 2.0 * biome_blend * biome_blend

	for i in BIOME_CLIMATE.size():
		var w: float = exp(-climate.distance_squared_to(BIOME_CLIMATE[i]) / spread)
		weights[i] = w
		total += w

	for i in weights.size():
		weights[i] /= maxf(total, 0.0001)

	return weights


## Terrain height above sea level at (x, z), before the start area is
## flattened.
func _raw_height(x: float, z: float) -> float:
	return _shape_height(x, z, _biome_weights(x, z))


func _shape_height(x: float, z: float, w: PackedFloat32Array) -> float:
	# Domain warp: bends the noise so hills and valleys snake around.
	var px: float = x + _warp.get_noise_2d(x, z) * 260.0
	var pz: float = z + _warp.get_noise_2d(x + 7919.0, z - 3571.0) * 260.0

	var hills: float = _hills.get_noise_2d(px, pz)
	var region: float = _region.get_noise_2d(x, z)
	var mountain_mask: float = smoothstep(0.05, 0.45, region)
	var plains_mask: float = smoothstep(0.0, 0.4, -region)

	var h: float = 0.0

	# Grassland: rolling hills with wide flat plains.
	if w[Biome.GRASSLAND] > 0.01:
		var g: float = base_height + hills * hill_height * 2.0
		g = lerpf(g, base_height * 0.8 + hills * 8.0, plains_mask)
		h += g * w[Biome.GRASSLAND]

	# Forest: gentler, slightly raised hills.
	if w[Biome.FOREST] > 0.01:
		h += (base_height + 4.0 + hills * hill_height * 1.3) * w[Biome.FOREST]

	# Desert: long dune ridges running in one direction, low overall -
	# low spots can dip under the sea level and become oasis lakes.
	if w[Biome.DESERT] > 0.01:
		var dx: float = px * 0.8 + pz * 0.6
		var dz: float = -px * 0.6 + pz * 0.8
		var dune: float = 1.0 - absf(_dunes.get_noise_2d(dx, dz * 0.3))
		h += (base_height * 0.7 + dune * dune * dune_height + hills * 10.0) * w[Biome.DESERT]

	# Badlands: high ground cut into flat-topped terraces with cliff steps.
	if w[Biome.BADLANDS] > 0.01:
		var b: float = base_height + 22.0 + hills * hill_height * 3.0
		var f: float = b / terrace_step
		# Flat mesa tops with short steep steps between them.
		b = (floor(f) + smoothstep(0.82, 0.97, f - floor(f))) * terrace_step
		h += b * w[Biome.BADLANDS]

	# Tundra: raised, smooth, snowy plains.
	if w[Biome.TUNDRA] > 0.01:
		h += (base_height + 8.0 + hills * hill_height * 1.1) * w[Biome.TUNDRA]

	# Mountain ranges rise through any biome - more in the cold, few in the
	# desert.
	var ridge: float = (_ridge.get_noise_2d(px, pz) + 1.0) * 0.5
	var mountain_scale: float = 1.0 + 0.4 * w[Biome.TUNDRA] - 0.7 * w[Biome.DESERT]
	h += ridge * ridge * mountain_height * mountain_mask * mountain_scale

	h += _detail.get_noise_2d(x, z) * 3.0 * (1.0 - 0.7 * w[Biome.DESERT])
	h += _micro.get_noise_2d(x, z) * micro_detail_height

	# Coastline all the way round, wobbled so it isn't a perfect circle.
	var d: float = Vector2(x, z).length() / _half
	d += _warp.get_noise_2d(x * 2.0, z * 2.0) * 0.12

	return lerpf(h, seabed_depth, smoothstep(coast_start, 0.98, d))


func _height_with_weights(x: float, z: float, w: PackedFloat32Array) -> float:
	var h: float = _shape_height(x, z, w)

	var dist: float = Vector2(x, z).distance_to(_spawn_center)

	var flatten: float = 1.0 - smoothstep(
		spawn_flat_radius * 0.55,
		spawn_flat_radius,
		dist
	)

	return lerpf(h, _spawn_height, flatten)


func _height(x: float, z: float) -> float:
	return _height_with_weights(x, z, _biome_weights(x, z))


func _choose_spawn() -> void:
	# Spiral out from the middle until we find dry, gently sloped ground.
	for step in 400:
		var angle: float = step * 2.4
		var radius: float = sqrt(float(step)) * 45.0
		var x: float = cos(angle) * radius
		var z: float = sin(angle) * radius

		var h: float = _raw_height(x, z)

		if h < 6.0 or h > 45.0:
			continue

		var slope: float = (
			absf(_raw_height(x + 30.0, z) - h) +
			absf(_raw_height(x, z + 30.0) - h)
		)

		if slope > 8.0:
			continue

		_spawn_center = Vector2(x, z)
		_spawn_height = h
		_spawn_yaw = _best_spawn_yaw()

		return

	_spawn_center = Vector2.ZERO
	_spawn_height = maxf(_raw_height(0.0, 0.0), 8.0)


## Faces the cars down the longest stretch of open, dry, drivable land,
## so nobody starts pointed straight at a lake or a cliff.
func _best_spawn_yaw() -> float:
	var best_yaw: float = 0.0
	var best_run: int = -1

	for d in 24:
		var yaw: float = TAU * d / 24.0
		# Car forward is -Z: yaw 0 drives toward -Z.
		var dir := Vector2(-sin(yaw), -cos(yaw))
		var previous: float = _spawn_height
		var run: int = 0

		for step in range(1, 26):
			var p: Vector2 = _spawn_center + dir * (step * 20.0)
			var h: float = _raw_height(p.x, p.y)

			if step * 20.0 < spawn_flat_radius:
				h = _spawn_height

			if h < 4.0 or absf(h - previous) > 10.0:
				break

			previous = h
			run += 1

		if run > best_run:
			best_run = run
			best_yaw = yaw

	return best_yaw


func _build_height_grid() -> void:
	var n1: int = _grid_n + 1
	var count: int = n1 * n1

	_heights.resize(count)
	_colors.resize(count)
	_badlands_weight.resize(count)
	_tundra_weight.resize(count)

	var land_cells: int = 0
	var coverage := PackedFloat32Array([0, 0, 0, 0, 0])

	# Climate on a coarse grid first (see climate_step).
	var step: int = maxi(climate_step, 1)
	var cn: int = int(ceil(float(_grid_n) / step)) + 1
	var coarse: Array[PackedFloat32Array] = []
	coarse.resize(cn * cn)
	_coarse_weights = coarse
	_coarse_n = cn
	_coarse_step = step

	for cj in cn:
		for ci in cn:
			coarse[cj * cn + ci] = _biome_weights(
				-_half + ci * step * cell_size,
				-_half + cj * step * cell_size
			)

	var w := PackedFloat32Array([0, 0, 0, 0, 0])
	var biome_count: int = w.size()

	for j in n1:
		var z: float = -_half + j * cell_size
		var cj: int = mini(j / step, cn - 2)
		var v: float = float(j - cj * step) / step

		for i in n1:
			var x: float = -_half + i * cell_size
			var k: int = j * n1 + i

			# Blend the four surrounding coarse climate samples.
			var ci: int = mini(i / step, cn - 2)
			var u: float = float(i - ci * step) / step
			var w00: PackedFloat32Array = coarse[cj * cn + ci]
			var w10: PackedFloat32Array = coarse[cj * cn + ci + 1]
			var w01: PackedFloat32Array = coarse[(cj + 1) * cn + ci]
			var w11: PackedFloat32Array = coarse[(cj + 1) * cn + ci + 1]

			for b in biome_count:
				w[b] = lerpf(lerpf(w00[b], w10[b], u), lerpf(w01[b], w11[b], u), v)

			var h: float = _height_with_weights(x, z, w)

			_heights[k] = h
			_colors[k] = _biome_colour(x, z, h, w)
			_badlands_weight[k] = w[Biome.BADLANDS]
			_tundra_weight[k] = w[Biome.TUNDRA]

			if h > 2.0 and i < _grid_n and j < _grid_n:
				land_cells += 1

				for b in coverage.size():
					coverage[b] += w[b]

	land_area_km2 = land_cells * cell_size * cell_size / 1000000.0

	for b in coverage.size():
		biome_coverage[b] = coverage[b] / maxf(land_cells, 1.0)


## Ground colour for the biome mix at a point, before slope and height
## (rock, snow, beach) are taken into account.
func _biome_colour(x: float, z: float, h: float, w: PackedFloat32Array) -> Color:
	var tint: float = _tint.get_noise_2d(x, z) * 0.5 + 0.5
	var color := Color(0, 0, 0)

	if w[Biome.GRASSLAND] > 0.01:
		var g: Color = Color(0.17, 0.36, 0.15).lerp(Color(0.29, 0.5, 0.2), tint)
		g = g.lerp(Color(0.47, 0.46, 0.25), smoothstep(0.7, 0.95, tint) * 0.6)
		color += g * w[Biome.GRASSLAND]

	if w[Biome.FOREST] > 0.01:
		color += Color(0.1, 0.25, 0.1).lerp(Color(0.17, 0.33, 0.13), tint) * w[Biome.FOREST]

	if w[Biome.DESERT] > 0.01:
		color += Color(0.8, 0.66, 0.42).lerp(Color(0.9, 0.78, 0.53), tint) * w[Biome.DESERT]

	if w[Biome.BADLANDS] > 0.01:
		# Rock strata: bands of colour that follow the height.
		var band: float = sin(h * 0.55) * 0.5 + 0.5
		var b: Color = Color(0.62, 0.24, 0.12).lerp(Color(0.8, 0.42, 0.2), band)
		b = b.lerp(Color(0.46, 0.18, 0.1), smoothstep(0.6, 0.9, tint) * 0.5)
		color += b * w[Biome.BADLANDS]

	if w[Biome.TUNDRA] > 0.01:
		var t: Color = Color(0.86, 0.9, 0.95).lerp(Color(0.52, 0.56, 0.52), smoothstep(0.62, 0.9, tint) * 0.7)
		color += t * w[Biome.TUNDRA]

	color.a = 1.0
	return color


## Second pass: rock on steep slopes, snow on peaks, beaches and seabed.
## Needs the finished height grid to work out slopes.
func _colour_grid() -> void:
	var n1: int = _grid_n + 1

	for j in n1:
		for i in n1:
			var k: int = j * n1 + i
			var h: float = _heights[k]

			var hx: float = _grid_height(mini(i + 1, _grid_n), j) - _grid_height(maxi(i - 1, 0), j)
			var hz: float = _grid_height(i, mini(j + 1, _grid_n)) - _grid_height(i, maxi(j - 1, 0))
			var up: float = Vector3(-hx, 2.0 * cell_size, -hz).normalized().y

			var color: Color = _colors[k]
			var tundra: float = _tundra_weight[k]

			if h < 0.0:
				color = Color(0.42, 0.4, 0.31)
			elif h < 3.0:
				# Beaches: sand, or grey gravel on cold shores.
				var shore: Color = Color(0.7, 0.63, 0.43).lerp(Color(0.55, 0.56, 0.55), tundra)
				color = shore.lerp(color, smoothstep(1.5, 3.0, h))

			# Steep slopes show bare rock - red in the badlands, grey elsewhere.
			var rock: Color = Color(0.38, 0.36, 0.34).lerp(Color(0.48, 0.2, 0.12), _badlands_weight[k])
			var rockiness: float = maxf(smoothstep(0.82, 0.68, up), smoothstep(90.0, 130.0, h))
			color = color.lerp(rock, rockiness)

			# Snow on the highest peaks (lower down in the cold).
			var snow_line: float = lerpf(150.0, 80.0, tundra)
			color = color.lerp(Color(0.93, 0.94, 0.96), smoothstep(snow_line, snow_line + 25.0, h) * smoothstep(0.6, 0.8, up))

			_colors[k] = color


## Biome weights anywhere on the map, blended from the coarse climate grid -
## much cheaper than working the climate out from scratch.
func _weights_at(x: float, z: float) -> PackedFloat32Array:
	var span: float = _coarse_step * cell_size
	var fx: float = clampf((x + _half) / span, 0.0, _coarse_n - 1.001)
	var fz: float = clampf((z + _half) / span, 0.0, _coarse_n - 1.001)
	var ci: int = int(fx)
	var cj: int = int(fz)
	var u: float = fx - ci
	var v: float = fz - cj

	var w00: PackedFloat32Array = _coarse_weights[cj * _coarse_n + ci]
	var w10: PackedFloat32Array = _coarse_weights[cj * _coarse_n + ci + 1]
	var w01: PackedFloat32Array = _coarse_weights[(cj + 1) * _coarse_n + ci]
	var w11: PackedFloat32Array = _coarse_weights[(cj + 1) * _coarse_n + ci + 1]

	var w := PackedFloat32Array([0, 0, 0, 0, 0])

	for b in w.size():
		w[b] = lerpf(lerpf(w00[b], w10[b], u), lerpf(w01[b], w11[b], u), v)

	return w


func _grid_colour(i: int, j: int) -> Color:
	return _colors[j * (_grid_n + 1) + i]


func _grid_height(i: int, j: int) -> float:
	return _heights[j * (_grid_n + 1) + i]


## Interpolated terrain height (above sea level) at any point, matching
## the triangles that were actually built.
func height_at(x: float, z: float) -> float:
	var fx: float = clampf((x + _half) / cell_size, 0.0, _grid_n - 0.001)
	var fz: float = clampf((z + _half) / cell_size, 0.0, _grid_n - 0.001)
	var i: int = int(fx)
	var j: int = int(fz)
	var u: float = fx - i
	var v: float = fz - j

	var a: float = _grid_height(i, j)
	var b: float = _grid_height(i + 1, j)
	var c: float = _grid_height(i, j + 1)
	var d: float = _grid_height(i + 1, j + 1)

	# Same diagonal split as the mesh: triangles (a, b, c) and (b, d, c).
	if u + v <= 1.0:
		return a + (b - a) * u + (c - a) * v

	return d + (c - d) * (1.0 - u) + (b - d) * (1.0 - v)


# --- Terrain mesh -----------------------------------------------------------


# --- Terrain mesh -----------------------------------------------------------

func _setup_materials() -> void:
	_terrain_material = StandardMaterial3D.new()
	_terrain_material.vertex_color_use_as_albedo = true
	_terrain_material.roughness = 0.95
	_terrain_material.cull_mode = BaseMaterial3D.CULL_DISABLED

	# Ramps carry their own colours (planks, curbs, lip stripe).
	_ramp_material = StandardMaterial3D.new()
	_ramp_material.vertex_color_use_as_albedo = true
	_ramp_material.roughness = 0.85

	# Trees and rocks: colour comes from each instance.
	_prop_material = StandardMaterial3D.new()
	_prop_material.vertex_color_use_as_albedo = true
	_prop_material.roughness = 0.9

	_trunk_material = StandardMaterial3D.new()
	_trunk_material.albedo_color = Color(0.36, 0.25, 0.16)
	_trunk_material.roughness = 0.95


func _build_terrain_chunks() -> void:
	var body := StaticBody3D.new()
	body.name = "TerrainBody"
	add_child(body)

	var chunks: int = int(ceil(float(_grid_n) / chunk_cells))

	for cz in chunks:
		for cx in chunks:
			_build_chunk(body, cx * chunk_cells, cz * chunk_cells)


func _build_chunk(body: StaticBody3D, i0: int, j0: int) -> void:
	var i1: int = mini(i0 + chunk_cells, _grid_n)
	var j1: int = mini(j0 + chunk_cells, _grid_n)

	var cell_count: int = (i1 - i0) * (j1 - j0)

	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()

	vertices.resize(cell_count * 6)
	normals.resize(cell_count * 6)
	colors.resize(cell_count * 6)

	var k: int = 0

	for j in range(j0, j1):
		var z0: float = -_half + j * cell_size
		var z1: float = z0 + cell_size

		for i in range(i0, i1):
			var x0: float = -_half + i * cell_size
			var x1: float = x0 + cell_size

			var a := Vector3(x0, _sea_level + _grid_height(i, j), z0)
			var b := Vector3(x1, _sea_level + _grid_height(i + 1, j), z0)
			var c := Vector3(x0, _sea_level + _grid_height(i, j + 1), z1)
			var d := Vector3(x1, _sea_level + _grid_height(i + 1, j + 1), z1)

			var ca: Color = _grid_colour(i, j)
			var cb: Color = _grid_colour(i + 1, j)
			var cc: Color = _grid_colour(i, j + 1)
			var cd: Color = _grid_colour(i + 1, j + 1)

			# Two flat-shaded triangles per square, clockwise from above
			# (Godot's front-face winding). Written out inline rather than
			# through a helper: this runs hundreds of thousands of times.
			var n1: Vector3 = (c - a).cross(b - a).normalized()
			var n2: Vector3 = (c - b).cross(d - b).normalized()

			# Slight per-face brightness change for the faceted look.
			var jitter: float = (fmod(absf(sin(i * 25.9796 + j * 78.233) * 43758.5453), 1.0) - 0.5) * 0.06
			var col1: Color = (ca + cb + cc) / 3.0
			var col2: Color = (cb + cd + cc) / 3.0
			col1 = Color(col1.r + jitter, col1.g + jitter, col1.b + jitter)
			col2 = Color(col2.r - jitter, col2.g - jitter, col2.b - jitter)

			vertices[k] = a
			vertices[k + 1] = b
			vertices[k + 2] = c
			vertices[k + 3] = b
			vertices[k + 4] = d
			vertices[k + 5] = c

			normals[k] = n1
			normals[k + 1] = n1
			normals[k + 2] = n1
			normals[k + 3] = n2
			normals[k + 4] = n2
			normals[k + 5] = n2

			colors[k] = col1
			colors[k + 1] = col1
			colors[k + 2] = col1
			colors[k + 3] = col2
			colors[k + 4] = col2
			colors[k + 5] = col2

			k += 6

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, _terrain_material)

	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = "Chunk_%d_%d" % [i0, j0]
	mesh_instance.mesh = mesh
	add_child(mesh_instance)

	# Collision uses the exact same triangles that are drawn, so the car
	# never drives on ground that differs from what you see.
	var shape := ConcavePolygonShape3D.new()
	shape.set_faces(vertices)
	shape.backface_collision = true

	var collision := CollisionShape3D.new()
	collision.shape = shape
	body.add_child(collision)


func _write_triangle(
	vertices: PackedVector3Array,
	normals: PackedVector3Array,
	colors: PackedColorArray,
	k: int,
	p0: Vector3,
	p1: Vector3,
	p2: Vector3,
	color: Color,
	face_i: int,
	face_j: int
) -> int:
	var normal: Vector3 = (p2 - p0).cross(p1 - p0).normalized()

	if normal.y < 0.0:
		normal = -normal

	# Slight per-face brightness change for the faceted low-poly look.
	var jitter: float = (
		fmod(absf(sin(face_i * 12.9898 + face_j * 78.233) * 43758.5453), 1.0)
		- 0.5
	) * 0.06

	var face_color := Color(
		clampf(color.r + jitter, 0.0, 1.0),
		clampf(color.g + jitter, 0.0, 1.0),
		clampf(color.b + jitter, 0.0, 1.0)
	)

	vertices[k] = p0
	vertices[k + 1] = p1
	vertices[k + 2] = p2

	for n in 3:
		normals[k + n] = normal
		colors[k + n] = face_color

	return k + 3


# --- Ramps ------------------------------------------------------------------

func _place_ramps() -> void:
	var placed: Array[Vector2] = _ramp_spots
	var attempts: int = 0

	while placed.size() < ramp_count and attempts < ramp_count * 60:
		attempts += 1

		var x: float = _rng.randf_range(-_half * 0.85, _half * 0.85)
		var z: float = _rng.randf_range(-_half * 0.85, _half * 0.85)
		var spot := Vector2(x, z)

		if spot.distance_to(_spawn_center) < spawn_flat_radius + 60.0:
			continue

		var too_close: bool = false

		for other in placed:
			if spot.distance_to(other) < 90.0:
				too_close = true
				break

		if too_close:
			continue

		var big: bool = _rng.randf() < big_ramp_fraction
		var length: float = _rng.randf_range(18.0, 24.0) if big else _rng.randf_range(13.0, 20.0)
		var width: float = _rng.randf_range(8.0, 12.0)
		var height: float = _rng.randf_range(6.0, 8.5) if big else _rng.randf_range(3.0, 5.5)
		var yaw: float = _rng.randf() * TAU

		var basis := Basis(Vector3.UP, yaw)
		var forward: Vector3 = -basis.z
		var right: Vector3 = basis.x

		# Needs dry, fairly level ground under the whole footprint.
		var lowest: float = INF
		var highest: float = -INF

		for corner in [
			forward * length * 0.5 + right * width * 0.5,
			forward * length * 0.5 - right * width * 0.5,
			-forward * length * 0.5 + right * width * 0.5,
			-forward * length * 0.5 - right * width * 0.5,
		]:
			var c: Vector3 = corner
			var ch: float = height_at(x + c.x, z + c.z)
			lowest = minf(lowest, ch)
			highest = maxf(highest, ch)

		if lowest < 4.0 or highest - lowest > 2.5:
			continue

		# The ramp starts flush with the ground where you drive onto it.
		var centre := Vector2(x, z)
		var fwd2 := Vector2(forward.x, forward.z)
		var right2 := Vector2(right.x, right.z)
		var entry: Vector2 = centre - fwd2 * length * 0.5
		var entry_height: float = height_at(entry.x, entry.y)
		var base: float = entry_height - 0.15

		# The ground must never rise through the ramp - otherwise the start
		# of it is buried and the car hits a lump of terrain instead of a
		# smooth ramp. Flat or falling ground is fine (a bigger drop off
		# the lip).
		var buried: bool = false
		var inner: float = width * 0.5 - 0.6

		for i in 13:
			var t: float = i / 12.0
			var surface: float = base + height * pow(t, RAMP_CURVE)

			for side in [-inner, 0.0, inner]:
				var p: Vector2 = entry + fwd2 * length * t + right2 * side
				var allowed: float = surface + (0.35 if i == 0 else 0.05)

				if height_at(p.x, p.y) > allowed:
					buried = true
					break

			if buried:
				break

		# And no hump in the run-up just before it.
		var run_up: Vector2 = entry - fwd2 * 10.0

		if buried or height_at(run_up.x, run_up.y) > entry_height + 1.0:
			continue

		# Walls reach down to the lowest ground anywhere under the ramp (not
		# just its corners - a valley or bump between them can dip lower),
		# so it never floats with its underside showing.
		var ground_low: float = lowest

		for gi in 5:
			for gj in 5:
				var p: Vector2 = entry + fwd2 * length * (gi / 4.0) + right2 * width * (gj / 4.0 - 0.5)
				ground_low = minf(ground_low, height_at(p.x, p.y))

		var foundation: float = (entry_height - ground_low) + 0.8

		_build_ramp(Vector3(x, _sea_level + base, z), basis, length, width, height, foundation)
		placed.append(spot)

		# Keep props off a ~30 m patch around every ramp.
		var cell := Vector2i(floori(x / 30.0), floori(z / 30.0))

		for dj in range(-1, 2):
			for di in range(-1, 2):
				_ramp_cells[cell + Vector2i(di, dj)] = true


func _build_ramp(
	origin: Vector3,
	basis: Basis,
	length: float,
	width: float,
	height: float,
	foundation: float = 0.5
) -> void:
	# A curved kicker: flat where you drive on at the back (+Z), curving up
	# to a steeper lip at the front (-Z). Racing curbs along both edges, a
	# yellow stripe on the lip, and plank lines across the surface.
	var hw: float = width * 0.5
	var hl: float = length * 0.5
	var curb_width: float = 0.45
	var curb_height: float = 0.22
	var segments: int = 12

	var tris := PackedVector3Array()
	var colors := PackedColorArray()

	var plank_a := Color(0.58, 0.48, 0.38)
	var plank_b := Color(0.52, 0.43, 0.34)
	var lip_color := Color(0.95, 0.78, 0.15)
	var wall_color := Color(0.36, 0.3, 0.25)
	var curb_red := Color(0.8, 0.12, 0.1)
	var curb_white := Color(0.92, 0.92, 0.9)

	for i in segments:
		var t0: float = float(i) / segments
		var t1: float = float(i + 1) / segments
		var z0: float = hl - t0 * length
		var z1: float = hl - t1 * length
		var y0: float = height * pow(t0, RAMP_CURVE)
		var y1: float = height * pow(t1, RAMP_CURVE)
		var inner: float = hw - curb_width

		# Driving surface.
		var surface: Color = lip_color if i == segments - 1 else (plank_a if i % 2 == 0 else plank_b)
		_ramp_quad(tris, colors,
			Vector3(-inner, y0, z0), Vector3(inner, y0, z0),
			Vector3(inner, y1, z1), Vector3(-inner, y1, z1),
			Vector3.UP, surface)

		var curb: Color = curb_red if i % 2 == 0 else curb_white

		for side in [-1.0, 1.0]:
			var outer_x: float = hw * side
			var inner_x: float = inner * side

			# Curb top.
			_ramp_quad(tris, colors,
				Vector3(inner_x, y0 + curb_height, z0), Vector3(outer_x, y0 + curb_height, z0),
				Vector3(outer_x, y1 + curb_height, z1), Vector3(inner_x, y1 + curb_height, z1),
				Vector3.UP, curb)

			# Curb's inner face, facing the driving surface.
			_ramp_quad(tris, colors,
				Vector3(inner_x, y0, z0), Vector3(inner_x, y1, z1),
				Vector3(inner_x, y1 + curb_height, z1), Vector3(inner_x, y0 + curb_height, z0),
				Vector3(-side, 0.0, 0.0), curb * 0.8)

			# Side wall, from below ground up to the top of the curb.
			_ramp_quad(tris, colors,
				Vector3(outer_x, -foundation, z0), Vector3(outer_x, -foundation, z1),
				Vector3(outer_x, y1 + curb_height, z1), Vector3(outer_x, y0 + curb_height, z0),
				Vector3(side, 0.0, 0.0), wall_color)

	# The drop at the front, below the lip. Only as tall as the driving
	# surface across the middle - raising it to curb height there would
	# leave a little wall sticking up right at take-off.
	var inner_w: float = hw - curb_width
	_ramp_quad(tris, colors,
		Vector3(-inner_w, -foundation, -hl), Vector3(inner_w, -foundation, -hl),
		Vector3(inner_w, height, -hl), Vector3(-inner_w, height, -hl),
		Vector3.FORWARD, wall_color * 0.85)

	for side in [-1.0, 1.0]:
		_ramp_quad(tris, colors,
			Vector3(inner_w * side, -foundation, -hl), Vector3(hw * side, -foundation, -hl),
			Vector3(hw * side, height + curb_height, -hl), Vector3(inner_w * side, height + curb_height, -hl),
			Vector3.FORWARD, wall_color * 0.85)

	# Close off the entry end below the driving surface, and the bottom, so
	# the ramp is a solid block - its inside can't be seen from any angle.
	_ramp_quad(tris, colors,
		Vector3(-hw, -foundation, hl), Vector3(hw, -foundation, hl),
		Vector3(hw, 0.0, hl), Vector3(-hw, 0.0, hl),
		Vector3.BACK, wall_color * 0.85)

	for side in [-1.0, 1.0]:
		var inner_end: float = (hw - curb_width) * side

		# End of each curb at the entry.
		_ramp_quad(tris, colors,
			Vector3(inner_end, 0.0, hl), Vector3(hw * side, 0.0, hl),
			Vector3(hw * side, curb_height, hl), Vector3(inner_end, curb_height, hl),
			Vector3.BACK, curb_red)

	_ramp_quad(tris, colors,
		Vector3(-hw, -foundation, hl), Vector3(hw, -foundation, hl),
		Vector3(hw, -foundation, -hl), Vector3(-hw, -foundation, -hl),
		Vector3.DOWN, wall_color * 0.7)

	var normals := PackedVector3Array()

	for i in range(0, tris.size(), 3):
		var n: Vector3 = (tris[i + 2] - tris[i]).cross(tris[i + 1] - tris[i]).normalized()
		normals.append(n)
		normals.append(n)
		normals.append(n)

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = tris
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, _ramp_material)

	var ramp := StaticBody3D.new()
	ramp.name = "Ramp"
	ramp.transform = Transform3D(basis, origin)
	add_child(ramp)

	var mesh_instance := MeshInstance3D.new()
	mesh_instance.mesh = mesh
	ramp.add_child(mesh_instance)

	# Collision follows the exact curve.
	var shape := ConcavePolygonShape3D.new()
	shape.set_faces(tris)
	shape.backface_collision = true

	var collision := CollisionShape3D.new()
	collision.shape = shape
	ramp.add_child(collision)

	# Let the target spawner put targets in the air off the end of this
	# ramp - so ramps are guaranteed to have something to aim for. The lip
	# angle comes from the slope of the curve at its end.
	if target_spawner != null:
		var launch_point: Vector3 = ramp.transform * Vector3(0.0, height, -hl)
		var incline: float = rad_to_deg(atan(RAMP_CURVE * height / length))
		target_spawner.add_jump_site(launch_point, -basis.z, incline)


## Adds a quad as two triangles, wound so its face points along `facing`.
func _ramp_quad(
	tris: PackedVector3Array,
	colors: PackedColorArray,
	a: Vector3,
	b: Vector3,
	c: Vector3,
	d: Vector3,
	facing: Vector3,
	color: Color
) -> void:
	for tri in [[a, b, c], [a, c, d]]:
		var p0: Vector3 = tri[0]
		var p1: Vector3 = tri[1]
		var p2: Vector3 = tri[2]

		# Godot's front faces are clockwise as seen from the front.
		if (p2 - p0).cross(p1 - p0).dot(facing) < 0.0:
			var swap: Vector3 = p1
			p1 = p2
			p2 = swap

		tris.append(p0)
		tris.append(p1)
		tris.append(p2)

		for k in 3:
			colors.append(color)


# --- Cars & spawners --------------------------------------------------------


# --- Trees and rocks --------------------------------------------------------

func _place_props() -> void:
	# Tiles of props: {mesh_key: {tile: {"t": [Transform3D], "c": [Color]}}}
	var pine_tiles: Array[Dictionary] = [{}, {}]
	var custom_tiles: Array[Dictionary] = []
	var rock_tiles: Dictionary = {}

	for i in custom_tree_meshes.size():
		custom_tiles.append({})

	var body := StaticBody3D.new()
	body.name = "Props"
	body.collision_layer = 1 << (PROP_LAYER - 1)
	body.collision_mask = 0
	add_child(body)

	var area_km2: float = map_size * map_size / 1000000.0
	var tree_attempts: int = int(forest_density * area_km2)
	var rock_attempts: int = int(rock_density * area_km2)

	# Past this distance from the centre it's open sea (coastline plus its
	# wobble), so candidates out there can be skipped without any checks.
	var land_reach: float = _half * minf(0.98 + 0.12, 1.4)
	var land_reach_sq: float = land_reach * land_reach

	var shapes: Dictionary = {}
	var body_rid: RID = body.get_rid()
	var custom_heights: Array[float] = []

	for mesh in custom_tree_meshes:
		custom_heights.append(maxf(mesh.get_aabb().size.y, 0.1) if mesh != null else 1.0)

	for n in tree_attempts:
		var x: float = _rng.randf_range(-_half * 0.95, _half * 0.95)
		var z: float = _rng.randf_range(-_half * 0.95, _half * 0.95)

		# Quick reject: well out past the coastline is always sea.
		if x * x + z * z > land_reach_sq:
			continue

		var w: PackedFloat32Array = _weights_at(x, z)

		var chance: float = w[Biome.FOREST] + w[Biome.TUNDRA] * 0.2 + w[Biome.GRASSLAND] * 0.08

		if _rng.randf() > chance or not _prop_spot_ok(x, z, 4.0, 2.0):
			continue

		var ground: float = _sea_level + height_at(x, z) - 0.3
		var yaw := Basis(Vector3.UP, _rng.randf() * TAU)
		var tile := Vector2i(floori(x / prop_tile_size), floori(z / prop_tile_size))

		# Broadleaf (your models) in grassland and partly in forest; pines
		# everywhere else, and always in the cold.
		var broadleaf_weight: float = w[Biome.GRASSLAND] * 0.85 + w[Biome.FOREST] * custom_tree_forest_share
		var pine_weight: float = w[Biome.FOREST] * (1.0 - custom_tree_forest_share) + w[Biome.TUNDRA] + w[Biome.GRASSLAND] * 0.15
		var use_custom: bool = (
			not custom_tree_meshes.is_empty()
			and _rng.randf() * (broadleaf_weight + pine_weight) < broadleaf_weight
		)

		var trunk_radius: float
		var trunk_height: float

		if use_custom:
			var index: int = _rng.randi() % custom_tree_meshes.size()
			var target_height: float = _rng.randf_range(custom_tree_min_height, custom_tree_max_height)
			var s: float = target_height / custom_heights[index]

			# Gentle per-tree tint so a grove isn't one identical colour.
			var tint := Color(1, 1, 1).lerp(Color(0.85, 1.0, 0.8), _rng.randf()) * _rng.randf_range(0.85, 1.08)
			tint.a = 1.0

			_add_to_tile(custom_tiles[index], tile, Transform3D(yaw.scaled(Vector3.ONE * s), Vector3(x, ground + 0.25, z)), tint)

			trunk_radius = maxf(0.3, 0.28 * s)
			trunk_height = target_height * 0.45
		else:
			var variant: int = _rng.randi() % 2
			var size: float = _rng.randf_range(0.8, 1.45)

			# Snow-dusted pines in the cold, deep green elsewhere.
			var green := Color(0.12, 0.3, 0.13).lerp(Color(0.2, 0.4, 0.17), _rng.randf())
			green = green.lerp(Color(0.78, 0.84, 0.86), w[Biome.TUNDRA] * 0.8)

			_add_to_tile(pine_tiles[variant], tile, Transform3D(yaw.scaled(Vector3.ONE * size), Vector3(x, ground, z)), green)

			trunk_radius = 0.45 * size
			trunk_height = 7.0 * size

		tree_count += 1

		# Collision straight into the physics engine (no scene node per
		# tree), with one shared shape per size step.
		var key := Vector2i(roundi(trunk_radius * 10.0), roundi(trunk_height * 2.0))
		var cylinder: CylinderShape3D = shapes.get(key)

		if cylinder == null:
			cylinder = CylinderShape3D.new()
			cylinder.radius = key.x / 10.0
			cylinder.height = key.y / 2.0
			shapes[key] = cylinder
			_prop_shapes.append(cylinder)

		PhysicsServer3D.body_add_shape(
			body_rid,
			cylinder.get_rid(),
			Transform3D(Basis(), Vector3(x, ground + cylinder.height * 0.5, z))
		)

	for n in rock_attempts:
		var x: float = _rng.randf_range(-_half * 0.95, _half * 0.95)
		var z: float = _rng.randf_range(-_half * 0.95, _half * 0.95)

		# Quick reject: well out past the coastline is always sea.
		if x * x + z * z > land_reach_sq:
			continue

		var w: PackedFloat32Array = _weights_at(x, z)
		var h: float = height_at(x, z)

		var chance: float = w[Biome.BADLANDS] + smoothstep(60.0, 110.0, h) * 0.25

		if _rng.randf() > chance or not _prop_spot_ok(x, z, 6.0, 6.0):
			continue

		var size: float = _rng.randf_range(1.2, 3.6)
		var stretch := Vector3(_rng.randf_range(0.8, 1.3), _rng.randf_range(0.55, 0.9), _rng.randf_range(0.8, 1.3))
		var basis := Basis(Vector3.UP, _rng.randf() * TAU).scaled(stretch * size)
		var ground: float = _sea_level + h

		var rock_color := Color(0.42, 0.4, 0.38).lerp(Color(0.52, 0.24, 0.14), w[Biome.BADLANDS])
		rock_color = rock_color.lerp(Color(0.3, 0.28, 0.27), _rng.randf() * 0.4)

		var tile := Vector2i(floori(x / prop_tile_size), floori(z / prop_tile_size))
		_add_to_tile(rock_tiles, tile, Transform3D(basis, Vector3(x, ground, z)), rock_color)
		rock_count += 1

		var rock_step: int = roundi(size * 2.0)
		var sphere: SphereShape3D = shapes.get(rock_step)

		if sphere == null:
			sphere = SphereShape3D.new()
			sphere.radius = rock_step / 2.0 * 0.85
			shapes[rock_step] = sphere
			_prop_shapes.append(sphere)

		PhysicsServer3D.body_add_shape(
			body_rid,
			sphere.get_rid(),
			Transform3D(Basis(), Vector3(x, ground + size * 0.3, z))
		)

	# Pines: trunks and leaves are separate so trunks stay brown while each
	# tree's leaves get their own shade.
	for variant in 2:
		_add_tiled_multimesh("PineTrunks%d" % variant, _build_pine_trunk_mesh(variant), pine_tiles[variant], false, _trunk_material, pine_draw_distance)
		_add_tiled_multimesh("PineLeaves%d" % variant, _build_pine_leaves_mesh(variant), pine_tiles[variant], true, _prop_material, pine_draw_distance)

	for i in custom_tree_meshes.size():
		if custom_tree_meshes[i] != null:
			_add_tiled_multimesh("CustomTree%d" % i, _tintable(custom_tree_meshes[i]), custom_tiles[i], true, null, custom_tree_draw_distance)

	_add_tiled_multimesh("Rocks", _build_rock_mesh(), rock_tiles, true, _prop_material, rock_draw_distance)


func _add_to_tile(tiles: Dictionary, tile: Vector2i, transform: Transform3D, color: Color) -> void:
	if not tiles.has(tile):
		tiles[tile] = {"t": [], "c": []}

	tiles[tile].t.append(transform)
	tiles[tile].c.append(color)


## A copy of a mesh whose materials take each tree's instance tint.
func _tintable(mesh: Mesh) -> Mesh:
	var copy: Mesh = mesh.duplicate()

	for i in copy.get_surface_count():
		var material := copy.surface_get_material(i)

		if material is BaseMaterial3D:
			var tinted: BaseMaterial3D = material.duplicate()
			tinted.vertex_color_use_as_albedo = true
			copy.surface_set_material(i, tinted)

	return copy


## One MultiMeshInstance per map tile, each only drawn within
## draw_distance - so props behind the camera or far away cost nothing.
func _add_tiled_multimesh(
	label: String,
	mesh: Mesh,
	tiles: Dictionary,
	use_colors: bool,
	material: Material,
	draw_distance: float
) -> void:
	for tile in tiles:
		var transforms: Array = tiles[tile].t
		var colors: Array = tiles[tile].c

		var multimesh := MultiMesh.new()
		multimesh.transform_format = MultiMesh.TRANSFORM_3D
		multimesh.use_colors = use_colors
		multimesh.mesh = mesh
		multimesh.instance_count = transforms.size()

		for i in transforms.size():
			multimesh.set_instance_transform(i, transforms[i])

			if use_colors:
				multimesh.set_instance_color(i, colors[i])

		var instance := MultiMeshInstance3D.new()
		instance.name = "%s_%d_%d" % [label, tile.x, tile.y]
		instance.multimesh = multimesh

		if material != null:
			instance.material_override = material

		instance.visibility_range_end = draw_distance
		instance.visibility_range_end_margin = draw_distance * 0.1
		add_child(instance)


## Whether a prop can go at (x, z): dry land, not too steep, and clear of
## the start area and the ramps.
func _prop_spot_ok(x: float, z: float, probe: float, max_rise: float) -> bool:
	var h: float = height_at(x, z)

	if h < 3.5:
		return false

	if absf(height_at(x + probe, z) - h) > max_rise or absf(height_at(x, z + probe) - h) > max_rise:
		return false

	var spot := Vector2(x, z)

	if spot.distance_to(_spawn_center) < spawn_flat_radius + 25.0:
		return false

	if _ramp_cells.has(Vector2i(floori(x / 30.0), floori(z / 30.0))):
		return false

	return true


## Pine trunk, flat shaded. Variant 0 is tall and slim, variant 1 bushy.
func _build_pine_trunk_mesh(variant: int) -> ArrayMesh:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)

	if variant == 0:
		_append_cone(tool, 0.34, 0.2, 2.6, 0.0, 7)
	else:
		_append_cone(tool, 0.4, 0.26, 2.0, 0.0, 7)

	tool.generate_normals()
	return tool.commit()


## Pine leaves: several stacked tiers with jagged, slightly drooping edges,
## flat shaded. Variant 0 is tall and slim, variant 1 bushy.
func _build_pine_leaves_mesh(variant: int) -> ArrayMesh:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)

	if variant == 0:
		_append_tier(tool, 2.2, 3.2, 1.6, 10)
		_append_tier(tool, 1.8, 2.9, 3.2, 10)
		_append_tier(tool, 1.4, 2.6, 4.7, 9)
		_append_tier(tool, 0.95, 2.3, 6.1, 8)
	else:
		_append_tier(tool, 2.8, 3.4, 1.2, 11)
		_append_tier(tool, 2.2, 3.0, 2.9, 10)
		_append_tier(tool, 1.5, 2.6, 4.4, 9)

	tool.generate_normals()
	return tool.commit()


## One pine tier: a cone whose rim alternates between full and shorter
## points (a jagged, needly edge) and droops a little at the tips.
func _append_tier(tool: SurfaceTool, radius: float, height: float, y0: float, points: int) -> void:
	var apex := Vector3(0.0, y0 + height, 0.0)
	var centre := Vector3(0.0, y0 + height * 0.15, 0.0)
	var rim: Array[Vector3] = []

	for p in points * 2:
		var angle: float = TAU * p / (points * 2)
		var tip: bool = p % 2 == 0
		var r: float = radius if tip else radius * 0.72
		var droop: float = -0.25 if tip else 0.15
		rim.append(Vector3(cos(angle) * r, y0 + droop, sin(angle) * r))

	for p in rim.size():
		var b0: Vector3 = rim[p]
		var b1: Vector3 = rim[(p + 1) % rim.size()]

		# Outward-facing (clockwise from outside).
		tool.add_vertex(b0)
		tool.add_vertex(b1)
		tool.add_vertex(apex)

		# Underside.
		tool.add_vertex(b0)
		tool.add_vertex(centre)
		tool.add_vertex(b1)


## Low-poly boulder: a squashed, chunky sphere.
func _build_rock_mesh() -> ArrayMesh:
	var sphere := SphereMesh.new()
	sphere.radius = 1.0
	sphere.height = 1.6
	sphere.radial_segments = 7
	sphere.rings = 4

	var tool := SurfaceTool.new()
	tool.create_from(sphere, 0)
	tool.deindex()
	tool.generate_normals()
	return tool.commit()


## Adds a flat-shaded cone/frustum (top_radius 0 = cone) standing at height
## y0 to the surface being built.
func _append_cone(
	tool: SurfaceTool,
	bottom_radius: float,
	top_radius: float,
	height: float,
	y0: float,
	sides: int
) -> void:
	for s in sides:
		var a0: float = TAU * s / sides
		var a1: float = TAU * (s + 1) / sides
		var b0 := Vector3(cos(a0) * bottom_radius, y0, sin(a0) * bottom_radius)
		var b1 := Vector3(cos(a1) * bottom_radius, y0, sin(a1) * bottom_radius)
		var t0 := Vector3(cos(a0) * top_radius, y0 + height, sin(a0) * top_radius)
		var t1 := Vector3(cos(a1) * top_radius, y0 + height, sin(a1) * top_radius)

		# Wound so the faces point outward (Godot's front faces are
		# clockwise as seen from outside). These were reversed before, which
		# made the near side of each tree disappear.
		tool.add_vertex(b0)
		tool.add_vertex(b1)
		tool.add_vertex(t0)

		if top_radius > 0.0:
			tool.add_vertex(b1)
			tool.add_vertex(t1)
			tool.add_vertex(t0)

		# Underside, so the cone looks solid from below too.
		tool.add_vertex(b0)
		tool.add_vertex(b1)
		tool.add_vertex(Vector3(0.0, y0, 0.0))


# --- Cars & spawners --------------------------------------------------------

func _place_cars() -> void:
	var basis := Basis(Vector3.UP, _spawn_yaw)
	var right: Vector3 = basis.x
	var centre := Vector3(
		_spawn_center.x,
		_sea_level + _spawn_height + 1.5,
		_spawn_center.y
	)

	# Only cars that actually exist (singleplayer removes player 2).
	var active: Array[Node3D] = []

	for car in cars:
		if is_instance_valid(car):
			active.append(car)

	for index in active.size():
		var car: Node3D = active[index]

		# Side by side, so neither car starts by shunting the other. A
		# single car goes in the middle.
		var side: float = (index - (active.size() - 1) * 0.5) * spawn_car_gap

		car.global_transform = Transform3D(basis, centre + right * side)

		# The car body bumps into trees and rocks (wheels still ignore them).
		if car is CollisionObject3D:
			(car as CollisionObject3D).collision_mask |= 1 << (PROP_LAYER - 1)

		# See across the whole (big) map; distance fog softens the far edge.
		var camera := car.get_node_or_null("Camera3D") as Camera3D

		if camera != null:
			camera.far = maxf(camera.far, map_size * 1.3)

		if car is RigidBody3D:
			(car as RigidBody3D).linear_velocity = Vector3.ZERO
			(car as RigidBody3D).angular_velocity = Vector3.ZERO


func _configure_spawners() -> void:
	var extents := Vector2(_half, _half) * 0.9

	if coin_spawner != null:
		coin_spawner.spawn_center = Vector2.ZERO
		coin_spawner.spawn_extents = extents

		var scale: float = clampf(
			land_area_km2 / maxf(reference_land_area_km2, 0.1),
			0.2,
			3.0
		)

		coin_spawner.common_max_active = maxi(4, roundi(coin_spawner.common_max_active * scale))
		coin_spawner.uncommon_max_active = maxi(2, roundi(coin_spawner.uncommon_max_active * scale))
		coin_spawner.rare_max_active = maxi(1, roundi(coin_spawner.rare_max_active * scale))

	if target_spawner != null:
		target_spawner.spawn_center = Vector2.ZERO
		target_spawner.spawn_extents = extents

		# More targets on more land, like the coins.
		var target_scale: float = clampf(land_area_km2 / maxf(reference_land_area_km2, 0.1), 0.5, 4.0)
		target_spawner.max_active = maxi(2, roundi(target_spawner.max_active * target_scale))
