extends Node3D
class_name TargetSpawner


@export var target_scene: PackedScene

@export_group("Spawn Area")

@export var spawn_center: Vector2 = Vector2(-0.7, 0.64)


@export var spawn_extents: Vector2 = Vector2(2450.0, 2450.0)

@export var sea: Sea

@export_group("Ground Raycast")

@export var raycast_start_height: float = 700.0
@export var raycast_max_distance: float = 1500.0
@export var ground_collision_mask: int = 1

@export_group("Ramp Detection")


@export var min_ramp_angle_degrees: float = 12.0
@export var max_ramp_angle_degrees: float = 55.0

@export_group("Launch Estimate")


@export var assumed_launch_speed: float = 22.0
@export var min_target_height: float = 2.0
@export var max_target_height: float = 60.0

@export_group("Target")


@export var max_active: int = 10


@export var spawn_interval: float = 3.0

@export var target_scale: float = 1.0


var _container: Node3D


func _ready() -> void:
	if target_scene == null:
		push_warning(
			"TargetSpawner has no target_scene assigned; no targets will spawn."
		)
		return

	_container = Node3D.new()
	_container.name = "Targets"
	add_child(_container)


	_try_fill_targets()


	var timer := Timer.new()
	timer.name = "TargetSpawnTimer"
	timer.wait_time = spawn_interval
	timer.autostart = true
	timer.one_shot = false

	add_child(timer)

	timer.timeout.connect(_on_spawn_timer_timeout)


func _on_spawn_timer_timeout() -> void:
	if _container.get_child_count() >= max_active:
		return

	_try_spawn_one()


func _try_fill_targets() -> void:
	while _container.get_child_count() < max_active:
		if not _try_spawn_one():
			break


func _try_spawn_one() -> bool:
	if _container.get_child_count() >= max_active:
		return false

	var placement = _find_jump_target_position()

	if placement == null:
		return false

	var target: Target = target_scene.instantiate()

	_container.add_child(target)

	target.global_position = placement
	target.coin_scale = target_scale

	return true



func _find_jump_target_position() -> Variant:
	var space_state := get_world_3d().direct_space_state

	for attempt in 40:
		var x: float = (
			spawn_center.x +
			randf_range(-spawn_extents.x, spawn_extents.x)
		)

		var z: float = (
			spawn_center.y +
			randf_range(-spawn_extents.y, spawn_extents.y)
		)

		var ground = _raycast_ground(x, z, space_state)

		if ground == null:
			continue

		if sea != null and not sea.is_land_y(ground.position.y):
			continue

		var incline_degrees: float = rad_to_deg(
			acos(
				clampf(ground.normal.dot(Vector3.UP), -1.0, 1.0)
			)
		)

		if incline_degrees < min_ramp_angle_degrees:
			continue

		if incline_degrees > max_ramp_angle_degrees:
			continue


		var uphill_dir := Vector3(
			-ground.normal.x,
			0.0,
			-ground.normal.z
		).normalized()

		if uphill_dir.length_squared() < 0.01:
			continue

		var incline_radians: float = deg_to_rad(incline_degrees)

		var gravity: float = absf(
			ProjectSettings.get_setting(
				"physics/3d/default_gravity",
				9.8
			)
		)

		var vertical_speed: float = (
			assumed_launch_speed * sin(incline_radians)
		)

		var horizontal_speed: float = (
			assumed_launch_speed * cos(incline_radians)
		)

		var time_to_apex: float = vertical_speed / gravity

		var apex_height: float = clampf(
			(vertical_speed * vertical_speed) / (2.0 * gravity),
			min_target_height,
			max_target_height
		)

		var apex_distance: float = horizontal_speed * time_to_apex

		var launch_point: Vector3 = ground.position

		var apex_position: Vector3 = (
			launch_point +
			uphill_dir * apex_distance +
			Vector3.UP * apex_height
		)


		if _path_is_blocked(launch_point, apex_position, space_state):
			continue

		return apex_position

	return null


func _path_is_blocked(
	from_pos: Vector3,
	to_pos: Vector3,
	space_state: PhysicsDirectSpaceState3D
) -> bool:
	var query := PhysicsRayQueryParameters3D.create(
		from_pos + Vector3.UP * 2.0,
		to_pos
	)

	query.collision_mask = ground_collision_mask

	var result := space_state.intersect_ray(query)

	return not result.is_empty()


func _raycast_ground(
	x: float,
	z: float,
	space_state: PhysicsDirectSpaceState3D
) -> Variant:
	var from := Vector3(x, raycast_start_height, z)
	var to := Vector3(x, raycast_start_height - raycast_max_distance, z)

	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = ground_collision_mask

	var result := space_state.intersect_ray(query)

	if result:
		return {
			"position": result.position,
			"normal": result.normal,
		}

	return null
