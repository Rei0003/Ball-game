extends RigidBody3D
class_name RaycastCar


var spawn_position: Vector3
var spawn_rotation: Vector3

var reset_hold_timer: float = 0.0
var reset_hold_threshold: float = 0.75
var reset_hold_triggered: bool = false

@export_group("Wheels")
@export var wheels: Array[RaycastWheel]
@export var total_wheels: int = 4

@export_group("Engine")
@export var acceleration: float = 800.0
@export var max_speed: float = 60.0
@export var accel_curve: Curve

@export_group("Steering")
@export var tire_turn_speed: float = 3.0
@export var tire_max_turn_degrees: float = 60.0


@export var steering_speed_falloff_start: float = 10.0
@export var steering_speed_falloff_end: float = 40.0
@export var min_steering_angle_degrees: float = 18.0

@export_group("Nitro")
@export var nitro_capacity: float = 100.0
@export var nitro_drain_rate: float = 40.0
@export var nitro_regen_rate: float = 12.0
@export var nitro_drift_refill_rate: float = 15.0
@export var nitro_trick_refill: float = 20.0
@export var nitro_boost_multiplier: float = 1.6
@export var nitro_max_speed_bonus: float = 25.0

var nitro: float = 100.0
var is_boosting: bool = false

@export_group("Drift initiation")
@export var drift_min_speed: float = 6.0
@export var drift_min_steering: float = 0.78
@export var drift_start_angle: float = 8.0
@export var initiation_duration: float = 0.3

@export_group("Drift control")
@export var drift_yaw_strength: float = 3.5
@export var drift_countersteer_strength: float = 1.8
@export var drift_max_angle: float = 65.0
@export var drift_recovery_angle: float = 8.0


@export var drift_torque_smoothing: float = 6.0

var _drift_torque_current: float = 0.0

@export_group("Effects")
@export var skid_marks: Array[GPUParticles3D]

@export_group("Air Control")
@export var air_pitch_strength: float = 5.0
@export var air_yaw_strength: float = 4.0
@export var air_roll_strength: float = 4.0
@export var air_control_speed: float = 10.0



@export var controller: PlayerController
@onready var speedometer: Label = $Control/SpeedLabel
@onready var trick_label: Label = $"../CenterContainer/Label"
@onready var score_label: Label = $"../ScoreContainer/ScoreLabel"




@export_group("Speed Effect")
@export var speed_effect_start := 100.0
@export var speed_effect_full := 180.0
@export var speed_effect_smoothing := 4.0

@export var speed_effect: ColorRect

var speed_effect_strength := 0.0




var motor_input: int = 0
var hand_brake: bool = false

var is_slipping: bool = false
var is_drifting: bool = false
var is_initiating_drift: bool = false

var drift_direction: float = 0.0
var initiation_timer: float = 0.0

@export_group("Air Tricks")
@export var flip_detection_enabled: bool = true
@export var minimum_flip_angle: float = 300.0

var was_airborne: bool = false
var frontflip_rotation: float = 0.0
var backflip_rotation: float = 0.0
var trick_label_timer: float = 0.0

@export var score_per_flip: int = 75

var score: int = 0




func _ready() -> void:
	spawn_position = global_position
	spawn_rotation = global_rotation
	
	total_wheels = maxi(total_wheels, 1)

	score = 0
	score_label.text = str(score)

	nitro = nitro_capacity

	var world := get_tree().current_scene

	if controller.player_id == 1:
		var username_label: Label = world.get_node(
			"GridContainer/SubViewportContainer/SubViewport/UsernameLabel"
		)
		username_label.text = GameState.car1_username

	elif controller.player_id == 2:
		var username_label: Label = world.get_node(
			"GridContainer/SubViewportContainer2/SubViewport/UsernameLabel"
		)
		username_label.text = GameState.car2_username

	

func _update_speed_effect(delta: float) -> void:
	var velocity := linear_velocity
	
	
	velocity.y = 0.0
	
	var speed_kmh := velocity.length() * 3.6

	var target_strength := clampf(
		inverse_lerp(
			speed_effect_start,
			speed_effect_full,
			speed_kmh
		),
		0.0,
		1.0
	)

	speed_effect_strength = lerpf(
		speed_effect_strength,
		target_strength,
		delta * speed_effect_smoothing
	)

	var material := speed_effect.material as ShaderMaterial

	if material:
		material.set_shader_parameter(
			"strength",
			speed_effect_strength
		)




func _reset_car() -> void:
	var current_position := global_position
	var current_yaw := global_rotation.y

	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO

	global_position = current_position
	global_rotation = Vector3(0.0, current_yaw, 0.0)

	sleeping = false

func _reset_to_spawn() -> void:
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO

	global_position = spawn_position
	global_rotation = spawn_rotation

	sleeping = false



func respawn_at(new_position: Vector3) -> void:
	global_position = new_position

	_reset_car()


func _update_speedometer() -> void:
	var velocity := linear_velocity
	
	
	
	var speed_kmh := velocity.length() * 3.6
	
	speedometer.text = str(roundi(speed_kmh))




func _get_point_velocity(point: Vector3) -> Vector3:
	return (
		linear_velocity +
		angular_velocity.cross(point - global_position)
	)


func _update_inputs() -> void:
	if controller.is_accelerating():
		motor_input = 1
	elif controller.is_decelerating():
		motor_input = -1
	else:
		motor_input = 0

	hand_brake = controller.is_handbraking()


func _get_steering_input() -> float:
	return controller.get_steering()


func _basic_steering_rotation(
	wheel: RaycastWheel,
	delta: float
) -> void:

	if not wheel.is_steer:
		return

	var steering_input: float = _get_steering_input()

	var speed: float = linear_velocity.length()

	var speed_factor: float = 1.0 - clampf(
		inverse_lerp(
			steering_speed_falloff_start,
			steering_speed_falloff_end,
			speed
		),
		0.0,
		1.0
	)

	var current_max_turn_degrees: float = lerpf(
		min_steering_angle_degrees,
		tire_max_turn_degrees,
		speed_factor
	)

	var target_angle: float = (
		steering_input *
		deg_to_rad(current_max_turn_degrees)
	)

	var steering_speed: float = tire_turn_speed

	if is_drifting:
		steering_speed *= 1.35

	wheel.rotation.y = move_toward(
		wheel.rotation.y,
		target_angle,
		steering_speed * delta
	)


func _get_drift_angle() -> float:
	var velocity: Vector3 = linear_velocity

	velocity.y = 0.0

	if velocity.length_squared() < 1.0:
		return 0.0

	var forward: Vector3 = -global_basis.z

	forward.y = 0.0
	forward = forward.normalized()

	var velocity_direction: Vector3 = velocity.normalized()

	var angle: float = rad_to_deg(
		acos(
			clampf(
				forward.dot(velocity_direction),
				-1.0,
				1.0
			)
		)
	)

	var side: float = signf(
		global_basis.x.dot(velocity_direction)
	)

	return angle * side


func _begin_drift(direction: float) -> void:
	is_drifting = true
	is_initiating_drift = false
	initiation_timer = 0.0
	drift_direction = direction


func _begin_drift_initiation(direction: float) -> void:
	is_initiating_drift = true
	initiation_timer = initiation_duration
	drift_direction = direction


func _update_drift_state(delta: float) -> void:
	var speed: float = linear_velocity.length()
	var steering: float = _get_steering_input()

	if speed < drift_min_speed:
		is_drifting = false
		is_initiating_drift = false
		drift_direction = 0.0
		initiation_timer = 0.0
		return

	if not is_drifting and not is_initiating_drift:

		if hand_brake and absf(steering) > 0.2:
			_begin_drift(signf(steering))
			return

		if absf(steering) >= drift_min_steering:
			_begin_drift_initiation(signf(steering))
			return

	if is_initiating_drift:

		initiation_timer -= delta

		if absf(steering) < 0.5 and not hand_brake:
			is_initiating_drift = false
			initiation_timer = 0.0
			return

		var drift_angle: float = absf(_get_drift_angle())

		if drift_angle >= drift_start_angle:
			_begin_drift(drift_direction)
			return

		if initiation_timer <= 0.0:
			_begin_drift(drift_direction)
			return

	if is_drifting:

		var current_angle: float = absf(_get_drift_angle())

		if current_angle > drift_max_angle:
			is_drifting = false
			drift_direction = 0.0
			return

		if (
			current_angle < drift_recovery_angle
			and absf(steering) < 0.2
		):
			is_drifting = false
			drift_direction = 0.0


func _apply_drift_control(delta: float) -> void:
	if not is_drifting:
		_drift_torque_current = 0.0
		return

	var speed: float = linear_velocity.length()

	if speed < drift_min_speed:
		_drift_torque_current = 0.0
		return

	var steering: float = _get_steering_input()
	var direction: float = drift_direction

	var target_torque: float = 0.0

	if absf(steering) >= 0.05 and direction != 0.0:
		var countersteering: bool = (
			steering * direction < 0.0
		)

		if countersteering:
			target_torque = (
				steering *
				drift_countersteer_strength
			)
		else:
			target_torque = (
				steering *
				drift_yaw_strength
			)

	var actual_angle: float = _get_drift_angle()

	if absf(actual_angle) > 40.0:
		target_torque -= (
			signf(actual_angle) *
			drift_countersteer_strength *
			0.5
		)

	_drift_torque_current = move_toward(
		_drift_torque_current,
		target_torque,
		drift_torque_smoothing * delta
	)

	apply_torque(
		global_basis.y *
		_drift_torque_current
	)

func _apply_air_control(delta: float) -> void:
	var steering: float = _get_steering_input()
	var pitch_input: float = float(motor_input)
	var roll_input: float = controller.get_roll()

	var local_angular_velocity: Vector3 = (
		global_basis.inverse() * angular_velocity
	)

	var target_pitch: float = (
		-pitch_input *
		air_pitch_strength
	)

	local_angular_velocity.x = move_toward(
		local_angular_velocity.x,
		target_pitch,
		air_control_speed * delta
	)

	var target_yaw: float = (
		steering *
		air_yaw_strength
	)

	local_angular_velocity.y = move_toward(
		local_angular_velocity.y,
		target_yaw,
		air_control_speed * delta
	)



	var target_roll: float = (
		roll_input *
		air_roll_strength
	)

	local_angular_velocity.z = move_toward(
		local_angular_velocity.z,
		target_roll,
		air_control_speed * delta
	)

	angular_velocity = (
		global_basis *
		local_angular_velocity
	)

func _flips_from_rotation(rotation_amount: float) -> int:
	
	var tolerance: float = 360.0 - minimum_flip_angle

	return int(
		(rotation_amount + tolerance) / 360.0
	)

func _update_flip_detection(grounded: bool) -> void:
	if not flip_detection_enabled:
		return

	if not grounded and not was_airborne:
		was_airborne = true
		frontflip_rotation = 0.0
		backflip_rotation = 0.0

		return

	if not grounded and was_airborne:
		var local_angular_velocity: Vector3 = (
			global_basis.inverse() *
			angular_velocity
		)

		var pitch_speed: float = local_angular_velocity.x

		var pitch_degrees_per_second: float = (
			rad_to_deg(pitch_speed)
		)

		var delta_rotation: float = (
			pitch_degrees_per_second *
			get_physics_process_delta_time()
		)

	
		if delta_rotation < 0.0:
			frontflip_rotation += -delta_rotation
		else:
			backflip_rotation += delta_rotation

	if grounded and was_airborne:
		was_airborne = false

		var completed_frontflips: int = _flips_from_rotation(
			frontflip_rotation
		)

		var completed_backflips: int = _flips_from_rotation(
			backflip_rotation
		)

		if completed_frontflips > 0 or completed_backflips > 0:
			var trick_lines: PackedStringArray = []
			var total_earned_score: int = 0


			if completed_frontflips > 0:
				var frontflip_score: int = (
					completed_frontflips *
					score_per_flip
				)

				total_earned_score += frontflip_score

				trick_lines.append(
					"FRONTFLIP x" +
					str(completed_frontflips) +
					"  +" +
					str(frontflip_score)
				)



			if completed_backflips > 0:
				var backflip_score: int = (
					completed_backflips *
					score_per_flip
				)

				total_earned_score += backflip_score

				trick_lines.append(
					"BACKFLIP x" +
					str(completed_backflips) +
					"  +" +
					str(backflip_score)
				)



			score += total_earned_score

			score_label.text = str(score)

			nitro = minf(nitro_capacity, nitro + nitro_trick_refill)



			show_trick_message("\n".join(trick_lines))

			print(
				trick_label.text,
				" score"
			)

		frontflip_rotation = 0.0
		backflip_rotation = 0.0

func _update_trick_label(delta: float) -> void:
	if not trick_label.visible:
		return

	trick_label_timer -= delta

	if trick_label_timer <= 0.0:
		trick_label.hide()


func show_trick_message(text: String, duration: float = 2.0) -> void:
	trick_label.text = text
	trick_label.show()
	trick_label_timer = duration


func _update_nitro(delta: float) -> void:
	is_boosting = (
		controller.is_boosting()
		and nitro > 0.0
		and motor_input > 0
	)

	if is_boosting:
		nitro = maxf(0.0, nitro - nitro_drain_rate * delta)
		return

	var regen_rate: float = nitro_regen_rate

	if is_drifting:
		regen_rate += nitro_drift_refill_rate

	nitro = minf(nitro_capacity, nitro + regen_rate * delta)



func _physics_process(delta: float) -> void:
	var reset_action := controller.get_action("reset")

	# Reset handling
	if Input.is_action_just_pressed(reset_action):
		reset_hold_timer = 0.0
		reset_hold_triggered = false

		# Quick press = reset at current location
		_reset_car()

	if Input.is_action_pressed(reset_action):
		reset_hold_timer += delta

		# Holding reset = return to original spawn
		if (
			reset_hold_timer >= reset_hold_threshold
			and not reset_hold_triggered
		):
			reset_hold_triggered = true
			_reset_to_spawn()

	if Input.is_action_just_released(reset_action):
		reset_hold_timer = 0.0
		reset_hold_triggered = false


	# Normal car input/physics
	_update_inputs()
	_update_drift_state(delta)
	_apply_drift_control(delta)
	_update_nitro(delta)
	_update_speedometer()
	_update_speed_effect(delta)
	_update_trick_label(delta)


	var grounded: bool = false

	for id in wheels.size():
		var wheel: RaycastWheel = wheels[id]

		wheel.apply_wheel_physics(self)
		_basic_steering_rotation(wheel, delta)

		if id < skid_marks.size():
			var skid: GPUParticles3D = skid_marks[id]

			if wheel.is_colliding():
				skid.global_position = (
					wheel.get_collision_point() +
					Vector3.UP * 0.01
				)

				skid.look_at(
					skid.global_position +
					global_basis.z
				)

			skid.emitting = (
				is_drifting
				and not wheel.is_steer
				and wheel.grip_factor > 0.15
				and wheel.is_colliding()
			)

		if wheel.is_colliding():
			grounded = true


	_update_flip_detection(grounded)


	if not grounded:
		_apply_air_control(delta)


	if grounded:
		center_of_mass_mode = (
			RigidBody3D.CENTER_OF_MASS_MODE_AUTO
		)

		center_of_mass = Vector3.ZERO

	else:
		center_of_mass_mode = (
			RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
		)

		center_of_mass = Vector3.DOWN * 0.5
