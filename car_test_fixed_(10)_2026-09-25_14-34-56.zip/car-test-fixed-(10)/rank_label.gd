extends HBoxContainer
class_name RankLabel


@export var own_car: RaycastCar

@export var other_cars: Array[RaycastCar] = []

@export_group("Font Sizes")
@export var number_font_size: int = 28
@export var suffix_font_size: int = 14

@onready var _number_label: Label = $Number
@onready var _suffix_label: Label = $Suffix

func _ready() -> void:
	_number_label.add_theme_font_size_override("font_size", number_font_size)
	_suffix_label.add_theme_font_size_override("font_size", suffix_font_size)

func _process(_delta: float) -> void:
	if own_car == null:
		return

	var place: int = 1

	for car in other_cars:
		if car != null and car.score > own_car.score:
			place += 1

	_number_label.text = str(place)
	_suffix_label.text = _ordinal_suffix(place)

func _ordinal_suffix(n: int) -> String:
	if n % 100 in [11, 12, 13]:
		return "th"

	match n % 10:
		1: return "st"
		2: return "nd"
		3: return "rd"
		_: return "th"
