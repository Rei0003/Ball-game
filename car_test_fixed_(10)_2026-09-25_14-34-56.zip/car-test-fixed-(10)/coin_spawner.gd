extends Node3D
class_name CoinSpawner

@export var coin_scene: PackedScene

@export_group("Spawn Area")

@export var spawn_center: Vector2 = Vector2(-0.7, 0.64)

@export var spawn_extents: Vector2 = Vector2(2450.0, 2450.0)

@export var sea: Sea

@export var raycast_start_height: float = 700.0
@export var raycast_max_distance: float = 1500.0
@export var ground_collision_mask: int = 1

@export var ground_clearance: float = 1.0

@export var max_placement_attempts: int = 30

@export_group("Common Coin")
@export var common_enabled: bool = true
@export var common_scale: float = 1.0
@export var common_color: Color = Color(1.0, 0.84, 0.1)
@export var common_score: int = 30
@export var common_spawn_interval: float = 0.5
@export var common_max_active: int = 60

@export_group("Uncommon Coin")
@export var uncommon_enabled: bool = true
@export var uncommon_scale: float = 0.7
@export var uncommon_color: Color = Color(0.55, 0.36, 0.08)
@export var uncommon_score: int = 60
@export var uncommon_spawn_interval: float = 1.5
@export var uncommon_max_active: int = 24

@export_group("Rare Coin")
@export var rare_enabled: bool = true
@export var rare_scale: float = 0.45
@export var rare_color: Color = Color(0.16, 0.16, 0.18)
@export var rare_score: int = 120
@export var rare_spawn_interval: float = 4.0
@export var rare_max_active: int = 10

var _tier_containers: Dictionary = {}

func _ready() -> void:
	if coin_scene == null:
		push_warning("CoinSpawner has no coin_scene assigned; no coins will spawn.")
		return

	_setup_tier("common", common_enabled, common_spawn_interval)
	_setup_tier("uncommon", uncommon_enabled, uncommon_spawn_interval)
	_setup_tier("rare", rare_enabled, rare_spawn_interval)

func _setup_tier(tier_name: String, enabled: bool, interval: float) -> void:
	var container := Node3D.new()
	container.name = tier_name.capitalize() + "Coins"
	add_child(container)
	_tier_containers[tier_name] = container

	if not enabled:
		return

	var timer := Timer.new()
	timer.name = tier_name.capitalize() + "SpawnTimer"
	timer.wait_time = interval
	timer.autostart = true
	timer.one_shot = false
	add_child(timer)
	timer.timeout.connect(_try_spawn_one.bind(tier_name))

	
	_try_fill_tier(tier_name)

func _try_fill_tier(tier_name: String) -> void:
	var max_active: int = _max_active_for(tier_name)
	var container: Node3D = _tier_containers[tier_name]

	while container.get_child_count() < max_active:
		if not _try_spawn_one(tier_name):
			break

func _try_spawn_one(tier_name: String) -> bool:
	var max_active: int = _max_active_for(tier_name)
	var container: Node3D = _tier_containers[tier_name]

	if container.get_child_count() >= max_active:
		return false

	var placement = _find_ground_position()

	if placement == null:
		return false

	var coin: Coin = coin_scene.instantiate()
	container.add_child(coin)

	coin.global_position = placement + Vector3(0.0, ground_clearance, 0.0)
	coin.coin_scale = _scale_for(tier_name)
	coin.score_value = _score_for(tier_name)
	coin.display_name = _display_name_for(tier_name)
	coin.set_coin_color(_color_for(tier_name))

	return true

func _find_ground_position() -> Variant:
	var space_state := get_world_3d().direct_space_state

	for attempt in max_placement_attempts:
		var x: float = spawn_center.x + randf_range(-spawn_extents.x, spawn_extents.x)
		var z: float = spawn_center.y + randf_range(-spawn_extents.y, spawn_extents.y)

		var from := Vector3(x, raycast_start_height, z)
		var to := Vector3(x, raycast_start_height - raycast_max_distance, z)

		var query := PhysicsRayQueryParameters3D.create(from, to)
		query.collision_mask = ground_collision_mask

		var result := space_state.intersect_ray(query)

		if not result:
			continue

		if sea != null and not sea.is_land_y(result.position.y):
			continue

		return result.position

	return null

func _max_active_for(tier_name: String) -> int:
	match tier_name:
		"common": return common_max_active
		"uncommon": return uncommon_max_active
		"rare": return rare_max_active
	return 0

func _scale_for(tier_name: String) -> float:
	match tier_name:
		"common": return common_scale
		"uncommon": return uncommon_scale
		"rare": return rare_scale
	return 1.0

func _color_for(tier_name: String) -> Color:
	match tier_name:
		"common": return common_color
		"uncommon": return uncommon_color
		"rare": return rare_color
	return Color.WHITE

func _score_for(tier_name: String) -> int:
	match tier_name:
		"common": return common_score
		"uncommon": return uncommon_score
		"rare": return rare_score
	return 0

func _display_name_for(tier_name: String) -> String:
	match tier_name:
		"common": return "COMMON COIN"
		"uncommon": return "UNCOMMON COIN"
		"rare": return "RARE COIN"
	return "COIN"
