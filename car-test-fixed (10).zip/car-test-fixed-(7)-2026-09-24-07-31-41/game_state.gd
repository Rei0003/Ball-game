extends Node

var car1_username: String = ""
var car2_username: String = ""
var winner_username: String = ""
