extends RayCast3D
class_name RaycastWheel

@export_group("Wheel Properties")
@export var spring_strength: float = 5000.0
@export var spring_damping: float = 120.0
@export var rest_dist: float = 0.5
@export var over_extend: float = 0.02
@export var wheel_radius: float = 0.4

@export_group("Grip")
@export var front_grip: float = 1.0
@export var rear_grip: float = 1.0
@export var drift_front_grip: float = 0.72
@export var drift_rear_grip: float = 0.22
@export var handbrake_grip: float = 0.05
@export var initiation_rear_grip: float = 0.38

@export_group("Longitudinal Traction")
@export var z_traction: float = 0.05

## Caps how much grip force a tire can generate, as a multiple of its
## share of the car's weight. This exists purely to stop a sharp turn or
## handbrake pull at high speed from snapping the car's direction
## instantly - it should sit well above anything normal driving forces
## ever need, or the tire will fail to fully cancel out ordinary slip and
## the car will spiral out of control on its own. Only lower this if you
## still see snapping at extreme slip, and lower it gradually.
@export var max_grip_force_coefficient: float = 12.0

@export_group("Motor")
@export var is_motor: bool = false
@export var is_steer: bool = false

@onready var wheel: Node3D = get_child(0)

var engine_force: float = 0.0
var grip_factor: float = 0.0


func _ready() -> void:
	target_position.y = -(rest_dist + wheel_radius + over_extend)


func apply_wheel_physics(car: RaycastCar) -> void:
	force_raycast_update()

	target_position.y = -(rest_dist + wheel_radius + over_extend)

	var forward_dir: Vector3 = -global_basis.z

	var wheel_velocity: float = forward_dir.dot(
		car.linear_velocity
	)

	wheel.rotate_x(
		(-wheel_velocity * get_physics_process_delta_time())
		/ wheel_radius
	)

	if not is_colliding():
		grip_factor = 0.0
		return

	var contact: Vector3 = get_collision_point()

	var spring_len: float = maxf(
		0.0,
		global_position.distance_to(contact) - wheel_radius
	)

	var offset: float = rest_dist - spring_len

	wheel.position.y = move_toward(
		wheel.position.y,
		-spring_len,
		5.0 * get_physics_process_delta_time()
	)

	contact = wheel.global_position

	var force_pos: Vector3 = (
		contact -
		car.global_position
	)

	var spring_force: float = (
		spring_strength *
		offset
	)

	var tire_vel: Vector3 = (
		car._get_point_velocity(contact)
	)

	var spring_damp_force: float = (
		spring_damping *
		global_basis.y.dot(tire_vel)
	)

	var suspension_force: Vector3 = (
		spring_force -
		spring_damp_force
	) * get_collision_normal()

	if is_motor and car.motor_input != 0:
		var effective_max_speed: float = car.max_speed
		var effective_acceleration: float = car.acceleration

		if car.is_boosting:
			effective_max_speed += car.nitro_max_speed_bonus
			effective_acceleration *= car.nitro_boost_multiplier

		var speed_ratio: float = clampf(
			absf(wheel_velocity) / effective_max_speed,
			0.0,
			1.0
		)

		var acceleration_multiplier: float = (
			car.accel_curve.sample_baked(
				speed_ratio
			)
		)

		var engine_force_vector: Vector3 = (
			forward_dir *
			effective_acceleration *
			car.motor_input *
			acceleration_multiplier
		)

		car.apply_force(
			engine_force_vector,
			force_pos
		)

	var lateral_velocity: float = (
		global_basis.x.dot(tire_vel)
	)

	var longitudinal_velocity: float = (
		forward_dir.dot(tire_vel)
	)

	var tire_speed: float = tire_vel.length()

	var slip_angle: float = 0.0

	if tire_speed > 0.5:
		slip_angle = atan2(
			lateral_velocity,
			absf(longitudinal_velocity) + 0.1
		)

	var slip_degrees: float = absf(
		rad_to_deg(slip_angle)
	)

	grip_factor = clampf(
		slip_degrees / 45.0,
		0.0,
		1.0
	)

	var grip: float

	if is_steer:
		grip = front_grip
	else:
		grip = rear_grip

	if car.is_drifting:
		if is_steer:
			grip = drift_front_grip
		else:
			grip = drift_rear_grip

	elif car.is_initiating_drift and not is_steer:
		grip = initiation_rear_grip

	if car.hand_brake and not is_steer:
		grip = handbrake_grip

	var steering: float = (
		car.controller.get_steering()
	)

	if car.is_drifting and is_steer:
		var countersteering: bool = (
			steering *
			car.drift_direction < 0.0
		)

		if countersteering:
			grip *= 0.9

	var slip_multiplier: float = 1.0

	if is_steer:
		slip_multiplier = clampf(
			1.0 -
			slip_degrees / 75.0,
			0.35,
			1.0
		)
	else:
		slip_multiplier = clampf(
			1.0 -
			slip_degrees / 85.0,
			0.18,
			1.0
		)

	var effective_grip: float = (
		grip *
		slip_multiplier
	)

	var gravity: float = (
		-car.get_gravity().y
	)

	var normal_load: float = (
		car.mass *
		gravity /
		maxf(car.total_wheels, 1)
	)

	# A real tire can only generate so much grip force no matter how hard
	# it's slipping - without this cap, a sudden high-speed direction
	# mismatch (sharp turn, handbrake) produces an unbounded corrective
	# force that snaps the car's heading almost instantly instead of
	# sliding it around smoothly.
	var max_grip_force: float = (
		normal_load *
		max_grip_force_coefficient
	)

	var raw_lateral_force: float = (
		lateral_velocity *
		effective_grip *
		normal_load
	)

	var lateral_force: Vector3 = (
		-global_basis.x *
		clampf(
			raw_lateral_force,
			-max_grip_force,
			max_grip_force
		)
	)

	var longitudinal_grip: float = z_traction

	if not is_steer and car.is_drifting:
		longitudinal_grip *= 0.65

	var raw_longitudinal_force: float = (
		longitudinal_velocity *
		longitudinal_grip *
		normal_load
	)

	var longitudinal_force: Vector3 = (
		global_basis.z *
		clampf(
			raw_longitudinal_force,
			-max_grip_force,
			max_grip_force
		)
	)

	car.apply_force(
		suspension_force,
		force_pos
	)

	car.apply_force(
		lateral_force,
		force_pos
	)

	car.apply_force(
		longitudinal_force,
		force_pos
	)
