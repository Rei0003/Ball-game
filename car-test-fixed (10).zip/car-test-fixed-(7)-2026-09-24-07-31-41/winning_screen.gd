extends Control

@onready var winner_label: Label = $HBoxContainer2/WinnerNameLabel

func _ready() -> void:
	winner_label.text = GameState.winner_username 
