extends Control


@onready var line_edit_1: LineEdit = $HBoxContainer/LineEdit
@onready var line_edit_2: LineEdit = $HBoxContainer/LineEdit2




func _on_button_pressed() -> void:
	GameState.car1_username = line_edit_1.text
	GameState.car2_username = line_edit_2.text
	
	get_tree().change_scene_to_file("res://world.tscn")
