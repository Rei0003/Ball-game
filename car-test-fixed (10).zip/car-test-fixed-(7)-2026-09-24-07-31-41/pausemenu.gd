extends Control


@onready var resume_button: Button = $VBoxContainer/Button
@onready var options_button: Button = $VBoxContainer/Button2
@onready var quit_button: Button = $VBoxContainer/Button3


func _ready() -> void:
	# The pause menu must continue processing while the game is paused -
	# and this is also what lets it catch the Escape key to CLOSE the
	# menu again, since everything else stops receiving input once the
	# tree is paused.
	process_mode = Node.PROCESS_MODE_ALWAYS

	resume_button.pressed.connect(_on_resume_pressed)
	options_button.pressed.connect(_on_options_pressed)
	quit_button.pressed.connect(_on_quit_pressed)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("Pause-Menu"):
		if get_tree().paused:
			_resume_game()
		else:
			_pause_game()


func _pause_game() -> void:
	visible = true
	get_tree().paused = true


func _on_resume_pressed() -> void:
	_resume_game()


func _resume_game() -> void:
	visible = false
	get_tree().paused = false


func _on_options_pressed() -> void:
	pass


func _on_quit_pressed() -> void:
	get_tree().paused = false
	get_tree().quit()
