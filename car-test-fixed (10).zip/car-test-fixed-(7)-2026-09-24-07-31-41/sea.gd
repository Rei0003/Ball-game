extends MeshInstance3D
class_name Sea


@export var land_margin: float = 2.0
@export var sea_penalty: int = 50

@export_group("Respawn Trigger")

@export var trigger_height_above_sea: float = 1.0

@export var trigger_depth_below_sea: float = 2000.0

@export var respawn_cooldown: float = 1.0

@export_group("Car Respawn")

@export var respawn_height_offset: float = 1.5
@export var respawn_search_radius_step: float = 25.0
@export var respawn_search_max_radius: float = 3000.0
@export var respawn_search_angle_steps: int = 16

@export_group("Ground Raycast")
@export var raycast_start_height: float = 700.0
@export var raycast_max_distance: float = 1500.0
@export var ground_collision_mask: int = 1

var _trigger: Area3D
var _cars_on_cooldown: Dictionary = {}

func _ready() -> void:
	_setup_trigger()

func _setup_trigger() -> void:
	var horizontal_size := _get_world_horizontal_size()
	var sea_y := get_sea_level_y()

	var shape := BoxShape3D.new()
	shape.size = Vector3(
		horizontal_size.x,
		trigger_height_above_sea + trigger_depth_below_sea,
		horizontal_size.y
	)

	var collision_shape := CollisionShape3D.new()
	collision_shape.shape = shape

	_trigger = Area3D.new()
	_trigger.name = "RespawnTrigger"
	_trigger.collision_layer = 0
	_trigger.collision_mask = ground_collision_mask
	_trigger.monitorable = false


	_trigger.top_level = true

	add_child(_trigger)
	_trigger.add_child(collision_shape)

	_trigger.global_position = Vector3(
		global_transform.origin.x,
		sea_y + (trigger_height_above_sea - trigger_depth_below_sea) / 2.0,
		global_transform.origin.z
	)

	_trigger.body_entered.connect(_on_body_entered)

func _get_world_horizontal_size() -> Vector2:
	if mesh == null:
		return Vector2(5000.0, 5000.0)

	var aabb := mesh.get_aabb()
	var corner_a: Vector3 = global_transform * aabb.position
	var corner_b: Vector3 = global_transform * (aabb.position + aabb.size)

	return Vector2(
		absf(corner_b.x - corner_a.x),
		absf(corner_b.z - corner_a.z)
	)


func get_sea_level_y() -> float:
	if mesh == null:
		return global_transform.origin.y

	var local_y: float = mesh.get_aabb().get_center().y

	return (global_transform * Vector3(0.0, local_y, 0.0)).y


func is_land_y(y: float) -> bool:
	return y > get_sea_level_y() + land_margin


func find_nearest_land_position(from_position: Vector3) -> Variant:
	var space_state := get_world_3d().direct_space_state


	var direct = _raycast_ground(from_position.x, from_position.z, space_state)

	if direct != null and is_land_y(direct.y):
		return direct

	var radius: float = respawn_search_radius_step

	while radius <= respawn_search_max_radius:
		for step in respawn_search_angle_steps:
			var angle: float = (TAU / respawn_search_angle_steps) * step
			var x: float = from_position.x + cos(angle) * radius
			var z: float = from_position.z + sin(angle) * radius

			var hit = _raycast_ground(x, z, space_state)

			if hit != null and is_land_y(hit.y):
				return hit

		radius += respawn_search_radius_step

	return null

func _raycast_ground(
	x: float,
	z: float,
	space_state: PhysicsDirectSpaceState3D
) -> Variant:
	var from := Vector3(x, raycast_start_height, z)
	var to := Vector3(x, raycast_start_height - raycast_max_distance, z)

	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = ground_collision_mask

	var result := space_state.intersect_ray(query)

	if result:
		return result.position

	return null

func _on_body_entered(body: Node3D) -> void:
	if not (body is RaycastCar):
		return

	if _cars_on_cooldown.get(body, false):
		return

	var car: RaycastCar = body

	# Remove points for falling into the sea
	car.score -= sea_penalty
	car.score = max(car.score, 0)
	car.score_label.text = str(car.score)

	var land_position = find_nearest_land_position(car.global_position)

	if land_position == null:
		push_warning("Sea: couldn't find any land nearby to respawn the car onto.")
		return

	_cars_on_cooldown[car] = true

	car.respawn_at(
		land_position + Vector3(0.0, respawn_height_offset, 0.0)
	)

	await get_tree().create_timer(respawn_cooldown).timeout

	_cars_on_cooldown[car] = false
