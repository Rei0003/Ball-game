extends HBoxContainer


func _ready() -> void:
	pass


func _process(_delta: float) -> void:
	pass


func _on_playAgain_pressed() -> void:
	get_tree().change_scene_to_file("res://world.tscn")


func _on_mainMenu_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
