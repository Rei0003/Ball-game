extends Area3D
class_name Coin

## Emitted right before this coin frees itself, so a spawner can react
## (e.g. know a slot in its tier just opened up).
signal collected(coin: Coin)

## Points added to the driver's score when this coin is collected.
@export var score_value: int = 30

## Text shown on the driver's trick label when collected, e.g. "COMMON COIN".
@export var display_name: String = "COIN"

## Uniform size multiplier for the coin mesh and its pickup radius.
@export var coin_scale: float = 1.0:
	set(value):
		coin_scale = value
		scale = Vector3.ONE * coin_scale

## How fast the coin spins in place, purely visual.
@export var spin_speed_degrees: float = 90.0

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	rotate_y(deg_to_rad(spin_speed_degrees) * delta)

func set_coin_color(color: Color) -> void:
	for mesh_instance in _find_mesh_instances(self):
		var material := StandardMaterial3D.new()

		material.albedo_color = color
		material.metallic = 0.85
		material.roughness = 0.25

		mesh_instance.material_override = material

func _find_mesh_instances(node: Node) -> Array[MeshInstance3D]:
	var found: Array[MeshInstance3D] = []

	for child in node.get_children():
		if child is MeshInstance3D:
			found.append(child)

		found.append_array(_find_mesh_instances(child))

	return found

func _on_body_entered(body: Node3D) -> void:
	if not (body is RaycastCar):
		return

	var car: RaycastCar = body

	car.score += score_value
	car.score_label.text = str(car.score)

	car.show_trick_message(display_name + " +" + str(score_value))

	collected.emit(self)

	queue_free()
