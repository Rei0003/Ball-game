extends Camera3D

@export var min_distance := 4.0
@export var max_distance := 8.0
@export var height := 3.0
@export var ground_clearance := 0.5
@export var camera_radius := 0.35
@export_flags_3d_physics var terrain_collision_mask := 1

@onready var target: Node3D = get_parent()

func _physics_process(_delta: float) -> void:
	var from_target := global_position - target.global_position

	if from_target.length() < min_distance:
		from_target = from_target.normalized() * min_distance
	elif from_target.length() > max_distance:
		from_target = from_target.normalized() * max_distance

	from_target.y = height

	var desired_position := target.global_position + from_target
	var space_state := get_world_3d().direct_space_state

	var sphere := SphereShape3D.new()
	sphere.radius = camera_radius

	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = sphere
	query.transform = Transform3D(Basis.IDENTITY, desired_position)
	query.collision_mask = terrain_collision_mask
	query.exclude = [target]

	var results := space_state.intersect_shape(query)

	if not results.is_empty():
		var ground_query := PhysicsRayQueryParameters3D.create(
			desired_position + Vector3.UP * 5.0,
			desired_position + Vector3.DOWN * 20.0
		)

		ground_query.exclude = [target]
		ground_query.collision_mask = terrain_collision_mask

		var ground_result := space_state.intersect_ray(ground_query)

		if ground_result:
			desired_position.y = ground_result.position.y + camera_radius + ground_clearance

	global_position = global_position.lerp(desired_position, 0.15)
	look_at(target.global_position, Vector3.UP)
