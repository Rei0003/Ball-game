extends VBoxContainer


func _ready() -> void:
	pass


func _process(_delta: float) -> void:
	pass


func _on_start_pressed() -> void:

	hide()


	get_node("../Panel").hide()
	get_node("../Label").hide()
	get_node("../border").hide()


func _on_options_pressed() -> void:
	pass


func _on_quit_pressed() -> void:
	get_tree().quit()
